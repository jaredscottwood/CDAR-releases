fn configured_windows_resource() -> winresource::WindowsResource {
    let mut resource = winresource::WindowsResource::new();
    resource
        .set_icon("assets/cdar.ico")
        .set("CompanyName", "Jared Wood; OpenAI GPT-5.6 Sol")
        .set(
            "FileDescription",
            "CDAR: Circular Dichroism Analysis & Refinement",
        )
        .set("ProductName", "CDAR")
        .set("InternalName", "cdar.exe")
        .set("OriginalFilename", "cdar.exe")
        .set("LegalCopyright", "Copyright (c) 2026 Jared Wood");
    resource
}

fn main() {
    println!("cargo:rerun-if-changed=assets/cdar.ico");

    // On Windows this embeds the six-resolution .ico as the executable's
    // Explorer/taskbar identity. Runtime mode switching uses PNG-backed
    // viewport icons in app.rs. Build this value on every host so API changes
    // in winresource are still caught by Linux CI.
    let resource = configured_windows_resource();
    #[cfg(target_os = "windows")]
    resource.compile().expect("could not embed assets/cdar.ico");
    #[cfg(not(target_os = "windows"))]
    drop(resource);
}
