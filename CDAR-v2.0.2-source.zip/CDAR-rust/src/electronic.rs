//! Electronic UV/ECD parsing, broadening, fitting, and assignment.

use std::cmp::Ordering;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::{Arc, OnceLock};

use anyhow::{Context, Result, anyhow, bail};
use rayon::prelude::*;
use regex::Regex;

use crate::math::{
    HARTREE_TO_KCAL, R_GAS, T_DEFAULT, arange, dot, ev_to_nm, interp_sorted, linspace, max_abs,
    mean, median, min_max, nm_to_ev, polyfit_weighted, polyval, resample, rmsd, savgol_smooth,
    std_dev,
};

pub const ELECTRONIC_CALCULATED_FITTED_LABEL: &str = "Calculated (fitted)";
pub const ELECTRONIC_ENANTIOMER_FITTED_LABEL: &str = "Enantiomer (fitted)";

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Profile {
    #[default]
    Gaussian,
    Lorentzian,
}

impl Profile {
    pub fn label(self) -> &'static str {
        match self {
            Self::Gaussian => "Gaussian",
            Self::Lorentzian => "Lorentzian",
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Gauge {
    #[default]
    Velocity,
    Length,
}

impl Gauge {
    pub fn label(self) -> &'static str {
        match self {
            Self::Velocity => "Velocity",
            Self::Length => "Length",
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum EcdUnit {
    #[default]
    Millidegrees,
    MolarEllipticity,
}

impl EcdUnit {
    pub fn label(self) -> &'static str {
        match self {
            Self::Millidegrees => "Millidegrees (mdeg)",
            Self::MolarEllipticity => "Molar ellipticity",
        }
    }

    pub fn axis_label(self) -> &'static str {
        match self {
            Self::Millidegrees => "Millidegrees (mdeg)",
            Self::MolarEllipticity => "Molar ellipticity (deg·cm²·dmol⁻¹)",
        }
    }

    pub fn coordinate_unit(self) -> &'static str {
        match self {
            Self::Millidegrees => "mdeg",
            Self::MolarEllipticity => "deg·cm²·dmol⁻¹",
        }
    }

    pub fn column_suffix(self) -> &'static str {
        match self {
            Self::Millidegrees => "mdeg",
            Self::MolarEllipticity => "molar_ellipticity_deg_cm2_per_dmol",
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum FitObjective {
    #[default]
    PeakShape,
    LeastSquares,
    Cosine,
    CrossSection,
}

impl FitObjective {
    pub fn label(self) -> &'static str {
        match self {
            Self::PeakShape => "Peak-shape (recommended)",
            Self::LeastSquares => "Least-squares",
            Self::Cosine => "Cosine similarity",
            Self::CrossSection => "Cross-section",
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Sensitivity {
    Permissive,
    #[default]
    Normal,
    Strict,
}

impl Sensitivity {
    pub fn value(self) -> f64 {
        match self {
            Self::Permissive => 0.6,
            Self::Normal => 1.0,
            Self::Strict => 1.8,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::Permissive => "permissive",
            Self::Normal => "normal",
            Self::Strict => "strict",
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct Spectrum {
    pub x: Vec<f64>,
    pub y: Vec<f64>,
}

impl Spectrum {
    /// Shared sampling checks. Measured wavenumber axes may include zero or
    /// negative coordinates outside the positive-frequency analysis window.
    pub fn validate_domain(&self) -> Result<()> {
        if self.x.len() < 2
            || self.x.len() != self.y.len()
            || self.x.iter().any(|v| !v.is_finite())
            || self.y.iter().any(|v| !v.is_finite())
            || min_max(&self.x).is_none_or(|(low, high)| high <= low)
        {
            bail!(
                "spectrum requires complete finite intensities and at least two distinct finite coordinates"
            );
        }
        Ok(())
    }

    /// Electronic spectra convert wavelength to photon energy and require λ > 0.
    pub fn validate_wavelength_domain(&self) -> Result<()> {
        self.validate_domain()?;
        if self.x.iter().any(|v| *v <= 0.0) {
            bail!("UV/ECD spectra require positive wavelengths");
        }
        Ok(())
    }
    pub fn new(x: Vec<f64>, y: Vec<f64>) -> Self {
        Self { x, y }
    }

    pub fn is_empty(&self) -> bool {
        self.x.is_empty() || self.y.is_empty()
    }

    pub fn len(&self) -> usize {
        self.x.len().min(self.y.len())
    }

    pub fn sorted(self) -> Self {
        let (x, y) = crate::math::sorted_xy(&self.x, &self.y);
        Self { x, y }
    }
}

#[derive(Clone, Debug, Default)]
pub struct Conformer {
    pub name: String,
    pub path: PathBuf,
    pub energy_first: Option<f64>,
    pub energy_last: Option<f64>,
    /// `free` for validated Gaussian calculations.
    pub energy_kind: String,
    /// Geometry, Gibbs energy, connectivity and frequencies from this same
    /// Gaussian LOG containing the ground-state optimization and TDDFT calculation.
    pub opt_freq: Option<crate::gaussian::GaussianEvidence>,
    pub ev: Vec<f64>,
    pub fosc: Vec<f64>,
    pub rvel: Option<Vec<f64>>,
    pub rlen: Option<Vec<f64>>,
    pub include: bool,
    pub weight: f64,
}

impl Conformer {
    pub fn energy(&self) -> Option<f64> {
        self.opt_freq
            .as_ref()
            .and_then(|d| d.gibbs)
            .filter(|g| g.is_finite())
    }

    pub fn validate(&self) -> Result<()> {
        let Some(evidence) = &self.opt_freq else {
            bail!("missing validated Gaussian optimization calculation");
        };
        evidence.validate_optimization()?;
        let n = self.ev.len();
        if n == 0
            || self.ev.iter().any(|e| !e.is_finite() || *e <= 0.0)
            || self.fosc.len() != n
            || self.fosc.iter().any(|f| !f.is_finite() || *f < 0.0)
        {
            bail!("incomplete excitation energies or oscillator strengths");
        }
        for (label, strengths) in [("velocity", &self.rvel), ("length", &self.rlen)] {
            if strengths
                .as_ref()
                .is_none_or(|v| v.len() != n || v.iter().any(|r| !r.is_finite()))
            {
                bail!("incomplete {label}-gauge rotational strengths");
            }
        }
        Ok(())
    }

    pub fn rot(&self, gauge: Gauge) -> Vec<f64> {
        match gauge {
            Gauge::Velocity => self.rvel.clone().unwrap_or_default(),
            Gauge::Length => self.rlen.clone().unwrap_or_default(),
        }
    }

    pub fn nstates(&self) -> usize {
        self.ev.len()
    }
}

fn read_lossy(path: &Path) -> Result<String> {
    let bytes = fs::read(path).with_context(|| format!("could not read {}", path.display()))?;
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}

/// A conformer is imported only after its ground-state calculation and all
/// electronic spectral arrays have passed validation.
pub fn parse_gaussian(path: impl AsRef<Path>) -> Result<Conformer> {
    let path = path.as_ref();
    let text = read_lossy(path)?;
    let lines: Vec<&str> = text.lines().collect();
    let evidence = crate::gaussian::parse_opt_freq(&text, path);
    evidence.validate_optimization()?;
    let gibbs_line = evidence
        .gibbs_line
        .ok_or_else(|| anyhow!("missing Gibbs free energy"))?;
    let routes = crate::gaussian::routes(&lines);
    let (td_start, td_route) = routes
        .iter()
        .rev()
        .find(|(index, route)| *index > gibbs_line && crate::gaussian::has_keyword(route, "td"))
        .ok_or_else(|| {
            anyhow!("missing time-dependent calculation after the ground-state optimization")
        })?;
    if crate::gaussian::has_keyword(td_route, "opt") {
        bail!("ECD requires excitation data at the optimized ground-state geometry");
    }
    let td_end = routes
        .iter()
        .find(|(index, _)| index > td_start)
        .map_or(lines.len(), |(index, _)| *index);
    let td_lines = &lines[*td_start..td_end];
    if td_lines.iter().any(|line| line.contains("orientation:")) {
        let (atoms, coordinates) = crate::gaussian::geometry(td_lines)
            .ok_or_else(|| anyhow!("incomplete time-dependent calculation geometry"))?;
        if atoms != evidence.atomic_numbers
            || crate::dedup::superposition(&evidence.coordinates, &coordinates)
                .is_none_or(|m| m.max_deviation > 0.001)
        {
            bail!(
                "time-dependent calculation geometry does not match the completed ground-state optimization"
            );
        }
    }
    if !td_lines
        .iter()
        .any(|line| line.contains("Normal termination"))
    {
        bail!("time-dependent calculation has not terminated normally");
    }
    static EXCITED_RE: OnceLock<Regex> = OnceLock::new();
    let excited_re = EXCITED_RE.get_or_init(|| {
        Regex::new(
            r"^\s*Excited State\s+(\d+):\s+\S+\s+([^\s]+)\s+eV\s+[^\s]+\s+nm\s+[fF]\s*=\s*([^\s]+)",
        )
        .unwrap()
    });
    let mut ev = Vec::new();
    let mut fosc = Vec::new();
    for line in td_lines
        .iter()
        .filter(|line| line.trim_start().starts_with("Excited State"))
    {
        let cap = excited_re
            .captures(line)
            .ok_or_else(|| anyhow!("malformed excited-state data"))?;
        let index: usize = cap[1].parse()?;
        if index != ev.len() + 1 {
            bail!("excited-state indices are incomplete or repeated");
        }
        ev.push(
            crate::gaussian::parse_number(&cap[2])
                .ok_or_else(|| anyhow!("invalid excitation energy"))?,
        );
        fosc.push(
            crate::gaussian::parse_number(&cap[3])
                .ok_or_else(|| anyhow!("invalid oscillator strength"))?,
        );
    }
    static NSTATES_RE: OnceLock<Regex> = OnceLock::new();
    let nstates_re = NSTATES_RE.get_or_init(|| Regex::new(r"nstates\s*=\s*(\d+)").unwrap());
    if let Some(cap) = nstates_re.captures(td_route) {
        let expected: usize = cap[1].parse()?;
        if ev.len() != expected {
            bail!(
                "time-dependent calculation requested {expected} states but supplied {}",
                ev.len()
            );
        }
    }
    let rvel = grab_rot_block(td_lines, Gauge::Velocity, ev.len())?;
    let rlen = grab_rot_block(td_lines, Gauge::Length, ev.len())?;
    let conformer = Conformer {
        name: path
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("conformer")
            .into(),
        path: path.to_path_buf(),
        energy_first: evidence.gibbs,
        energy_last: evidence.gibbs,
        energy_kind: "free".into(),
        opt_freq: Some(evidence),
        ev,
        fosc,
        rvel: Some(rvel),
        rlen: Some(rlen),
        include: true,
        weight: 0.0,
    };
    conformer.validate()?;
    Ok(conformer)
}

fn grab_rot_block(lines: &[&str], gauge: Gauge, nstates: usize) -> Result<Vec<f64>> {
    let gauge_name = match gauge {
        Gauge::Velocity => "velocity",
        Gauge::Length => "length",
    };
    let start = lines
        .iter()
        .enumerate()
        .filter(|(_, line)| line.contains("Rotatory Strengths"))
        .filter(|(i, _)| {
            lines[*i..]
                .iter()
                .take(4)
                .any(|line| line.to_lowercase().contains(gauge_name))
        })
        .map(|(i, _)| i)
        .next_back()
        .ok_or_else(|| anyhow!("missing {gauge_name}-gauge rotational strengths"))?;
    let mut values = Vec::new();
    for line in lines.iter().skip(start + 1) {
        let fields: Vec<_> = line.split_whitespace().collect();
        let index = fields.first().and_then(|s| s.parse::<usize>().ok());
        if let Some(index) = index {
            if index != values.len() + 1 || fields.len() < 5 {
                bail!("incomplete {gauge_name}-gauge rotational-strength table");
            }
            let data: Option<Vec<_>> = fields[1..5]
                .iter()
                .map(|s| crate::gaussian::parse_number(s))
                .collect();
            let data =
                data.ok_or_else(|| anyhow!("invalid {gauge_name}-gauge rotational strength"))?;
            values.push(data[3]);
        } else if !values.is_empty() {
            break;
        }
    }
    if values.len() != nstates || nstates == 0 {
        bail!("{gauge_name}-gauge rotational-strength count does not match excitation energies");
    }
    Ok(values)
}

pub fn parse_qm(path: impl AsRef<Path>) -> Result<Conformer> {
    parse_gaussian(path)
}

/// Invalid conformers are rejected before the numerical de-duplication engine.
pub fn dedupe_electronic(conformers: &mut Vec<Conformer>) -> crate::dedup::DedupResult {
    let mut eligible = Vec::new();
    let mut rejected = Vec::new();
    for (i, c) in conformers.iter().enumerate() {
        match c.validate() {
            Ok(()) => eligible.push(i),
            Err(error) => rejected.push((i, error.to_string())),
        }
    }
    let evidence: Vec<_> = eligible
        .iter()
        .map(|&i| conformers[i].opt_freq.clone().unwrap())
        .collect();
    let mut report = crate::dedup::deduplicate(&evidence);
    report.remap_indices(&eligible);
    report.rejected = rejected;
    *conformers = report
        .survivors
        .iter()
        .map(|&i| conformers[i].clone())
        .collect();
    report
}

pub fn boltzmann_weights(energies_hartree: &[f64], temperature: f64) -> (Vec<f64>, Vec<f64>) {
    if energies_hartree.is_empty()
        || !temperature.is_finite()
        || temperature <= 0.0
        || energies_hartree.iter().any(|v| !v.is_finite())
    {
        return (Vec::new(), Vec::new());
    }
    let minimum = energies_hartree
        .iter()
        .copied()
        .fold(f64::INFINITY, f64::min);
    let relative: Vec<f64> = energies_hartree
        .iter()
        .map(|e| (e - minimum) * HARTREE_TO_KCAL)
        .collect();
    let factors: Vec<f64> = relative
        .iter()
        .map(|de| (-de / (R_GAS * temperature)).exp())
        .collect();
    let total: f64 = factors.iter().sum();
    // The minimum-energy conformer's factor is one, so valid inputs always
    // have a positive normalizer. Never invent equal populations for bad data.
    let weights = factors.iter().map(|v| v / total).collect();
    (weights, relative)
}

pub fn broaden(
    transitions: &[f64],
    weights: &[f64],
    sigma: f64,
    grid_ev: &[f64],
    profile: Profile,
    energy_weight: bool,
) -> Vec<f64> {
    if transitions.is_empty() || sigma <= 0.0 {
        return vec![0.0; grid_ev.len()];
    }
    let n = transitions.len().min(weights.len());
    let norm = 1.0 / (std::f64::consts::PI.sqrt() * sigma);
    let inv_pi = 1.0 / std::f64::consts::PI;
    let sigma2 = sigma * sigma;
    grid_ev
        .par_iter()
        .map(|&x| {
            (0..n)
                .map(|i| {
                    let mut weight = weights[i];
                    if energy_weight {
                        weight *= transitions[i];
                    }
                    let dx = x - transitions[i];
                    match profile {
                        Profile::Gaussian => {
                            let d = dx / sigma;
                            norm * weight * (-d * d).exp()
                        }
                        Profile::Lorentzian => inv_pi * weight * sigma / (dx * dx + sigma2),
                    }
                })
                .sum()
        })
        .collect()
}

#[derive(Clone, Debug, Default)]
pub struct WeightedTransitions {
    pub ev: Vec<f64>,
    pub fosc: Vec<f64>,
    pub rot: Vec<f64>,
    pub weights: Vec<f64>,
    pub relative_energies: Vec<f64>,
    pub used_indices: Vec<usize>,
}

pub fn weighted_transitions(
    conformers: &[Conformer],
    gauge: Gauge,
    temperature: f64,
) -> WeightedTransitions {
    let used_indices: Vec<usize> = conformers
        .iter()
        .enumerate()
        .filter(|(_, c)| c.include && c.validate().is_ok())
        .map(|(i, _)| i)
        .collect();
    if used_indices.is_empty() {
        return WeightedTransitions::default();
    }
    let energies: Vec<f64> = used_indices
        .iter()
        .map(|&i| conformers[i].energy().unwrap())
        .collect();
    let (weights, relative_energies) = boltzmann_weights(&energies, temperature);
    let states: usize = used_indices.iter().map(|&i| conformers[i].nstates()).sum();
    let mut ev = Vec::with_capacity(states);
    let mut fosc = Vec::with_capacity(states);
    let mut rot = Vec::with_capacity(states);
    for (&index, &population) in used_indices.iter().zip(&weights) {
        let conformer = &conformers[index];
        ev.extend_from_slice(&conformer.ev);
        fosc.extend(conformer.fosc.iter().map(|v| v * population));
        rot.extend(conformer.rot(gauge).into_iter().map(|v| v * population));
    }
    WeightedTransitions {
        ev,
        fosc,
        rot,
        weights,
        relative_energies,
        used_indices,
    }
}

pub fn scale_to_match(reference: &[f64], calculated: &[f64]) -> (Vec<f64>, f64) {
    let gp = max_abs(calculated);
    let fp = max_abs(reference);
    let scale = if gp > 0.0 { fp / gp } else { 1.0 };
    (calculated.iter().map(|v| v * scale).collect(), scale)
}

pub fn cross_section(a: &[f64], b: &[f64], dx: f64) -> f64 {
    a.iter().zip(b).map(|(x, y)| (x - y).abs()).sum::<f64>() * dx
}

pub fn cosine_similarity(a: &[f64], b: &[f64]) -> f64 {
    let numerator = dot(a, b);
    let denominator = (dot(a, a) * dot(b, b)).sqrt();
    if denominator > 0.0 {
        numerator / denominator
    } else {
        0.0
    }
}

#[derive(Clone, Debug, Default)]
pub struct EcdSimilarity {
    pub s_pp: f64,
    pub s_nn: f64,
    pub phi_pp: f64,
    pub phi_nn: f64,
    pub smsi: f64,
}

pub fn ecd_similarity(reference: &[f64], calculated: &[f64]) -> EcdSimilarity {
    let n = reference.len().min(calculated.len());
    let mut fpp = Vec::new();
    let mut gpp = Vec::new();
    let mut fnn = Vec::new();
    let mut gnn = Vec::new();
    let mut denominator = 0.0;
    let mut pp_area = 0.0;
    let mut nn_area = 0.0;
    for i in 0..n {
        let f = reference[i];
        let g = calculated[i];
        denominator += f.abs() + g.abs();
        if f > 0.0 && g > 0.0 {
            fpp.push(f);
            gpp.push(g);
            pp_area += f + g;
        } else if f < 0.0 && g < 0.0 {
            fnn.push(f);
            gnn.push(g);
            nn_area += f.abs() + g.abs();
        }
    }
    let s_pp = if fpp.is_empty() {
        0.0
    } else {
        cosine_similarity(&fpp, &gpp)
    };
    let s_nn = if fnn.is_empty() {
        0.0
    } else {
        cosine_similarity(&fnn, &gnn)
    };
    let (phi_pp, phi_nn) = if denominator > 0.0 {
        (pp_area / denominator, nn_area / denominator)
    } else {
        (0.0, 0.0)
    };
    EcdSimilarity {
        s_pp,
        s_nn,
        phi_pp,
        phi_nn,
        smsi: phi_pp * s_pp + phi_nn * s_nn,
    }
}

#[derive(Clone, Debug, Default)]
pub struct EsiResult {
    pub delta: f64,
    pub same: EcdSimilarity,
    pub opposite: EcdSimilarity,
}

pub fn esi(reference: &[f64], calculated: &[f64]) -> EsiResult {
    let same = ecd_similarity(reference, calculated);
    let mirrored: Vec<f64> = calculated.iter().map(|v| -*v).collect();
    let opposite = ecd_similarity(reference, &mirrored);
    EsiResult {
        delta: same.smsi - opposite.smsi,
        same,
        opposite,
    }
}

pub const BASELINE_CAP_FRAC: f64 = 0.30;
pub const NOISE_K: f64 = 5.0;
pub const REL_FLOOR: f64 = 0.06;
pub const MIN_WIDTH_FRAC: f64 = 0.025;

pub fn estimate_noise(y: &[f64]) -> f64 {
    if y.len() < 5 {
        return 0.0;
    }
    let second: Vec<f64> = y.windows(3).map(|w| w[2] - 2.0 * w[1] + w[0]).collect();
    let med = median(&second);
    let deviations: Vec<f64> = second.iter().map(|v| (v - med).abs()).collect();
    median(&deviations) / (0.6745 * 6.0_f64.sqrt())
}

pub fn estimate_baseline(
    x: &[f64],
    y: &[f64],
    order: usize,
    iterations: usize,
    asymmetric: bool,
) -> Vec<f64> {
    let n = x.len().min(y.len());
    if n < 8.max(order + 2) {
        return vec![0.0; n];
    }
    let (xlo, xhi) = min_max(&x[..n]).unwrap_or((0.0, 1.0));
    let span = if xhi > xlo { xhi - xlo } else { 1.0 };
    let xmean = mean(&x[..n]);
    let normalized: Vec<f64> = x[..n].iter().map(|v| (v - xmean) / span).collect();
    let mut weights = vec![1.0; n];
    let mut baseline = vec![0.0; n];
    for _ in 0..iterations.max(1) {
        let Some(coefficients) = polyfit_weighted(&normalized, &y[..n], order, &weights) else {
            break;
        };
        baseline = normalized
            .iter()
            .map(|&v| polyval(&coefficients, v))
            .collect();
        let residual: Vec<f64> = y[..n].iter().zip(&baseline).map(|(a, b)| a - b).collect();
        let rmed = median(&residual);
        let absolute: Vec<f64> = residual.iter().map(|v| (v - rmed).abs()).collect();
        let mut scale = median(&absolute) / 0.6745;
        if scale == 0.0 {
            scale = std_dev(&residual);
        }
        if scale == 0.0 {
            scale = 1.0;
        }
        for (i, value) in residual.iter().enumerate() {
            let t = value / (3.0 * scale);
            let robust = 1.0 / (1.0 + t * t);
            weights[i] = if asymmetric && *value <= 0.0 {
                1.0
            } else {
                robust
            };
        }
    }
    let (blo, bhi) = min_max(&baseline).unwrap_or((0.0, 0.0));
    let (ylo, yhi) = min_max(&y[..n]).unwrap_or((0.0, 1.0));
    let base_range = bhi - blo;
    let signal_range = if yhi > ylo { yhi - ylo } else { 1.0 };
    let cap = BASELINE_CAP_FRAC * signal_range;
    if base_range > cap && base_range > 0.0 {
        let factor = cap / base_range;
        for value in &mut baseline {
            *value *= factor;
        }
    }
    baseline
}

pub fn baseline_correct(x: &[f64], y: &[f64], order: usize, asymmetric: bool) -> Vec<f64> {
    let baseline = estimate_baseline(x, y, order, 8, asymmetric);
    y.iter()
        .zip(&baseline)
        .map(|(value, base)| value - base)
        .collect()
}

#[derive(Clone, Debug, Default)]
pub struct Feature {
    pub x: f64,
    pub y: f64,
    pub sign: i8,
    pub prominence: f64,
    pub width: f64,
}

fn local_extrema(y: &[f64]) -> (Vec<usize>, Vec<usize>) {
    if y.len() < 3 {
        return (Vec::new(), Vec::new());
    }
    let mut signs: Vec<i8> = y
        .windows(2)
        .map(|w| {
            if w[1] > w[0] {
                1
            } else if w[1] < w[0] {
                -1
            } else {
                0
            }
        })
        .collect();
    if signs.iter().all(|v| *v == 0) {
        return (Vec::new(), Vec::new());
    }
    let mut last = 0;
    for sign in &mut signs {
        if *sign == 0 {
            *sign = last;
        } else {
            last = *sign;
        }
    }
    let mut maxima = Vec::new();
    let mut minima = Vec::new();
    for i in 0..signs.len().saturating_sub(1) {
        if signs[i] > 0 && signs[i + 1] < 0 {
            maxima.push(i + 1);
        } else if signs[i] < 0 && signs[i + 1] > 0 {
            minima.push(i + 1);
        }
    }
    (maxima, minima)
}

fn prominence_and_width(y: &[f64], index: usize, is_maximum: bool) -> (f64, f64) {
    let n = y.len();
    let reference = y[index];
    let mut j = index as isize - 1;
    let mut left_base = reference;
    while j >= 0 {
        let value = y[j as usize];
        if (is_maximum && value > reference) || (!is_maximum && value < reference) {
            break;
        }
        left_base = if is_maximum {
            left_base.min(value)
        } else {
            left_base.max(value)
        };
        j -= 1;
    }
    let mut k = index + 1;
    let mut right_base = reference;
    while k < n {
        let value = y[k];
        if (is_maximum && value > reference) || (!is_maximum && value < reference) {
            break;
        }
        right_base = if is_maximum {
            right_base.min(value)
        } else {
            right_base.max(value)
        };
        k += 1;
    }
    let (prominence, half) = if is_maximum {
        let p = reference - left_base.max(right_base);
        (p, reference - p / 2.0)
    } else {
        let p = left_base.min(right_base) - reference;
        (p, reference + p / 2.0)
    };
    if prominence <= 0.0 {
        return (0.0, 0.0);
    }
    let mut a = index;
    while a > 0 && if is_maximum { y[a] > half } else { y[a] < half } {
        a -= 1;
    }
    let mut b = index;
    while b + 1 < n && if is_maximum { y[b] > half } else { y[b] < half } {
        b += 1;
    }
    (prominence, (b.saturating_sub(a)).max(1) as f64)
}

pub fn find_features(
    x: &[f64],
    y: &[f64],
    minimum_prominence: f64,
    minimum_width: f64,
) -> Vec<Feature> {
    let n = x.len().min(y.len());
    if n < 3 {
        return Vec::new();
    }
    let (maxima, minima) = local_extrema(&y[..n]);
    let dx = if n > 1 {
        mean(&x[..n].windows(2).map(|w| w[1] - w[0]).collect::<Vec<_>>())
    } else {
        1.0
    };
    let mut features = Vec::new();
    for (indices, is_maximum) in [(&maxima, true), (&minima, false)] {
        for &index in indices {
            let (prominence, samples) = prominence_and_width(&y[..n], index, is_maximum);
            let width = (samples * dx).abs();
            if prominence >= minimum_prominence && samples > 0.0 && width >= minimum_width {
                features.push(Feature {
                    x: x[index],
                    y: y[index],
                    sign: if is_maximum { 1 } else { -1 },
                    prominence,
                    width,
                });
            }
        }
    }
    features.sort_by(|a, b| a.x.partial_cmp(&b.x).unwrap_or(Ordering::Equal));
    features
}

#[derive(Clone, Debug, Default)]
pub struct SpectrumAnalysis {
    pub x: Vec<f64>,
    pub smooth: Vec<f64>,
    pub noise: f64,
    pub span: f64,
    pub minimum_prominence: f64,
    pub window: usize,
    pub minimum_width: f64,
    pub features: Vec<Feature>,
    pub peak: f64,
    pub relative_floor: f64,
}

pub fn analyze_spectrum(x: &[f64], y: &[f64], sensitivity: f64) -> SpectrumAnalysis {
    let n = x.len().min(y.len());
    if n == 0 {
        return SpectrumAnalysis::default();
    }
    let noise = estimate_noise(&y[..n]);
    let (raw_lo, raw_hi) = min_max(&y[..n]).unwrap_or((0.0, 1.0));
    let raw_span = if raw_hi > raw_lo {
        raw_hi - raw_lo
    } else {
        1.0
    };
    let relative_noise = noise / raw_span;
    let fraction = (0.006 + 0.3 * relative_noise).clamp(0.006, 0.02);
    let mut window = ((n as f64 * fraction).round() as usize).max(5);
    if window.is_multiple_of(2) {
        window += 1;
    }
    if window > n {
        window = if n % 2 == 1 { n } else { n.saturating_sub(1) };
    }
    let smooth = savgol_smooth(&y[..n], Some(window), 2);
    let (lo, hi) = min_max(&smooth).unwrap_or((0.0, 1.0));
    let span = if hi > lo { hi - lo } else { 1.0 };
    let minimum_prominence = (NOISE_K * noise).max(REL_FLOOR * span) * sensitivity.max(1e-6);
    let (xlo, xhi) = min_max(&x[..n]).unwrap_or((0.0, 1.0));
    let x_range = if xhi > xlo { xhi - xlo } else { 1.0 };
    let minimum_width = MIN_WIDTH_FRAC * x_range;
    let features = find_features(&x[..n], &smooth, minimum_prominence, minimum_width);
    SpectrumAnalysis {
        x: x[..n].to_vec(),
        smooth: smooth.clone(),
        noise,
        span,
        minimum_prominence,
        window,
        minimum_width,
        features,
        peak: {
            let value = max_abs(&smooth);
            if value > 0.0 { value } else { 1.0 }
        },
        relative_floor: REL_FLOOR * sensitivity.max(1e-6),
    }
}

pub fn match_features(experimental: &[Feature], calculated: &[Feature], tolerance: f64) -> usize {
    let mut used = vec![false; calculated.len()];
    let mut matched = 0;
    for exp in experimental {
        let mut best = None;
        let mut best_distance = f64::INFINITY;
        for (i, calc) in calculated.iter().enumerate() {
            if used[i] || calc.sign != exp.sign {
                continue;
            }
            let distance = (calc.x - exp.x).abs();
            if distance <= tolerance && distance < best_distance {
                best = Some(i);
                best_distance = distance;
            }
        }
        if let Some(index) = best {
            used[index] = true;
            matched += 1;
        }
    }
    matched
}

#[derive(Clone, Debug, Default)]
pub struct PeakScoreInfo {
    pub experimental_count: usize,
    pub calculated_count: usize,
    pub count_mismatch: usize,
    pub tier2: f64,
    pub scale: f64,
}

pub fn peak_count_score(
    analysis: &SpectrumAnalysis,
    calculated: &[f64],
    target: &[f64],
    energy_weight: bool,
) -> (f64, PeakScoreInfo) {
    let (lo, hi) = min_max(calculated).unwrap_or((0.0, 1.0));
    let span = if hi > lo { hi - lo } else { 1.0 };
    let calculated_features = find_features(
        &analysis.x,
        calculated,
        analysis.relative_floor * span,
        analysis.minimum_width,
    );
    let experimental_count = analysis.features.len();
    let calculated_count = calculated_features.len();
    let count_mismatch = experimental_count.abs_diff(calculated_count);
    let (scaled, scale) = scale_to_match(target, calculated);
    let tier2 = if energy_weight {
        esi(target, &scaled).delta.abs()
    } else {
        cosine_similarity(target, &scaled)
    };
    let score = count_mismatch as f64 * 10.0 - tier2;
    (
        score,
        PeakScoreInfo {
            experimental_count,
            calculated_count,
            count_mismatch,
            tier2,
            scale: scale.abs(),
        },
    )
}

#[derive(Clone, Debug, Default)]
pub struct FitResult {
    pub sigma: f64,
    pub shift: f64,
    pub scale: f64,
    pub normalized_rmsd: f64,
    pub similarity: f64,
    pub area: f64,
    pub score: f64,
    pub peak_info: Option<PeakScoreInfo>,
    pub experimental_features: Option<usize>,
    pub noise: Option<f64>,
}

#[allow(clippy::too_many_arguments)]
fn pack_fit(
    sigma: f64,
    shift: f64,
    experimental: &[f64],
    calculated: &[f64],
    calculated_scaled: &[f64],
    scale: f64,
    peak: f64,
    dx: f64,
    score: f64,
    peak_info: Option<PeakScoreInfo>,
) -> FitResult {
    FitResult {
        sigma,
        shift,
        scale: scale.abs(),
        normalized_rmsd: rmsd(experimental, calculated_scaled) / peak,
        similarity: cosine_similarity(experimental, calculated),
        area: cross_section(experimental, calculated_scaled, dx),
        score,
        peak_info,
        experimental_features: None,
        noise: None,
    }
}

fn point_score(
    experimental: &[f64],
    calculated: &[f64],
    calculated_scaled: &[f64],
    dx: f64,
    peak: f64,
    objective: FitObjective,
) -> (f64, bool) {
    match objective {
        FitObjective::Cosine => (cosine_similarity(experimental, calculated), false),
        FitObjective::CrossSection => (cross_section(experimental, calculated_scaled, dx), true),
        _ => (rmsd(experimental, calculated_scaled) / peak, true),
    }
}

#[allow(clippy::too_many_arguments)]
pub fn fit_2d(
    experimental_x_nm: &[f64],
    experimental_y: &[f64],
    transitions: &[f64],
    weights: &[f64],
    sigma_grid: &[f64],
    shift_grid: &[f64],
    profile: Profile,
    objective: FitObjective,
    energy_weight: bool,
    sign_robust: bool,
    npoints: usize,
    sensitivity: f64,
    topk: usize,
    remove_baseline: bool,
) -> Option<FitResult> {
    let n = experimental_x_nm.len().min(experimental_y.len());
    if n < 2 || transitions.is_empty() || sigma_grid.is_empty() || shift_grid.is_empty() {
        return None;
    }
    let (lo, hi) = min_max(&experimental_x_nm[..n])?;
    if hi <= lo {
        return None;
    }
    let grid = linspace(lo, hi, npoints.max(50));
    let dx = grid[1] - grid[0];
    let mut experimental = resample(&experimental_x_nm[..n], &experimental_y[..n], &grid);
    let use_shape = objective == FitObjective::PeakShape;
    if remove_baseline {
        experimental = baseline_correct(&grid, &experimental, 1, !energy_weight);
    }
    let peak = {
        let value = max_abs(&experimental);
        if value > 0.0 { value } else { 1.0 }
    };
    let analysis = use_shape.then(|| analyze_spectrum(&grid, &experimental, sensitivity));
    let target: &[f64] = analysis.as_ref().map_or(&experimental, |ctx| &ctx.smooth);

    let ev_lo = (nm_to_ev(hi) - 1.5).max(0.2);
    let ev_hi = nm_to_ev(lo) + 1.5;
    let evaluation_ev = linspace(ev_lo, ev_hi, 1000);
    let mut wavelength_ascending: Vec<f64> =
        evaluation_ev.iter().rev().map(|v| ev_to_nm(*v)).collect();
    let signs: &[f64] = if sign_robust { &[1.0, -1.0] } else { &[1.0] };

    let mut best: Option<FitResult> = None;
    let mut shortlist: Vec<(usize, f64, f64)> = Vec::new();
    let mut broadened_cache = Vec::new();
    for (sigma_index, &sigma) in sigma_grid.iter().enumerate() {
        let broadened = broaden(
            transitions,
            weights,
            sigma,
            &evaluation_ev,
            profile,
            energy_weight,
        );
        let broadened_ascending: Vec<f64> = broadened.into_iter().rev().collect();
        let mut rows = Vec::new();
        for &shift in shift_grid {
            for (x, base) in wavelength_ascending
                .iter_mut()
                .zip(evaluation_ev.iter().rev())
            {
                *x = ev_to_nm(*base) + shift;
            }
            let calculated = interp_sorted(&wavelength_ascending, &broadened_ascending, &grid);
            for &sign in signs {
                let candidate: Vec<f64> = if sign > 0.0 {
                    calculated.clone()
                } else {
                    calculated.iter().map(|v| -*v).collect()
                };
                let (scaled, scale) = scale_to_match(target, &candidate);
                if use_shape {
                    rows.push((rmsd(target, &scaled) / peak, shift, sign));
                } else {
                    let (score, lower_is_better) =
                        point_score(&experimental, &candidate, &scaled, dx, peak, objective);
                    let replace = best.as_ref().is_none_or(|current| {
                        if lower_is_better {
                            score < current.score
                        } else {
                            score > current.score
                        }
                    });
                    if replace {
                        best = Some(pack_fit(
                            sigma,
                            shift,
                            &experimental,
                            &candidate,
                            &scaled,
                            scale,
                            peak,
                            dx,
                            score,
                            None,
                        ));
                    }
                }
            }
        }
        if use_shape {
            rows.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(Ordering::Equal));
            shortlist.extend(
                rows.into_iter()
                    .take(topk.max(1))
                    .map(|(_, shift, sign)| (sigma_index, shift, sign)),
            );
            broadened_cache.push(broadened_ascending);
        }
    }
    if !use_shape {
        return best;
    }

    let analysis = analysis.as_ref()?;
    let mut scored = Vec::new();
    for (sigma_index, shift, sign) in shortlist {
        let sigma = sigma_grid[sigma_index];
        let broadened_ascending = &broadened_cache[sigma_index];
        for (x, base) in wavelength_ascending
            .iter_mut()
            .zip(evaluation_ev.iter().rev())
        {
            *x = ev_to_nm(*base) + shift;
        }
        let mut calculated = interp_sorted(&wavelength_ascending, broadened_ascending, &grid);
        if sign < 0.0 {
            calculated.iter_mut().for_each(|v| *v = -*v);
        }
        let (_, info) = peak_count_score(analysis, &calculated, &experimental, energy_weight);
        scored.push((sigma, shift, calculated, info));
    }
    let global_best_tier2 = scored
        .iter()
        .map(|row| row.3.tier2)
        .fold(f64::NEG_INFINITY, f64::max);
    let floor = if global_best_tier2 > 0.0 {
        global_best_tier2 * 0.80
    } else {
        global_best_tier2
    };
    let minimum_mismatch = scored
        .iter()
        .filter(|row| row.3.tier2 >= floor)
        .map(|row| row.3.count_mismatch)
        .min()?;
    let (sigma, shift, calculated, info) = scored
        .into_iter()
        .filter(|row| row.3.tier2 >= floor && row.3.count_mismatch == minimum_mismatch)
        .max_by(|a, b| a.3.tier2.partial_cmp(&b.3.tier2).unwrap_or(Ordering::Equal))?;
    let (scaled, scale) = scale_to_match(&experimental, &calculated);
    let score = info.count_mismatch as f64 * 10.0 - info.tier2;
    let mut result = pack_fit(
        sigma,
        shift,
        &experimental,
        &calculated,
        &scaled,
        scale,
        peak,
        dx,
        score,
        Some(info),
    );
    result.experimental_features = Some(analysis.features.len());
    result.noise = Some(analysis.noise);
    Some(result)
}

#[allow(clippy::too_many_arguments)]
pub fn fit_uv(
    x: &[f64],
    y: &[f64],
    transitions: &[f64],
    oscillator_strengths: &[f64],
    sigma_grid: &[f64],
    shift_grid: &[f64],
    profile: Profile,
    objective: FitObjective,
    sensitivity: f64,
) -> Option<FitResult> {
    fit_2d(
        x,
        y,
        transitions,
        oscillator_strengths,
        sigma_grid,
        shift_grid,
        profile,
        objective,
        false,
        false,
        1000,
        sensitivity,
        2,
        false,
    )
}

#[allow(clippy::too_many_arguments)]
pub fn fit_ecd_2d(
    x: &[f64],
    y: &[f64],
    transitions: &[f64],
    rotatory_strengths: &[f64],
    sigma_grid: &[f64],
    shift_grid: &[f64],
    profile: Profile,
    objective: FitObjective,
    sensitivity: f64,
) -> Option<FitResult> {
    fit_2d(
        x,
        y,
        transitions,
        rotatory_strengths,
        sigma_grid,
        shift_grid,
        profile,
        objective,
        true,
        true,
        1000,
        sensitivity,
        2,
        false,
    )
}

#[allow(clippy::too_many_arguments)]
pub fn fit_sigma(
    x: &[f64],
    y: &[f64],
    transitions: &[f64],
    weights: &[f64],
    shift: f64,
    sigma_grid: &[f64],
    profile: Profile,
    objective: FitObjective,
    energy_weight: bool,
    sign_robust: bool,
    sensitivity: f64,
) -> Option<FitResult> {
    fit_2d(
        x,
        y,
        transitions,
        weights,
        sigma_grid,
        &[shift],
        profile,
        objective,
        energy_weight,
        sign_robust,
        1000,
        sensitivity,
        2,
        false,
    )
}

type PreparedCurve = (Vec<f64>, Vec<f64>, Vec<f64>, Vec<f64>);

fn prepared_curve(
    wavelength: &[f64],
    intensity: &[f64],
    transitions: &[f64],
    weights: &[f64],
    sigma: f64,
    profile: Profile,
    energy_weight: bool,
) -> Option<PreparedCurve> {
    let (lo, hi) = min_max(wavelength)?;
    let ev_lo = (nm_to_ev(hi) - 1.5).max(0.2);
    let ev_hi = nm_to_ev(lo) + 1.5;
    let x_ev = linspace(ev_lo, ev_hi, 1000);
    let broadened = broaden(transitions, weights, sigma, &x_ev, profile, energy_weight);
    let x_nm_ascending: Vec<f64> = x_ev.iter().rev().map(|v| ev_to_nm(*v)).collect();
    let y_ascending: Vec<f64> = broadened.into_iter().rev().collect();
    let grid = linspace(lo, hi, 1000);
    let experimental = resample(wavelength, intensity, &grid);
    Some((x_nm_ascending, y_ascending, grid, experimental))
}

#[derive(Clone, Debug, Default)]
pub struct ShiftAdjustment {
    pub shift: f64,
    pub sigma_ecd: f64,
    pub uv_similarity: f64,
    pub esi: f64,
}

#[allow(clippy::too_many_arguments)]
pub fn esi_tolerant_shift(
    uv: &Spectrum,
    ecd: &Spectrum,
    transitions: &[f64],
    oscillator_strengths: &[f64],
    rotatory_strengths: &[f64],
    sigma_uv: f64,
    shift_center: f64,
    uv_similarity_reference: f64,
    sigma_ecd_center: f64,
    esi_reference: f64,
    profile: Profile,
    objective: FitObjective,
    uv_tolerance: f64,
    window: f64,
    step: f64,
    sensitivity: f64,
) -> Option<ShiftAdjustment> {
    if uv_tolerance <= 0.0 {
        return None;
    }
    let (x_uv, y_uv, grid_uv, exp_uv) = prepared_curve(
        &uv.x,
        &uv.y,
        transitions,
        oscillator_strengths,
        sigma_uv,
        profile,
        false,
    )?;
    let (x_ecd, y_ecd, grid_ecd, exp_ecd) = prepared_curve(
        &ecd.x,
        &ecd.y,
        transitions,
        rotatory_strengths,
        sigma_ecd_center,
        profile,
        true,
    )?;
    let candidates = arange(
        shift_center - window,
        shift_center + window + step / 2.0,
        step,
    );
    let mut best_shift = None;
    let mut best_esi = esi_reference;
    for shift in candidates {
        let shifted_uv: Vec<f64> = x_uv.iter().map(|v| v + shift).collect();
        let calc_uv = interp_sorted(&shifted_uv, &y_uv, &grid_uv);
        let (calc_uv_scaled, _) = scale_to_match(&exp_uv, &calc_uv);
        if cosine_similarity(&exp_uv, &calc_uv_scaled) < uv_similarity_reference - uv_tolerance {
            continue;
        }
        let shifted_ecd: Vec<f64> = x_ecd.iter().map(|v| v + shift).collect();
        let calc_ecd = interp_sorted(&shifted_ecd, &y_ecd, &grid_ecd);
        let (calc_ecd_scaled, _) = scale_to_match(&exp_ecd, &calc_ecd);
        let candidate_esi = esi(&exp_ecd, &calc_ecd_scaled).delta.abs();
        if candidate_esi > best_esi {
            best_esi = candidate_esi;
            best_shift = Some(shift);
        }
    }
    let best_shift = best_shift?;
    let sigma_grid = arange(
        (sigma_ecd_center - 0.03).max(0.03),
        sigma_ecd_center + 0.0301,
        0.005,
    );
    let sigma_ecd = fit_sigma(
        &ecd.x,
        &ecd.y,
        transitions,
        rotatory_strengths,
        best_shift,
        &sigma_grid,
        profile,
        objective,
        true,
        true,
        sensitivity,
    )
    .map_or(sigma_ecd_center, |fit| fit.sigma);

    let shifted_uv: Vec<f64> = x_uv.iter().map(|v| v + best_shift).collect();
    let calc_uv = interp_sorted(&shifted_uv, &y_uv, &grid_uv);
    let (calc_uv_scaled, _) = scale_to_match(&exp_uv, &calc_uv);
    let uv_similarity = cosine_similarity(&exp_uv, &calc_uv_scaled);

    let (x_ecd_final, y_ecd_final, grid_ecd_final, exp_ecd_final) = prepared_curve(
        &ecd.x,
        &ecd.y,
        transitions,
        rotatory_strengths,
        sigma_ecd,
        profile,
        true,
    )?;
    let shifted_ecd: Vec<f64> = x_ecd_final.iter().map(|v| v + best_shift).collect();
    let calc_ecd = interp_sorted(&shifted_ecd, &y_ecd_final, &grid_ecd_final);
    let (calc_ecd_scaled, _) = scale_to_match(&exp_ecd_final, &calc_ecd);
    Some(ShiftAdjustment {
        shift: best_shift,
        sigma_ecd,
        uv_similarity,
        esi: esi(&exp_ecd_final, &calc_ecd_scaled).delta,
    })
}

#[derive(Clone, Debug, Default)]
pub struct ParsedExperimental {
    pub wavelength: Vec<f64>,
    pub columns: Vec<Vec<f64>>,
    pub ncolumns: usize,
    pub source: String,
}

pub fn parse_experimental(path: impl AsRef<Path>) -> Result<ParsedExperimental> {
    let text = read_lossy(path.as_ref())?;
    parse_experimental_text(&text)
}

pub fn parse_experimental_text(text: &str) -> Result<ParsedExperimental> {
    if looks_jasco(text) {
        return parse_jasco(text);
    }
    let lines: Vec<&str> = text
        .lines()
        .filter(|line| !line.trim().is_empty())
        .collect();
    if lines.is_empty() {
        bail!("experimental file is empty");
    }
    let delimiter = sniff_delimiter(&lines);
    rows_to_experimental(numeric_rows(&lines, delimiter)?, "delimited")
}

fn sniff_delimiter(lines: &[&str]) -> Option<char> {
    for line in lines {
        let line = line.trim().trim_start_matches('\u{feff}');
        if line.starts_with(['#', ';', '%', '!']) {
            continue;
        }
        for delimiter in [Some(','), Some('\t'), Some(';'), None] {
            let fields = split_fields(line, delimiter);
            if fields.first().is_some_and(|v| v.parse::<f64>().is_ok()) {
                return delimiter;
            }
        }
    }
    None
}

fn split_fields(line: &str, delimiter: Option<char>) -> Vec<&str> {
    match delimiter {
        Some(delimiter) => line.split(delimiter).map(str::trim).collect(),
        None => line.split_whitespace().collect(),
    }
}

/// Preserve column positions and reject damaged numeric rows rather than
/// shifting channels or silently discarding observations.
fn numeric_rows(lines: &[&str], delimiter: Option<char>) -> Result<Vec<Vec<f64>>> {
    let mut rows = Vec::new();
    let mut width = None;
    for (index, line) in lines.iter().enumerate() {
        let line = line.trim().trim_start_matches('\u{feff}');
        if line.is_empty() || line.starts_with(['#', ';', '%', '!']) {
            continue;
        }
        let fields = split_fields(line, delimiter);
        let numeric_first = fields.first().is_some_and(|v| v.parse::<f64>().is_ok());
        if !numeric_first {
            if !rows.is_empty()
                && fields.len() >= 2
                && fields[1..].iter().all(|v| v.parse::<f64>().is_ok())
            {
                bail!("invalid coordinate in measurement row {}", index + 1);
            }
            continue; // textual headers and instrument metadata
        }
        let values: Option<Vec<f64>> = fields
            .iter()
            .map(|v| v.parse::<f64>().ok().filter(|v| v.is_finite()))
            .collect();
        let values = values.ok_or_else(|| {
            anyhow!(
                "missing, nonnumeric, or non-finite value in measurement row {}",
                index + 1
            )
        })?;
        let expected = *width.get_or_insert(values.len());
        if values.len() < 2 || values.len() != expected {
            bail!(
                "measurement row {} has {} columns; expected {expected}",
                index + 1,
                values.len()
            );
        }
        rows.push(values);
    }
    Ok(rows)
}

fn looks_jasco(text: &str) -> bool {
    let upper = text.to_ascii_uppercase();
    upper.contains("XYDATA")
        || upper.contains("JASCO")
        || (upper.contains("TITLE") && upper.contains("NPOINTS"))
}

fn parse_jasco(text: &str) -> Result<ParsedExperimental> {
    let lines: Vec<&str> = text.lines().collect();
    let start = lines
        .iter()
        .position(|line| line.to_ascii_uppercase().contains("XYDATA"))
        .map_or(0, |index| index + 1);
    let data = &lines[start..];
    rows_to_experimental(numeric_rows(data, sniff_delimiter(data))?, "jasco")
}

fn rows_to_experimental(rows: Vec<Vec<f64>>, source: &str) -> Result<ParsedExperimental> {
    if rows.len() < 2 {
        bail!("experimental data needs at least two complete numeric rows");
    }
    let width = rows[0].len();
    let wavelength = rows.iter().map(|row| row[0]).collect();
    let columns = (1..width)
        .map(|column| rows.iter().map(|row| row[column]).collect())
        .collect();
    Ok(ParsedExperimental {
        wavelength,
        columns,
        ncolumns: width,
        source: source.into(),
    })
}

pub fn guess_roles(columns: &[Vec<f64>]) -> (Option<usize>, Option<usize>) {
    if columns.is_empty() {
        return (None, None);
    }
    if columns.len() == 1 {
        return if columns[0].iter().any(|v| *v < -1e-9) {
            (None, Some(0))
        } else {
            (Some(0), None)
        };
    }
    let negative_fraction: Vec<f64> = columns
        .iter()
        .map(|column| {
            column.iter().filter(|v| **v < -1e-9).count() as f64 / column.len().max(1) as f64
        })
        .collect();
    let ecd = negative_fraction
        .iter()
        .enumerate()
        .max_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(Ordering::Equal))
        .and_then(|(index, fraction)| (*fraction > 0.02).then_some(index));
    let uv = columns
        .iter()
        .enumerate()
        .filter(|(index, _)| Some(*index) != ecd)
        .max_by(|a, b| {
            let span_a = min_max(a.1).map_or(0.0, |(lo, hi)| hi - lo);
            let span_b = min_max(b.1).map_or(0.0, |(lo, hi)| hi - lo);
            span_a.partial_cmp(&span_b).unwrap_or(Ordering::Equal)
        })
        .map(|(index, _)| index);
    if ecd.is_none() && columns.len() >= 2 {
        (Some(0), Some(1))
    } else {
        (uv, ecd)
    }
}

#[derive(Clone, Debug, Default)]
pub struct ElectronicCurves {
    pub wavelength: Vec<f64>,
    pub uv: Vec<f64>,
    pub ecd: Vec<f64>,
    pub stick_nm: Vec<f64>,
    pub stick_f: Vec<f64>,
    pub stick_r: Vec<f64>,
    pub populations: Vec<f64>,
    pub relative_energies: Vec<f64>,
    pub used_indices: Vec<usize>,
}

#[derive(Clone, Debug, Default)]
pub struct BandChannelReport {
    pub experimental: Vec<Feature>,
    pub calculated: Vec<Feature>,
    pub noise: f64,
    pub matched: usize,
}

#[derive(Clone, Debug, Default)]
pub struct BandReport {
    pub uv: Option<BandChannelReport>,
    pub ecd: Option<BandChannelReport>,
}

#[derive(Clone, Debug, Default)]
pub struct ElectronicEvaluation {
    pub uv_similarity: Option<f64>,
    pub esi: Option<f64>,
    pub esi_detail: Option<EsiResult>,
    pub similarity_same: Option<f64>,
    pub similarity_enantiomer: Option<f64>,
    pub sign_agreement: Option<f64>,
    pub shape_where_signed: Option<f64>,
    pub discrimination: Option<f64>,
    pub fit_quality: Option<f64>,
    pub assignment: String,
    pub reliability: String,
}

#[derive(Clone, Debug)]
pub struct ElectronicDataset {
    pub(crate) state: crate::state::DatasetState,
    pub name: String,
    pub experimental_uv: Option<Spectrum>,
    pub experimental_ecd: Option<Spectrum>,
    pub experimental_source: String,
    pub conformers: Vec<Conformer>,
    pub sigma_uv: f64,
    pub sigma_ecd: f64,
    pub link_sigma: bool,
    pub shift: f64,
    pub scale_uv: f64,
    pub scale_ecd: f64,
    pub ecd_unit: EcdUnit,
    pub profile: Profile,
    pub gauge: Gauge,
    pub temperature: f64,
    pub show_enantiomer: bool,
    pub show_sticks: bool,
    pub show_peaks: bool,
    pub show_export_legend: bool,
    /// True only after a successful Auto-Fit for the current inputs.
    pub fitted: bool,
    pub sensitivity: Sensitivity,
    pub wavelength_min: f64,
    pub wavelength_max: f64,
    pub npoints: usize,
    pub dpi: u32,
    cache: Option<Arc<ElectronicCurves>>,
}

impl Default for ElectronicDataset {
    fn default() -> Self {
        Self::new("Compound 1")
    }
}

impl ElectronicDataset {
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            state: Default::default(),
            name: name.into(),
            experimental_uv: None,
            experimental_ecd: None,
            experimental_source: String::new(),
            conformers: Vec::new(),
            sigma_uv: 0.20,
            sigma_ecd: 0.20,
            link_sigma: true,
            shift: 0.0,
            scale_uv: 1.0,
            scale_ecd: 1.0,
            ecd_unit: EcdUnit::Millidegrees,
            profile: Profile::Gaussian,
            gauge: Gauge::Velocity,
            temperature: T_DEFAULT,
            show_enantiomer: false,
            show_sticks: false,
            show_peaks: false,
            show_export_legend: true,
            fitted: false,
            sensitivity: Sensitivity::Normal,
            wavelength_min: 200.0,
            wavelength_max: 500.0,
            npoints: 1400,
            dpi: 400,
            cache: None,
        }
    }

    pub fn has_experimental_uv(&self) -> bool {
        self.experimental_uv.as_ref().is_some_and(|s| !s.is_empty())
    }

    pub fn has_experimental_ecd(&self) -> bool {
        self.experimental_ecd
            .as_ref()
            .is_some_and(|s| !s.is_empty())
    }

    pub fn has_any_experimental(&self) -> bool {
        self.has_experimental_uv() || self.has_experimental_ecd()
    }

    pub fn has_calculation(&self) -> bool {
        self.conformers
            .iter()
            .any(|c| c.include && c.validate().is_ok())
    }

    pub fn ecd_sigma(&self) -> f64 {
        if self.link_sigma {
            self.sigma_uv
        } else {
            self.sigma_ecd
        }
    }

    pub fn invalidate(&mut self) {
        self.cache = None;
    }

    /// Call when inputs or fit settings change, including an explicit reset.
    /// Display-only changes invalidate the curve cache without expiring a fit.
    pub fn invalidate_fit(&mut self) {
        self.fitted = false;
        self.state.changed();
    }

    pub fn set_default_range(&mut self) {
        let mut lows = Vec::new();
        let mut highs = Vec::new();
        for spectrum in [&self.experimental_uv, &self.experimental_ecd]
            .into_iter()
            .flatten()
        {
            if let Some((lo, hi)) = min_max(&spectrum.x) {
                lows.push(lo);
                highs.push(hi);
            }
        }
        if let (Some(lo), Some(hi)) = (
            lows.into_iter()
                .min_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal)),
            highs
                .into_iter()
                .max_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal)),
        ) {
            self.wavelength_min = lo;
            self.wavelength_max = hi;
        } else if self.has_calculation() {
            let weighted = weighted_transitions(&self.conformers, self.gauge, self.temperature);
            let wavelengths: Vec<f64> = weighted
                .ev
                .iter()
                .map(|v| ev_to_nm(*v))
                .filter(|v| v.is_finite())
                .collect();
            if let Some((lo, hi)) = min_max(&wavelengths) {
                self.wavelength_min = (lo - 40.0).max(150.0);
                self.wavelength_max = hi + 60.0;
            }
        }
        self.invalidate();
    }

    pub fn curves(&mut self) -> Option<Arc<ElectronicCurves>> {
        if let Some(cache) = &self.cache {
            return Some(cache.clone());
        }
        for conformer in &mut self.conformers {
            conformer.weight = 0.0;
        }
        let weighted = weighted_transitions(&self.conformers, self.gauge, self.temperature);
        if weighted.ev.is_empty() {
            return None;
        }
        for (&index, &population) in weighted.used_indices.iter().zip(&weighted.weights) {
            if let Some(conformer) = self.conformers.get_mut(index) {
                conformer.weight = population;
            }
        }
        let lo = self.wavelength_min.min(self.wavelength_max);
        let hi = self.wavelength_min.max(self.wavelength_max);
        let ev_lo = (nm_to_ev(hi) - 1.5).max(0.2);
        let ev_hi = nm_to_ev(lo) + 1.5;
        let grid_ev = linspace(ev_lo, ev_hi, self.npoints.max(50));
        let uv = broaden(
            &weighted.ev,
            &weighted.fosc,
            self.sigma_uv,
            &grid_ev,
            self.profile,
            false,
        );
        let ecd = broaden(
            &weighted.ev,
            &weighted.rot,
            self.ecd_sigma(),
            &grid_ev,
            self.profile,
            true,
        );
        let mut rows: Vec<(f64, f64, f64)> = grid_ev
            .into_iter()
            .zip(uv)
            .zip(ecd)
            .map(|((ev, uv), ecd)| (ev_to_nm(ev) + self.shift, uv, ecd))
            .filter(|row| row.0 >= lo && row.0 <= hi)
            .collect();
        rows.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(Ordering::Equal));
        let mut wavelength = Vec::with_capacity(rows.len());
        let mut uv = Vec::with_capacity(rows.len());
        let mut ecd = Vec::with_capacity(rows.len());
        for (x, u, e) in rows {
            wavelength.push(x);
            uv.push(u);
            ecd.push(e);
        }
        let curves = Arc::new(ElectronicCurves {
            wavelength,
            uv,
            ecd,
            stick_nm: weighted
                .ev
                .iter()
                .map(|v| ev_to_nm(*v) + self.shift)
                .collect(),
            stick_f: weighted.fosc,
            stick_r: weighted.rot,
            populations: weighted.weights,
            relative_energies: weighted.relative_energies,
            used_indices: weighted.used_indices,
        });
        self.cache = Some(curves.clone());
        Some(curves)
    }

    fn comparison_grid(&self, channel: Option<&Spectrum>, count: usize) -> Vec<f64> {
        let mut lo = self.wavelength_min.min(self.wavelength_max);
        let mut hi = self.wavelength_min.max(self.wavelength_max);
        if let Some(channel) = channel
            && let Some((c_lo, c_hi)) = min_max(&channel.x)
        {
            lo = lo.max(c_lo);
            hi = hi.min(c_hi);
        }
        if !lo.is_finite() || !hi.is_finite() || hi <= lo {
            lo = self.wavelength_min.min(self.wavelength_max);
            hi = self.wavelength_min.max(self.wavelength_max);
        }
        linspace(lo, hi, count)
    }

    pub fn autoscale(&mut self) {
        let Some(curves) = self.curves() else { return };
        if let Some(experimental) = self.experimental_uv.as_ref()
            && max_abs(&curves.uv) > 0.0
        {
            let grid = self.comparison_grid(Some(experimental), 800);
            let observed = resample(&experimental.x, &experimental.y, &grid);
            let calculated = resample(&curves.wavelength, &curves.uv, &grid);
            let peak = max_abs(&calculated);
            if peak > 0.0 {
                self.scale_uv = max_abs(&observed) / peak;
            }
        }
        if let Some(experimental) = self.experimental_ecd.as_ref()
            && max_abs(&curves.ecd) > 0.0
        {
            let grid = self.comparison_grid(Some(experimental), 800);
            let observed = resample(&experimental.x, &experimental.y, &grid);
            let calculated = resample(&curves.wavelength, &curves.ecd, &grid);
            let peak = max_abs(&calculated);
            if peak > 0.0 {
                self.scale_ecd = max_abs(&observed) / peak;
            }
        }
    }

    fn channel_band_report(
        &self,
        experimental: &Spectrum,
        calculated_x: Option<&[f64]>,
        calculated_y: Option<&[f64]>,
    ) -> BandChannelReport {
        let grid = self.comparison_grid(Some(experimental), 800);
        let observed = resample(&experimental.x, &experimental.y, &grid);
        let analysis = analyze_spectrum(&grid, &observed, self.sensitivity.value());
        let mut report = BandChannelReport {
            experimental: analysis.features.clone(),
            noise: analysis.noise,
            ..Default::default()
        };
        if let (Some(x), Some(y)) = (calculated_x, calculated_y) {
            let calculated = resample(x, y, &grid);
            let (lo, hi) = min_max(&calculated).unwrap_or((0.0, 1.0));
            let span = if hi > lo { hi - lo } else { 1.0 };
            report.calculated = find_features(
                &grid,
                &calculated,
                analysis.relative_floor * span,
                analysis.minimum_width,
            );
            let xspan = grid.last().copied().unwrap_or(1.0) - grid.first().copied().unwrap_or(0.0);
            let tolerance = (0.04 * xspan).max(6.0);
            report.matched = match_features(&report.experimental, &report.calculated, tolerance);
        }
        report
    }

    pub fn band_report(&mut self) -> BandReport {
        let curves = self.curves();
        let uv = self.experimental_uv.as_ref().map(|experimental| {
            let calculated = curves
                .as_ref()
                .map(|c| c.uv.iter().map(|v| v * self.scale_uv).collect::<Vec<_>>());
            self.channel_band_report(
                experimental,
                curves.as_ref().map(|c| c.wavelength.as_slice()),
                calculated.as_deref(),
            )
        });
        let ecd = self.experimental_ecd.as_ref().map(|experimental| {
            let calculated = curves
                .as_ref()
                .map(|c| c.ecd.iter().map(|v| v * self.scale_ecd).collect::<Vec<_>>());
            self.channel_band_report(
                experimental,
                curves.as_ref().map(|c| c.wavelength.as_slice()),
                calculated.as_deref(),
            )
        });
        BandReport { uv, ecd }
    }

    pub fn evaluate(&mut self) -> ElectronicEvaluation {
        let mut evaluation = ElectronicEvaluation::default();
        let Some(curves) = self.curves() else {
            return evaluation;
        };
        if let Some(experimental) = &self.experimental_uv {
            let grid = self.comparison_grid(Some(experimental), 800);
            let observed = resample(&experimental.x, &experimental.y, &grid);
            let scaled: Vec<f64> = curves.uv.iter().map(|v| v * self.scale_uv).collect();
            let calculated = resample(&curves.wavelength, &scaled, &grid);
            evaluation.uv_similarity = Some(cosine_similarity(&observed, &calculated));
        }
        if let Some(experimental) = &self.experimental_ecd {
            let grid = self.comparison_grid(Some(experimental), 800);
            let observed = resample(&experimental.x, &experimental.y, &grid);
            let scaled: Vec<f64> = curves.ecd.iter().map(|v| v * self.scale_ecd).collect();
            let calculated = resample(&curves.wavelength, &scaled, &grid);
            let detail = esi(&observed, &calculated);
            let delta = detail.delta;
            let same = detail.same.smsi;
            let opposite = detail.opposite.smsi;
            let sign_agreement = detail.same.phi_pp + detail.same.phi_nn;
            let shape_where_signed = if sign_agreement > 0.0 {
                same / sign_agreement
            } else {
                0.0
            };
            evaluation.assignment = if delta > 0.05 {
                "As-calculated configuration favoured".into()
            } else if delta < -0.05 {
                "Enantiomer of the calculation favoured".into()
            } else {
                "Inconclusive (|Δ| very small)".into()
            };
            let total = same + opposite;
            let discrimination = if total > 0.0 { delta / total } else { 0.0 };
            let absolute = discrimination.abs();
            evaluation.reliability = if absolute >= 0.75 {
                "high reliability — the enantiomer is decisively rejected".into()
            } else if absolute >= 0.45 {
                "moderate reliability — the enantiomer fits clearly worse".into()
            } else if absolute >= 0.20 {
                "low reliability — consider other methods".into()
            } else {
                "not reliable — both configurations fit comparably".into()
            };
            if absolute >= 0.45 && total < 0.75 {
                evaluation
                    .reliability
                    .push_str("; the modest ESI reflects band intensity agreement, not ambiguity");
            }
            evaluation.esi = Some(delta);
            evaluation.similarity_same = Some(same);
            evaluation.similarity_enantiomer = Some(opposite);
            evaluation.sign_agreement = Some(sign_agreement);
            evaluation.shape_where_signed = Some(shape_where_signed);
            evaluation.discrimination = Some(discrimination);
            evaluation.fit_quality = Some(total);
            evaluation.esi_detail = Some(detail);
        } else if evaluation.uv_similarity.is_some() {
            evaluation.assignment = "UV fitted (no ECD loaded)".into();
            evaluation.reliability = "Load experimental ECD for an assignment.".into();
        }
        evaluation
    }

    pub fn reset_fit(&mut self) {
        self.sigma_uv = 0.20;
        self.sigma_ecd = 0.20;
        self.link_sigma = true;
        self.shift = 0.0;
        self.profile = Profile::Gaussian;
        self.invalidate_fit();
        self.invalidate();
        self.autoscale();
    }
}

#[derive(Clone, Debug)]
pub struct ElectronicAutoFitInput {
    pub transitions: Vec<f64>,
    pub oscillator_strengths: Vec<f64>,
    pub rotatory_strengths: Vec<f64>,
    pub uv: Option<Spectrum>,
    pub ecd: Option<Spectrum>,
    pub profile: Profile,
    pub objective: FitObjective,
    pub sensitivity: f64,
}

impl ElectronicAutoFitInput {
    pub fn from_dataset(dataset: &ElectronicDataset, objective: FitObjective) -> Self {
        let weighted =
            weighted_transitions(&dataset.conformers, dataset.gauge, dataset.temperature);
        Self {
            transitions: weighted.ev,
            oscillator_strengths: weighted.fosc,
            rotatory_strengths: weighted.rot,
            uv: dataset.experimental_uv.clone(),
            ecd: dataset.experimental_ecd.clone(),
            profile: dataset.profile,
            objective,
            sensitivity: dataset.sensitivity.value(),
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct ElectronicAutoFitOutput {
    pub sigma_uv: Option<f64>,
    pub sigma_ecd: Option<f64>,
    pub shift: f64,
    pub uv_similarity: Option<f64>,
    pub ecd_fitted: bool,
    pub shift_adjusted_for_esi: bool,
    pub esi_before_adjustment: Option<f64>,
}

pub fn run_electronic_auto_fit(input: ElectronicAutoFitInput) -> Result<ElectronicAutoFitOutput> {
    if input.transitions.is_empty() {
        bail!("no calculated excited states are available");
    }
    if input.uv.is_none() && input.ecd.is_none() {
        bail!("no experimental UV or ECD spectrum is available");
    }
    for spectrum in [&input.uv, &input.ecd].into_iter().flatten() {
        spectrum.validate_wavelength_domain()?;
    }
    let coarse_sigma = arange(0.05, 0.4001, 0.02);
    let coarse_shift = arange(-40.0, 40.001, 2.0);
    let mut sigma_uv = None;
    let mut sigma_ecd = None;
    let mut shift = 0.0;
    let mut uv_similarity = None;
    let mut shift_adjusted = false;
    let mut esi_before_adjustment = None;

    if let Some(uv) = &input.uv
        && let Some(coarse) = fit_uv(
            &uv.x,
            &uv.y,
            &input.transitions,
            &input.oscillator_strengths,
            &coarse_sigma,
            &coarse_shift,
            input.profile,
            input.objective,
            input.sensitivity,
        )
    {
        let fine_sigma = arange(
            (coarse.sigma - 0.03).max(0.03),
            coarse.sigma + 0.0301,
            0.005,
        );
        let fine_shift = arange(coarse.shift - 2.0, coarse.shift + 2.001, 0.25);
        let fit = fit_uv(
            &uv.x,
            &uv.y,
            &input.transitions,
            &input.oscillator_strengths,
            &fine_sigma,
            &fine_shift,
            input.profile,
            input.objective,
            input.sensitivity,
        )
        .unwrap_or(coarse);
        sigma_uv = Some(fit.sigma);
        shift = fit.shift;
        uv_similarity = Some(fit.similarity);
    }

    if let Some(ecd) = &input.ecd {
        if let (Some(uv), Some(uv_sigma)) = (&input.uv, sigma_uv) {
            if let Some(coarse) = fit_sigma(
                &ecd.x,
                &ecd.y,
                &input.transitions,
                &input.rotatory_strengths,
                shift,
                &coarse_sigma,
                input.profile,
                input.objective,
                true,
                true,
                input.sensitivity,
            ) {
                let fine_sigma = arange(
                    (coarse.sigma - 0.03).max(0.03),
                    coarse.sigma + 0.0301,
                    0.005,
                );
                let fit = fit_sigma(
                    &ecd.x,
                    &ecd.y,
                    &input.transitions,
                    &input.rotatory_strengths,
                    shift,
                    &fine_sigma,
                    input.profile,
                    input.objective,
                    true,
                    true,
                    input.sensitivity,
                )
                .unwrap_or(coarse);
                sigma_ecd = Some(fit.sigma);
            }

            if let (Some(ecd_sigma), Some(uv_reference)) = (sigma_ecd, uv_similarity) {
                let (x, y, grid, observed) = prepared_curve(
                    &ecd.x,
                    &ecd.y,
                    &input.transitions,
                    &input.rotatory_strengths,
                    ecd_sigma,
                    input.profile,
                    true,
                )
                .ok_or_else(|| anyhow!("could not prepare the ECD comparison grid"))?;
                let shifted: Vec<f64> = x.iter().map(|v| v + shift).collect();
                let calculated = interp_sorted(&shifted, &y, &grid);
                let (scaled, _) = scale_to_match(&observed, &calculated);
                let esi_reference = esi(&observed, &scaled).delta.abs();
                let uv_tolerance = 0.01 * uv_reference;
                if let Some(adjustment) = esi_tolerant_shift(
                    uv,
                    ecd,
                    &input.transitions,
                    &input.oscillator_strengths,
                    &input.rotatory_strengths,
                    uv_sigma,
                    shift,
                    uv_reference,
                    ecd_sigma,
                    esi_reference,
                    input.profile,
                    input.objective,
                    uv_tolerance,
                    5.0,
                    0.25,
                    input.sensitivity,
                ) {
                    shift = adjustment.shift;
                    sigma_ecd = Some(adjustment.sigma_ecd);
                    uv_similarity = Some(adjustment.uv_similarity);
                    shift_adjusted = true;
                    esi_before_adjustment = Some(esi_reference);
                }
            }
        } else if let Some(coarse) = fit_ecd_2d(
            &ecd.x,
            &ecd.y,
            &input.transitions,
            &input.rotatory_strengths,
            &coarse_sigma,
            &coarse_shift,
            input.profile,
            input.objective,
            input.sensitivity,
        ) {
            let fine_sigma = arange(
                (coarse.sigma - 0.03).max(0.03),
                coarse.sigma + 0.0301,
                0.005,
            );
            let fine_shift = arange(coarse.shift - 2.0, coarse.shift + 2.001, 0.25);
            let fit = fit_ecd_2d(
                &ecd.x,
                &ecd.y,
                &input.transitions,
                &input.rotatory_strengths,
                &fine_sigma,
                &fine_shift,
                input.profile,
                input.objective,
                input.sensitivity,
            )
            .unwrap_or(coarse);
            sigma_ecd = Some(fit.sigma);
            shift = fit.shift;
        }
    }

    if sigma_uv.is_none() && sigma_ecd.is_none() {
        bail!("no usable spectrum could be fitted; check the measured data and wavelength range");
    }
    if sigma_uv.is_none() {
        sigma_uv = sigma_ecd;
    }
    Ok(ElectronicAutoFitOutput {
        sigma_uv,
        sigma_ecd,
        shift,
        uv_similarity,
        ecd_fitted: input.ecd.is_some() && sigma_ecd.is_some(),
        shift_adjusted_for_esi: shift_adjusted,
        esi_before_adjustment,
    })
}
