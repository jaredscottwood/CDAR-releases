//! Validated ground-state optimization evidence from Gaussian LOG files.
use anyhow::{Context, Result, bail};
use regex::Regex;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

#[derive(Clone, Debug, Default)]
pub struct GaussianEvidence {
    pub source: PathBuf,
    pub atomic_numbers: Vec<u16>,
    pub coordinates: Vec<[f64; 3]>,
    pub connectivity: Vec<Vec<usize>>,
    pub connectivity_reported: bool,
    pub gibbs: Option<f64>,
    pub frequencies: Vec<f64>,
    pub imaginary_modes: usize,
    pub terminated_normally: bool,
    pub error_termination: bool,
    pub ground_state_optimization_completed: bool,
    pub mode_range: std::ops::Range<usize>,
    pub gibbs_line: Option<usize>,
    pub validation_errors: Vec<String>,
}

impl GaussianEvidence {
    pub fn validate_optimization(&self) -> Result<()> {
        if self.error_termination {
            bail!("Gaussian reported an error termination");
        }
        if !self.terminated_normally {
            bail!("calculation has not terminated normally");
        }
        if !self.ground_state_optimization_completed {
            bail!("no completed ground-state geometry optimization");
        }
        if !self.validation_errors.is_empty() {
            bail!("{}", self.validation_errors.join("; "));
        }
        if self.gibbs.is_none_or(|v| !v.is_finite()) {
            bail!("missing Gibbs free energy from the completed optimization calculation");
        }
        let n = self.atomic_numbers.len();
        if n < 2
            || n != self.coordinates.len()
            || self.atomic_numbers.iter().any(|z| !(1..=118).contains(z))
            || self.coordinates.iter().flatten().any(|v| !v.is_finite())
        {
            bail!("missing or incomplete optimized geometry");
        }
        if !self.connectivity_reported
            || self.connectivity.len() != n
            || !self.connectivity.iter().any(|v| !v.is_empty())
            || self.connectivity.iter().enumerate().any(|(i, ns)| {
                ns.iter()
                    .any(|&j| j >= n || j == i || !self.connectivity[j].contains(&i))
            })
        {
            bail!("missing or invalid Gaussian Initial Parameters bond table");
        }
        let expected = self.expected_modes();
        if self.frequencies.len() != expected || self.frequencies.iter().any(|v| !v.is_finite()) {
            bail!(
                "incomplete harmonic frequency data: expected {expected} modes, found {}",
                self.frequencies.len()
            );
        }
        if self.imaginary_modes > 0 || self.frequencies.iter().any(|v| *v <= 0.0) {
            bail!("optimized structure is not a minimum: non-positive vibrational frequencies");
        }
        Ok(())
    }

    pub fn expected_modes(&self) -> usize {
        let n = self.coordinates.len();
        if n < 2 {
            return 0;
        }
        let origin = self.coordinates[0];
        let delta = |p: [f64; 3]| std::array::from_fn::<_, 3, _>(|i| p[i] - origin[i]);
        let axis = self
            .coordinates
            .iter()
            .copied()
            .map(delta)
            .max_by(|a, b| norm2(*a).total_cmp(&norm2(*b)))
            .unwrap();
        let scale = norm2(axis);
        let linear = self.coordinates.iter().copied().map(delta).all(|p| {
            let cross = [
                axis[1] * p[2] - axis[2] * p[1],
                axis[2] * p[0] - axis[0] * p[2],
                axis[0] * p[1] - axis[1] * p[0],
            ];
            norm2(cross) <= 1e-12 * scale * scale
        });
        3 * n - if linear { 5 } else { 6 }
    }
}
fn norm2(p: [f64; 3]) -> f64 {
    p.iter().map(|v| v * v).sum()
}

pub fn parse_number(token: &str) -> Option<f64> {
    token
        .replace(['D', 'd'], "E")
        .parse::<f64>()
        .ok()
        .filter(|v| v.is_finite())
}

pub fn read_opt_freq(path: &Path) -> Result<GaussianEvidence> {
    let bytes =
        std::fs::read(path).with_context(|| format!("could not read {}", path.display()))?;
    let result = parse_opt_freq(&String::from_utf8_lossy(&bytes), path);
    result.validate_optimization()?;
    Ok(result)
}

/// Printed route sections identify the electronic state being optimized.
pub fn routes(lines: &[&str]) -> Vec<(usize, String)> {
    let mut result = Vec::new();
    let mut i = 0;
    while i < lines.len() {
        if lines[i].trim_start().starts_with('#') {
            let start = i;
            let mut route = String::new();
            while i < lines.len()
                && !lines[i].trim().is_empty()
                && !lines[i].trim_start().starts_with("---")
            {
                route.push_str(lines[i].trim());
                route.push(' ');
                i += 1;
            }
            result.push((start, route.to_lowercase()));
        } else {
            i += 1;
        }
    }
    result
}
pub fn has_keyword(route: &str, keyword: &str) -> bool {
    route
        .split(|c: char| !c.is_ascii_alphanumeric())
        .any(|s| s.eq_ignore_ascii_case(keyword))
}
fn excited_route(route: &str) -> bool {
    ["td", "tda", "cis", "eom"]
        .iter()
        .any(|k| has_keyword(route, k))
}

pub fn parse_opt_freq(text: &str, path: &Path) -> GaussianEvidence {
    let lines: Vec<&str> = text.lines().collect();
    let route_sections = routes(&lines);
    let mut route_sections = route_sections.iter().peekable();
    let mut current_route = String::new();
    let mut opt_start = 0;
    let mut ground_completed = false;
    let mut optimized_geometry = None;
    let mut frequencies = Vec::new();
    let mut mode_start = 0;
    let mut reported_imaginary = 0;
    let mut malformed_modes = false;
    let mut selected: Option<GaussianEvidence> = None;
    let mut last_activity = 0;
    let mut last_normal = None;
    let mut any_error = false;
    for (i, line) in lines.iter().enumerate() {
        if let Some((_, route)) = route_sections.next_if(|(index, _)| *index == i) {
            if let Some(evidence) = &mut selected
                && !evidence.terminated_normally
            {
                evidence
                    .validation_errors
                    .push("ground-state calculation has not terminated normally".into());
            }
            if ground_completed && last_normal.is_none_or(|n| n < last_activity) {
                ground_completed = false;
            }
            current_route = route.clone();
            last_activity = i;
            if has_keyword(route, "opt") {
                opt_start = i;
                ground_completed = false;
                optimized_geometry = None;
                selected = None;
                frequencies.clear();
                reported_imaginary = 0;
                malformed_modes = false;
            } else if !excited_route(route) {
                if has_keyword(route, "freq") {
                    selected = None;
                }
                // A subsequent job must print its own modes before its Gibbs
                // energy can qualify, regardless of its route spelling.
                frequencies.clear();
                reported_imaginary = 0;
                malformed_modes = false;
            }
        }
        if line.contains("Entering Gaussian System")
            || line.contains("SCF Done")
            || line.contains("Excited State")
            || line.contains("Rotatory Strengths")
            || line.contains("orientation:")
        {
            last_activity = i;
        }
        if line.contains("Optimization completed") {
            last_activity = i;
            ground_completed = has_keyword(&current_route, "opt") && !excited_route(&current_route);
            optimized_geometry = geometry(&lines[opt_start..=i]);
        }
        if line.contains("Optimization stopped") || line.contains("Convergence failure") {
            ground_completed = false;
            selected = None;
        }
        if line.contains("Harmonic frequencies") && !excited_route(&current_route) {
            selected = None;
            frequencies.clear();
            reported_imaginary = 0;
            malformed_modes = false;
            mode_start = i;
        }
        if line.trim().starts_with("Frequencies --") && !excited_route(&current_route) {
            selected = None;
            last_activity = i;
            if frequencies.is_empty() {
                mode_start = i;
            }
            if let Some((_, tail)) = line.split_once("--") {
                for token in tail.split_whitespace() {
                    if let Some(value) = parse_number(token) {
                        frequencies.push(value);
                    } else {
                        malformed_modes = true;
                    }
                }
            }
        }
        if line.to_lowercase().contains("imaginary frequencies") && !excited_route(&current_route) {
            let lower = line.to_lowercase();
            if let Some((prefix, _)) = lower.split_once("imaginary frequencies") {
                reported_imaginary = prefix
                    .split_whitespace()
                    .last()
                    .and_then(|s| s.parse().ok())
                    .unwrap_or(0);
            }
        }
        if line.contains("Sum of electronic and thermal Free Energies=")
            && !excited_route(&current_route)
        {
            last_activity = i;
            let gibbs = line
                .split_once('=')
                .and_then(|(_, s)| s.split_whitespace().next())
                .and_then(parse_number);
            let (atomic_numbers, coordinates) = geometry(&lines[opt_start..=i]).unwrap_or_default();
            let connectivity = gaussian_connectivity(&lines[opt_start..=i], atomic_numbers.len());
            let mut errors = Vec::new();
            // The printed harmonic modes followed by thermochemistry establish
            // this association. A literal `freq` route token is not evidence:
            // e.g. Opt=CalcAll also produces a harmonic analysis.
            if malformed_modes {
                errors.push("malformed harmonic frequency data".into());
            }
            if let Some((z, points)) = &optimized_geometry {
                if z != &atomic_numbers
                    || crate::dedup::superposition(points, &coordinates)
                        .is_none_or(|m| m.max_deviation > 0.001)
                {
                    errors.push(
                        "frequency analysis geometry does not match the completed optimization"
                            .into(),
                    );
                }
            } else {
                errors.push("missing optimized geometry at convergence".into());
            }
            selected = Some(GaussianEvidence {
                source: path.to_path_buf(),
                atomic_numbers,
                coordinates,
                connectivity_reported: connectivity.iter().any(|ns| !ns.is_empty()),
                connectivity,
                gibbs,
                frequencies: frequencies.clone(),
                imaginary_modes: reported_imaginary
                    .max(frequencies.iter().filter(|v| **v < 0.0).count()),
                ground_state_optimization_completed: ground_completed,
                mode_range: mode_start..i,
                gibbs_line: Some(i),
                validation_errors: errors,
                ..Default::default()
            });
        }
        if line.contains("Normal termination") {
            last_normal = Some(i);
            if let Some(evidence) = &mut selected {
                evidence.terminated_normally = true;
            }
        }
        if line.contains("Error termination") {
            any_error = true;
        }
    }
    let mut result = selected.unwrap_or_else(|| GaussianEvidence {
        source: path.to_path_buf(),
        ground_state_optimization_completed: ground_completed,
        terminated_normally: last_normal.is_some_and(|i| i > last_activity),
        validation_errors: vec![
            "missing complete harmonic analysis and Gibbs free energy from the optimization calculation".into(),
        ],
        ..Default::default()
    });
    result.terminated_normally &= last_normal.is_some_and(|i| i > last_activity);
    result.error_termination = any_error;
    result
}

fn last_gaussian_orientation(lines: &[&str], tag: &str) -> Option<(Vec<u16>, Vec<[f64; 3]>)> {
    let start = lines.iter().rposition(|line| line.contains(tag))?;
    let mut atoms = Vec::new();
    let mut points = Vec::new();
    let mut closed = false;
    for line in lines.iter().skip(start + 5) {
        if line.trim_start().starts_with("---") {
            closed = true;
            break;
        }
        let f: Vec<_> = line.split_whitespace().collect();
        if f.len() != 6 || f[0].parse::<usize>().ok()? != atoms.len() + 1 {
            return None;
        }
        atoms.push(f[1].parse().ok()?);
        points.push([
            parse_number(f[3])?,
            parse_number(f[4])?,
            parse_number(f[5])?,
        ]);
    }
    (closed && !points.is_empty()).then_some((atoms, points))
}

pub(crate) fn geometry(lines: &[&str]) -> Option<(Vec<u16>, Vec<[f64; 3]>)> {
    // These are two printed coordinate representations, never inferred geometry.
    let standard = lines
        .iter()
        .rposition(|l| l.contains("Standard orientation:"));
    let input = lines.iter().rposition(|l| l.contains("Input orientation:"));
    let tag = if standard > input {
        "Standard orientation:"
    } else {
        "Input orientation:"
    };
    last_gaussian_orientation(lines, tag)
}

fn gaussian_connectivity(lines: &[&str], atom_count: usize) -> Vec<Vec<usize>> {
    let mut connectivity = vec![Vec::new(); atom_count];
    if atom_count == 0 {
        return connectivity;
    }
    let Some(section) = lines.iter().enumerate().find_map(|(index, line)| {
        line.contains("Initial Parameters")
            .then_some(index)
            .filter(|index| {
                lines
                    .iter()
                    .skip(*index + 1)
                    .take(3)
                    .any(|next| next.contains("Angstroms and Degrees"))
            })
    }) else {
        return connectivity;
    };
    let Some(header) = lines
        .iter()
        .enumerate()
        .skip(section)
        .take(12)
        .find_map(|(index, line)| {
            (line.contains("Name") && line.contains("Definition")).then_some(index)
        })
    else {
        return connectivity;
    };

    static BOND_RE: OnceLock<Regex> = OnceLock::new();
    static ANGLE_OR_DIHEDRAL_RE: OnceLock<Regex> = OnceLock::new();
    let bond_re = BOND_RE.get_or_init(|| Regex::new(r"R\(\s*(\d+)\s*,\s*(\d+)\s*\)").unwrap());
    let angle_or_dihedral_re =
        ANGLE_OR_DIHEDRAL_RE.get_or_init(|| Regex::new(r"[AD]\(\d+").unwrap());
    for line in lines.iter().skip(header + 2).take(5000) {
        let trimmed = line.trim();
        if trimmed.starts_with("---")
            || (trimmed.starts_with('!')
                && angle_or_dihedral_re.is_match(trimmed)
                && !bond_re.is_match(trimmed))
        {
            break;
        }
        let Some(captures) = bond_re.captures(trimmed) else {
            if trimmed.contains("R(") {
                return Vec::new();
            }
            continue;
        };
        let Some((first, second)) = captures
            .get(1)
            .and_then(|value| value.as_str().parse::<usize>().ok())
            .zip(
                captures
                    .get(2)
                    .and_then(|value| value.as_str().parse::<usize>().ok()),
            )
        else {
            return Vec::new();
        };
        let Some((first, second)) = first.checked_sub(1).zip(second.checked_sub(1)) else {
            return Vec::new();
        };
        if first >= atom_count || second >= atom_count || first == second {
            return Vec::new();
        }
        connectivity[first].push(second);
        connectivity[second].push(first);
    }
    for neighbors in &mut connectivity {
        neighbors.sort_unstable();
        neighbors.dedup();
    }
    connectivity
}
