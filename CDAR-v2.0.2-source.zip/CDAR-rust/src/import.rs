//! Shared file-import accounting. Repeated files are distinct from duplicate geometries.
use crate::dedup::DedupResult;
use anyhow::Result;
use std::collections::BTreeSet;
use std::fmt::Write;
use std::path::{Path, PathBuf};

#[derive(Debug, Default)]
pub struct ImportReport {
    pub requested: usize,
    pub previous: usize,
    pub parsed: usize,
    pub already_loaded: Vec<PathBuf>,
    pub repeated_selection: Vec<PathBuf>,
    pub failures: Vec<(PathBuf, String)>,
    pub paths: Vec<PathBuf>,
    pub dedup: DedupResult,
}

impl ImportReport {
    pub fn new_retained(&self) -> usize {
        self.dedup
            .survivors
            .iter()
            .filter(|&&i| i >= self.previous)
            .count()
    }
    pub fn previous_removed(&self) -> usize {
        self.previous
            - self
                .dedup
                .survivors
                .iter()
                .filter(|&&i| i < self.previous)
                .count()
    }
    pub fn incoming_duplicates(&self) -> usize {
        self.dedup
            .duplicates
            .iter()
            .filter(|d| d.duplicate >= self.previous)
            .count()
    }
    pub fn incoming_rejected(&self) -> usize {
        self.failures.len()
            + self
                .dedup
                .rejected
                .iter()
                .filter(|(i, _)| *i >= self.previous)
                .count()
    }
    pub fn changed(&self) -> bool {
        self.new_retained() > 0 || self.previous_removed() > 0
    }
    pub fn text(&self) -> String {
        let kept = self.new_retained();
        let removed = self.incoming_duplicates();
        let rejected = self.incoming_rejected();
        let already = self.already_loaded.len();
        let repeated = self.repeated_selection.len();
        let total = self.dedup.survivors.len();
        let mut text = format!(
            "{} files selected: {kept} new conformers kept, {removed} duplicates removed, {rejected} rejected, {already} already loaded, {repeated} repeated selections. Dataset: {total} conformers.\n\n",
            self.requested
        );
        writeln!(text, "THIS IMPORT\nFiles selected: {}\nNew conformers kept: {kept}\nIncoming duplicate conformers removed: {removed}\nRejected files: {rejected}\nFiles already loaded: {already}\nRepeated selections in this import: {repeated}", self.requested).unwrap();
        writeln!(text, "\nDATASET\nConformers before import: {}\nPreviously loaded conformers removed: {}\nNew conformers kept: {kept}\nConformers after import: {total}", self.previous, self.previous_removed()).unwrap();
        text.push_str("\nDUPLICATE DETECTION\nAll five gates must pass: |ΔG| ≤ 0.20 kcal/mol; symmetry-aware RMSD ≤ 0.10 Å; maximum atom displacement ≤ 0.15 Å; frequency RMSD ≤ 2.0 cm⁻¹; maximum frequency difference ≤ 3.0 cm⁻¹.\n");
        if self.dedup.duplicates.is_empty() {
            text.push_str("No duplicate conformers removed.\n");
        }
        for (number, d) in self.dedup.duplicates.iter().enumerate() {
            let origin = if d.duplicate < self.previous {
                "previously loaded"
            } else {
                "this import"
            };
            writeln!(text, "\nMatch {}\nRemoved duplicate ({origin}): {}\nKept representative: {}\n|ΔG| = {:.6} kcal/mol; RMSD = {:.6} Å; maximum atom displacement = {:.6} Å; frequency RMSD = {:.6} cm⁻¹; maximum frequency difference = {:.6} cm⁻¹.", number + 1, self.paths[d.duplicate].display(), self.paths[d.representative].display(), d.energy_gap, d.geometry.rmsd, d.geometry.max_deviation, d.frequency_rmsd, d.frequency_max).unwrap();
        }
        if !self.failures.is_empty() || !self.dedup.rejected.is_empty() {
            text.push_str("\nREJECTED FILES\n");
            for (path, reason) in &self.failures {
                writeln!(text, "{}\nReason: {reason}\n", path.display()).unwrap();
            }
            for (i, reason) in &self.dedup.rejected {
                writeln!(text, "{}\nReason: {reason}\n", self.paths[*i].display()).unwrap();
            }
        }
        for (heading, paths) in [
            ("ALREADY LOADED — NOT IMPORTED AGAIN", &self.already_loaded),
            (
                "REPEATED SELECTIONS — NOT IMPORTED AGAIN",
                &self.repeated_selection,
            ),
        ] {
            if !paths.is_empty() {
                writeln!(text, "\n{heading}").unwrap();
                for path in paths {
                    writeln!(text, "{}", path.display()).unwrap();
                }
            }
        }
        if !self.dedup.survivors.is_empty() {
            text.push_str("\nCONFORMERS NOW IN DATASET\n");
            for &i in &self.dedup.survivors {
                writeln!(text, "{}", self.paths[i].display()).unwrap();
            }
        }
        if self.dedup.truncated_pairs > 0 {
            writeln!(
                text,
                "\n{} symmetry searches reached a limit; no unproven duplicate was removed.",
                self.dedup.truncated_pairs
            )
            .unwrap();
        }
        text
    }
}

fn path_key(path: &Path) -> PathBuf {
    std::fs::canonicalize(path)
        .unwrap_or_else(|_| std::path::absolute(path).unwrap_or_else(|_| path.to_path_buf()))
}

/// One entry point for button and drag-and-drop imports in both modes.
/// Retained conformers are compared together, while counts distinguish this
/// selection from the dataset that was already present.
pub fn import_conformers<T>(
    conformers: &mut Vec<T>,
    paths: Vec<PathBuf>,
    parse: impl Fn(&Path) -> Result<T>,
    source: impl Fn(&T) -> &Path,
    dedupe: impl Fn(&mut Vec<T>) -> DedupResult,
) -> ImportReport {
    let mut report = ImportReport {
        requested: paths.len(),
        previous: conformers.len(),
        ..Default::default()
    };
    let existing: BTreeSet<_> = conformers.iter().map(|c| path_key(source(c))).collect();
    let mut selected = BTreeSet::new();
    for path in paths {
        let key = path_key(&path);
        if !selected.insert(key.clone()) {
            report.repeated_selection.push(path);
        } else if existing.contains(&key) {
            report.already_loaded.push(path);
        } else {
            match parse(&path) {
                Ok(c) => {
                    conformers.push(c);
                    report.parsed += 1;
                }
                Err(e) => report.failures.push((path, e.to_string())),
            }
        }
    }
    report.paths = conformers.iter().map(|c| source(c).to_path_buf()).collect();
    report.dedup = dedupe(conformers);
    debug_assert_eq!(
        report.requested,
        report.new_retained()
            + report.incoming_duplicates()
            + report.incoming_rejected()
            + report.already_loaded.len()
            + report.repeated_selection.len()
    );
    debug_assert_eq!(
        conformers.len(),
        report.previous - report.previous_removed() + report.new_retained()
    );
    report
}
