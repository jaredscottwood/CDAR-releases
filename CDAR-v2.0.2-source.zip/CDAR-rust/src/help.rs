//! User-facing reference text retained from the Python edition.

pub const DEVELOPERS: &str = "Jared Wood and OpenAI GPT-5.6 Sol";

pub const ABOUT: &str = r#"CDAR — Circular Dichroism Analysis & Refinement

Absolute-configuration assignment by comparison of calculated and measured
circular dichroism spectra, in two modes:

Electronic (UV / ECD)
  Calculated excited-state spectra compared with measured UV absorbance and
  ECD. Bruhn et al. (SpecDis), Chirality 2013, 25, 243–249, is an important
  inspiration, but CDAR substantially extends that starting point with its own
  parsing, staged fitting, diagnostics, and workflow.

Vibrational (IR / VCD)
  Calculated harmonic spectra compared with measured IR absorbance and VCD,
  closely following the scientific framework of Sherer et al., J. Med. Chem.
  2014, 57, 477–494, while presenting it as an integrated native GUI workflow.

The cited methods are scientific inspirations rather than complete
specifications for CDAR. The application provides dedicated parsers, numerical
routines, plotting, background fitting, and SVG/PDF/PNG export.

Authors / developers: Jared Wood and OpenAI GPT-5.6 Sol"#;

pub const ECD_METHODOLOGY: &str = r#"ELECTRONIC CIRCULAR DICHROISM — METHODOLOGY

This mode assigns absolute configuration by comparing calculated and measured
UV absorbance alongside circular-dichroism (ECD) spectra. Bruhn,
Schaumlöffel, Hemberger and Bringmann, “SpecDis: Quantifying the
Comparison of Calculated and Experimental Electronic Circular Dichroism
Spectra,” Chirality 2013, 25, 243–249, provides important methodological
inspiration; CDAR is not a reimplementation of SpecDis.

CDAR substantially extends that starting point with native Gaussian
parsing, UV-anchored staged fitting, independently adjustable UV/ECD
bandwidths, multiple fitting objectives, constrained ECD shift refinement,
band diagnostics, and additional fit-quality and reliability reporting.

1. Calculated spectra

Each input Gaussian LOG must contain a completed ground-state geometry
optimization, its Gibbs free energy and harmonic frequencies, and a completed
time-dependent calculation with excitation energies, oscillator strengths,
and rotational strengths. Only normally terminated calculations with complete
data and an optimized minimum are accepted.

Rotational strengths can use velocity or length gauge; velocity is the
default. Conformers are Boltzmann weighted at the selected temperature using
the Gibbs free energies from their optimization calculations. Each transition
is broadened with a Gaussian or Lorentzian profile. A uniform wavelength
shift can account for a systematic offset. UV and ECD bandwidths can be fitted
independently.

Automatic conformer de-duplication

The optimization calculation supplies the Gibbs free energy, optimized
geometry, and harmonic frequencies. Gaussian's Initial Parameters bond table
defines the molecular graph.

A merge requires all of these conditions:
  |ΔG| ≤ 0.20 kcal/mol
  symmetry-aware Cartesian RMSD ≤ 0.10 Å
  largest aligned single-atom displacement ≤ 0.15 Å
  frequency RMSD ≤ 2.0 cm⁻¹
  largest individual frequency difference ≤ 3.0 cm⁻¹

Every atom participates, including methyl hydrogens and tert-butyl branches.
Atoms can be relabeled only when their elements and molecular connectivity
permit it. Geometries are aligned by translation and proper rotation, and
frequencies are compared in ascending order.

Conformers are considered from lowest Gibbs energy upward and compared with
retained representatives. Each distinct minimum contributes once to the
Boltzmann distribution. Import diagnostics identify duplicate conformers and
the representatives kept.

The ECD unit selector defaults to millidegrees and can instead label values as
molar ellipticity (deg·cm²·dmol⁻¹). It does not numerically convert between
those units: imported data must already use the selected unit because a valid
conversion requires concentration and optical path length.

2. Fitting bandwidth and shift

Automatic fitting determines the UV bandwidth and shift, transfers that shift
to ECD, and then fits ECD bandwidth while testing both the calculated spectrum
and its mirror image. A small ECD-driven shift refinement is accepted only if
it does not reduce UV similarity by more than one percent relative.

Auto-Fit is intended as a reproducible starting point rather than a substitute
for inspection. After it completes, inspect the UV/ECD overlays and use the
available bandwidth, global-shift, and display-scale controls for modest fine
tuning to obtain the most scientifically defensible fit. Recheck UV similarity,
the signed ECD metrics, band coverage, and enantiomer discrimination after each
adjustment. After Auto-Fit completes successfully, calculated UV, calculated
ECD, and enantiomer legends append “(fitted)”. Resetting the fit or changing a
fit input restores the plain labels until Auto-Fit succeeds again.

Available objectives are peak-shape, cross-section, least-squares, and cosine
similarity. Peak-shape first matches the number of considerable bands and then
optimizes agreement. Cross-section minimizes the area between curves.
Least-squares minimizes pointwise RMS deviation. Cosine maximizes the
normalized dot product. Peak-shape and cross-section are generally preferable
when broadening could hide genuine band-shape disagreement.

Unlike VCD mode, ECD does not apply independent per-band shifts, so the
displayed enantiomer is always the exact mirror of the calculated curve.

3. Similarity and ESI

UV agreement is cosine similarity. Signed ECD uses a SpecDis-inspired same-sign
similarity S(MSI), comparing positive and negative regions separately and
weighting each by its share of intensity. The enantiomeric similarity index is

  ESI = S(MSI, calculated) − S(MSI, enantiomer)

It ranges from −1 to +1. Positive values favor the calculated configuration;
negative values favor its enantiomer. Values near zero mean the data do not
distinguish the hypotheses.

The component metrics are calculated as follows. Let fᵢ and gᵢ be the measured
and calculated ECD values at grid point i, and let

  A = Σᵢ (|fᵢ| + |gᵢ|)

The positive and negative same-sign intensity fractions are

  φ++ = Σ(fᵢ + gᵢ) / A       where fᵢ > 0 and gᵢ > 0
  φ−− = Σ(|fᵢ| + |gᵢ|) / A  where fᵢ < 0 and gᵢ < 0

Sign agreement is φ++ + φ−−: the fraction of the combined absolute intensity
that lies in regions where measured and calculated signs agree. S++ and S−−
are cosine similarities calculated only within their corresponding same-sign
regions, and

  S(MSI) = φ++ S++ + φ−− S−−

Shape where signed is S(MSI) / (φ++ + φ−−), or zero when sign agreement is
zero. It is therefore the intensity-weighted shape similarity conditional on
the signs already agreeing. A high shape-where-signed value together with low
sign agreement means that the matching-sign pieces have similar shapes, but a
large fraction of spectral intensity still has the wrong sign.

The fit-quality ceiling is S(MSI, calculated) + S(MSI, enantiomer).
Discrimination is ESI divided by that ceiling when the denominator is
nonzero. This separates relative preference between the two hypotheses from
their overall ability to fit the data. Reliability tiers use |discrimination|
thresholds of 0.75, 0.45, and 0.20.

Result colors are interpretation aids: paired S(MSI) values color the clearly
higher hypothesis green and the lower one red (both amber when separated by
less than 0.05). Other green/amber thresholds are 0.90/0.75 for UV cosine,
0.20/0.05 for |ESI|, 0.75/0.45 for the fit-quality ceiling, 0.45/0.20 for
|discrimination|, 0.65/0.35 for sign agreement, and 0.60/0.35 for shape where
signed. Values below the amber threshold are red. These thresholds and the
reliability tiers are software guidance, not literature quantities. Similarity
scores supplement, rather than replace, inspection of band coverage and
scientific judgment.

Reference

Bruhn, T.; Schaumlöffel, A.; Hemberger, Y.; Bringmann, G. SpecDis:
Quantifying the Comparison of Calculated and Experimental Electronic Circular
Dichroism Spectra. Chirality 2013, 25, 243–249. DOI: 10.1002/chir.22138"#;

pub const VCD_METHODOLOGY: &str = r#"VIBRATIONAL CIRCULAR DICHROISM — METHODOLOGY

This mode assigns absolute configuration by comparing calculated and measured
IR absorbance alongside vibrational circular-dichroism (VCD) spectra. Its
scientific workflow closely follows Sherer et al., “Systematic Approach to
Conformational Sampling for Assigning Absolute Configuration Using Vibrational
Circular Dichroism,”
J. Med. Chem. 2014, 57, 477–494.

Unlike the more substantially extended ECD workflow, this mode intentionally
stays close to the published VCD procedure. CDAR's principal contribution here
is an integrated native GUI for loading calculations, fitting, inspection,
assignment, and export, with explicit handling of the few implementation
differences described below.

1. Calculated spectra

Each input Gaussian LOG must contain a completed ground-state geometry
optimization, its Gibbs free energy, and complete harmonic frequencies, IR
dipole strengths, and VCD rotational strengths. Only normally terminated
calculations with complete data and an optimized minimum are accepted.

Conformers are Boltzmann weighted using the Gibbs free energies from their
optimization calculations at 298.15 K by default. Modes are represented by
Lorentzian bands. The published defaults are a 0.98 frequency scale factor
and 6 cm⁻¹ half-width; CDAR can optimize both against measured IR absorbance,
whose intensity is independent of enantiomer.

Automatic conformer de-duplication

The optimization calculation supplies the Gibbs free energy, optimized
geometry, and harmonic frequencies. Gaussian's Initial Parameters bond table
defines the molecular graph.

A merge requires all of these conditions:
  |ΔG| ≤ 0.20 kcal/mol
  symmetry-aware Cartesian RMSD ≤ 0.10 Å
  largest aligned single-atom displacement ≤ 0.15 Å
  frequency RMSD ≤ 2.0 cm⁻¹
  largest individual frequency difference ≤ 3.0 cm⁻¹

Every atom participates, including methyl hydrogens and tert-butyl branches.
Atoms can be relabeled only when their elements and molecular connectivity
permit it. Geometries are aligned by translation and proper rotation, and
frequencies are compared in ascending order.

Conformers are considered from lowest Gibbs energy upward and compared with
retained representatives. Each distinct minimum contributes once to the
Boltzmann distribution. Import diagnostics identify duplicate conformers and
the representatives kept.

2. Comparison

Measured and calculated spectra are interpolated to a common integer-
wavenumber grid and normalized: IR to [0, 1] and VCD to [−1, 1]. Agreement is
quantified with the same-sign overlap similarity:

  IR  = Ico / (Icc + Ioo − Ico)
  VCD = Ico / (Icc + Ioo − |Ico|)

Icc and Ioo are self-overlaps and Ico is cross-overlap. Exact agreement scores
1; an exact VCD mirror scores −1.

Harmonic-frequency error varies by mode, so each calculated band region may
shift independently toward lower frequency by up to the selected maximum
(20 cm⁻¹ by default). The as-calculated spectrum and its enantiomer are fitted
independently under the same freedom. After fitting, they therefore need not be
exact mirror images. After Auto-Fit completes successfully, legends append
“(fitted)” to calculated IR, calculated VCD, and the independently shifted
enantiomer. Before Auto-Fit, matched previews retain the plain “Calculated” and
“Enantiomer” labels.

3. Enantiomeric similarity index

  ESI = VCD similarity (as calculated) − VCD similarity (enantiomer)

Positive ESI favors the as-calculated spectrum and negative ESI favors its
enantiomer. CDAR displays high, moderate, low, and not-reliable tiers at |ESI|
thresholds 0.6, 0.3, and 0.05. These graduated tiers are software guidance.
The original protocol notes typical good similarities of roughly 0.5–0.8 for
IR and 0.2–0.5 for VCD and treats |ESI| below about 0.1 cautiously. A convincing
ESI still requires an acceptable IR fit.

In the Fit results colors, IR values are green at 0.50 or above, amber at 0.30–0.50,
and red below 0.30. The higher of the two VCD hypotheses is green and the lower
is red when they differ by at least 0.05; otherwise both are amber. |ESI| is
green at 0.30 or above, amber from 0.05 to 0.30, and red below 0.05. These are
visual interpretation aids, not additional literature-derived criteria.

4. Practical notes

The default analysis window is 1000–1600 cm⁻¹. The view and analysis window are
independent. Duplicate removal runs automatically when Gaussian LOG files are
imported, before populations and spectra are calculated. Import messages
identify rejected files and explain why they did not qualify.

Reference

Sherer, E. C.; Lee, C. H.; Shpungin, J.; Cuff, J. F.; Da, C.; Ball, R.;
Bach, R.; Crespo, A.; Gong, X.; Welch, C. J. Systematic Approach to
Conformational Sampling for Assigning Absolute Configuration Using Vibrational
Circular Dichroism. J. Med. Chem. 2014, 57, 477–494.
DOI: 10.1021/jm401600u"#;

/// Let the window wrap prose to its current width, while preserving equations
/// and indented conditions as distinct lines.
pub fn reflow_methodology(text: &str) -> String {
    text.split("\n\n")
        .map(|paragraph| {
            if paragraph.lines().any(|line| line.starts_with("  ")) {
                paragraph.to_string()
            } else {
                paragraph.split_whitespace().collect::<Vec<_>>().join(" ")
            }
        })
        .collect::<Vec<_>>()
        .join("\n\n")
}
