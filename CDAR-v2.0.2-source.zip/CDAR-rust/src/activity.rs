//! Bounded per-mode activity history. The footer uses only the newest entry.
use std::collections::VecDeque;

const MAX_ENTRIES: usize = 200;
const MAX_BYTES: usize = 1024 * 1024;
const TRUNCATED: &str = "\n[This entry exceeded the log size limit and was shortened.]";
const EVICTED: &str =
    "[Earlier activity was removed to keep the log within its history limit.]\n\n";

pub(crate) struct ActivityLog {
    entries: VecDeque<String>,
    bytes: usize,
    removed: bool,
    text: String,
}

impl ActivityLog {
    pub fn new(initial: &str) -> Self {
        let mut log = Self {
            entries: VecDeque::new(),
            bytes: 0,
            removed: false,
            text: String::new(),
        };
        log.push(initial.into());
        log
    }

    pub fn push(&mut self, mut message: String) {
        if message.is_empty() {
            return;
        }
        // Keep room for the delimiter, even when a single import report is huge.
        if message.len() + 2 > MAX_BYTES {
            message.truncate(message.floor_char_boundary(MAX_BYTES - 2 - TRUNCATED.len()));
            message.push_str(TRUNCATED);
        }
        self.bytes += message.len() + 2;
        self.entries.push_back(message);
        while self.entries.len() > MAX_ENTRIES || self.bytes > MAX_BYTES {
            let oldest = self.entries.pop_front().expect("history is nonempty");
            self.bytes -= oldest.len() + 2;
            self.removed = true;
        }
        // Cache the complete text once per event, not on every rendered frame.
        self.text.clear();
        if self.removed {
            self.text.push_str(EVICTED);
        }
        for (index, entry) in self.entries.iter().enumerate() {
            if index > 0 {
                self.text.push_str("\n\n");
            }
            self.text.push_str(entry);
        }
    }

    pub fn latest(&self) -> &str {
        self.entries.back().map_or("", String::as_str)
    }

    pub fn text(&self) -> &str {
        &self.text
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn history_retains_multiline_reports_and_repeated_actions_in_order() {
        let mut log = ActivityLog::new("Ready");
        log.push("Imported files\nKept: alpha\nRejected: beta".into());
        log.push("Fit reset.".into());
        log.push("Fit reset.".into());
        assert_eq!(log.latest(), "Fit reset.");
        assert_eq!(
            log.text(),
            "Ready\n\nImported files\nKept: alpha\nRejected: beta\n\nFit reset.\n\nFit reset."
        );
    }

    #[test]
    fn history_limits_keep_recent_events_and_bound_large_unicode_reports() {
        let mut log = ActivityLog::new("Ready");
        for index in 0..MAX_ENTRIES + 10 {
            log.push(format!("Event {index}"));
        }
        assert_eq!(log.entries.len(), MAX_ENTRIES);
        assert_eq!(log.entries.front().unwrap(), "Event 10");
        assert!(log.text().starts_with(EVICTED));
        let report = "ΔG ≤ 0.20 kcal/mol\n".repeat(MAX_BYTES / 10);
        log.push(report);
        assert!(log.latest().ends_with(TRUNCATED));
        assert!(log.bytes <= MAX_BYTES);
        assert!(log.text().len() <= MAX_BYTES + EVICTED.len());
        log.push("Export complete.".into());
        assert_eq!(log.latest(), "Export complete.");
        assert_eq!(log.entries.len(), 1);
        assert!(log.text().ends_with("Export complete."));
    }
}
