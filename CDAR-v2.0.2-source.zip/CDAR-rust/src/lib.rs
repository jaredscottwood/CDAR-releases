//! Scientific and application core for CDAR.
//!
//! The numerical code is intentionally independent of the GUI.  That keeps
//! the Gaussian parsers, fitting algorithms, and similarity metrics easy
//! to regression-test against the original Python implementation.

mod activity;
pub mod app;
pub mod assets;
pub mod dedup;
pub mod electronic;
pub mod export;
pub mod gaussian;
pub mod help;
pub mod import;
pub mod math;
mod state;
pub mod vibrational;

pub const APP_TITLE: &str = "CDAR: Circular Dichroism Analysis & Refinement";
