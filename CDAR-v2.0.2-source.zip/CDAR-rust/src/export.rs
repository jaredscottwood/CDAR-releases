//! Publication-style figure and tabular export.
//!
//! Figures are authored once as SVG. SVG is written directly, converted to a
//! true vector PDF by `svg2pdf`, or rasterized at the requested DPI by
//! `resvg`. This keeps all three output formats visually consistent without a
//! native Cairo dependency.

use std::collections::BTreeSet;
use std::fmt::Write as _;
use std::fs;
use std::path::Path;

use anyhow::{Context, Result, anyhow, bail};

use crate::electronic::{
    ELECTRONIC_CALCULATED_FITTED_LABEL, ELECTRONIC_ENANTIOMER_FITTED_LABEL, ElectronicDataset,
    Spectrum,
};
use crate::math::{
    AxisTicks, format_axis_tick, linspace, max_abs, min_max, nice_axis_range, resample,
    rounded_axis_ticks,
};
use crate::vibrational::{
    VIB_CALCULATED_FITTED_LABEL, VIB_ENANTIOMER_FITTED_LABEL, VibDataset, VibMatchedCurves,
};

const SVG_DPI: f64 = 96.0;
const WIDTH: f64 = 6.6 * SVG_DPI;
const HEIGHT: f64 = 5.8 * SVG_DPI;

#[derive(Clone, Debug, Default)]
pub struct LineSeries {
    pub label: String,
    pub color: String,
    pub points: Vec<[f64; 2]>,
    pub width: f64,
    pub dashed: bool,
}

impl LineSeries {
    pub fn new(label: impl Into<String>, color: impl Into<String>, x: &[f64], y: &[f64]) -> Self {
        Self {
            label: label.into(),
            color: color.into(),
            points: x
                .iter()
                .copied()
                .zip(y.iter().copied())
                .map(|(x, y)| [x, y])
                .collect(),
            width: 1.9,
            dashed: false,
        }
    }

    pub fn dashed(mut self) -> Self {
        self.dashed = true;
        self.width = 1.6;
        self
    }
}

#[derive(Clone, Debug, Default)]
pub struct StickSeries {
    pub color: String,
    pub x: Vec<f64>,
    pub height: Vec<f64>,
    pub positive_only: bool,
}

#[derive(Clone, Debug, Default)]
pub struct Marker {
    pub x: f64,
    pub y: f64,
    pub upward: bool,
    pub color: String,
}

#[derive(Clone, Debug)]
pub struct PanelSpec {
    pub y_label: String,
    pub x_label: Option<String>,
    pub x_range: (f64, f64),
    pub x_tick_quantum: f64,
    pub y_tick_minimum: f64,
    pub scientific_y: bool,
    pub reverse_x: bool,
    pub symmetric_y: bool,
    pub zero_line: bool,
    pub lines: Vec<LineSeries>,
    pub sticks: Vec<StickSeries>,
    pub markers: Vec<Marker>,
}

#[derive(Clone, Debug)]
pub struct FigureSpec {
    pub title: String,
    pub show_legend: bool,
    pub panels: Vec<PanelSpec>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum FigureCorner {
    LeftTop,
    RightTop,
    LeftBottom,
    RightBottom,
}

impl FigureCorner {
    fn name(self) -> &'static str {
        match self {
            Self::LeftTop => "left-top",
            Self::RightTop => "right-top",
            Self::LeftBottom => "left-bottom",
            Self::RightBottom => "right-bottom",
        }
    }
}

fn xml_escape(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

fn legend_rect(
    corner: FigureCorner,
    area: (f64, f64, f64, f64),
    width: f64,
    height: f64,
) -> (f64, f64, f64, f64) {
    let (left, top, panel_width, panel_height) = area;
    let inset = 10.0;
    let x = match corner {
        FigureCorner::LeftTop | FigureCorner::LeftBottom => left + inset,
        FigureCorner::RightTop | FigureCorner::RightBottom => left + panel_width - width - inset,
    };
    let y = match corner {
        FigureCorner::LeftTop | FigureCorner::RightTop => top + inset,
        FigureCorner::LeftBottom | FigureCorner::RightBottom => top + panel_height - height - inset,
    };
    (x, y, width, height)
}

fn best_legend_corner(
    panel: &PanelSpec,
    y_range: (f64, f64),
    area: (f64, f64, f64, f64),
    legend_size: (f64, f64),
) -> FigureCorner {
    let (left, top, width, height) = area;
    let (x0, x1) = panel.x_range;
    let (xlo, xhi) = (x0.min(x1), x0.max(x1));
    let (ylo, yhi) = y_range;
    let map_x = |x: f64| {
        let fraction = if panel.reverse_x {
            (xhi - x) / (xhi - xlo)
        } else {
            (x - xlo) / (xhi - xlo)
        };
        left + fraction * width
    };
    let map_y = |y: f64| top + (yhi - y) / (yhi - ylo) * height;
    let candidates = [
        FigureCorner::RightTop,
        FigureCorner::LeftTop,
        FigureCorner::RightBottom,
        FigureCorner::LeftBottom,
    ];
    candidates
        .into_iter()
        .min_by_key(|corner| {
            let (x, y, w, h) = legend_rect(*corner, area, legend_size.0, legend_size.1);
            let padding = 7.0;
            let contains = |px: f64, py: f64| {
                px >= x - padding
                    && px <= x + w + padding
                    && py >= y - padding
                    && py <= y + h + padding
            };
            let line_hits = panel
                .lines
                .iter()
                .flat_map(|line| &line.points)
                .filter(|point| {
                    point[0] >= xlo
                        && point[0] <= xhi
                        && point[1].is_finite()
                        && contains(map_x(point[0]), map_y(point[1]))
                })
                .count();
            let marker_hits = panel
                .markers
                .iter()
                .filter(|marker| contains(map_x(marker.x), map_y(marker.y)))
                .count()
                * 8;
            let stick_hits = panel
                .sticks
                .iter()
                .flat_map(|sticks| sticks.x.iter())
                .filter(|value| {
                    **value >= xlo
                        && **value <= xhi
                        && map_x(**value) >= x - padding
                        && map_x(**value) <= x + w + padding
                })
                .count();
            line_hits + marker_hits + stick_hits
        })
        .unwrap_or(FigureCorner::RightTop)
}

fn panel_y_ticks(panel: &PanelSpec) -> AxisTicks {
    let (xlow, xhigh) = (
        panel.x_range.0.min(panel.x_range.1),
        panel.x_range.0.max(panel.x_range.1),
    );
    let mut values = Vec::new();
    for line in &panel.lines {
        values.extend(
            line.points
                .iter()
                .filter(|point| point[0] >= xlow && point[0] <= xhigh && point[1].is_finite())
                .map(|point| point[1]),
        );
    }
    if values.is_empty() {
        values.extend(
            panel
                .sticks
                .iter()
                .flat_map(|sticks| sticks.height.iter().copied()),
        );
    }
    let (mut low, mut high) = min_max(&values).unwrap_or((-1.0, 1.0));
    if panel.zero_line {
        low = low.min(0.0);
        high = high.max(0.0);
    }
    if panel.symmetric_y {
        let amplitude = low.abs().max(high.abs()).max(1e-12) * 1.08;
        nice_axis_range(-amplitude, amplitude, 7, panel.y_tick_minimum, true, true)
    } else {
        let span = if high > low {
            high - low
        } else {
            high.abs().max(1.0)
        };
        if low >= 0.0 {
            low = 0.0;
        } else {
            low -= span * 0.08;
        }
        high += span * 0.08;
        nice_axis_range(
            low,
            high,
            6,
            panel.y_tick_minimum,
            false,
            panel.zero_line || low >= 0.0,
        )
    }
}

fn svg_path(
    points: &[[f64; 2]],
    panel: &PanelSpec,
    y_range: (f64, f64),
    area: (f64, f64, f64, f64),
) -> String {
    let (left, top, width, height) = area;
    let (x0, x1) = panel.x_range;
    let (xlo, xhi) = (x0.min(x1), x0.max(x1));
    let (ylo, yhi) = y_range;
    let map_x = |x: f64| {
        let fraction = if panel.reverse_x {
            (xhi - x) / (xhi - xlo)
        } else {
            (x - xlo) / (xhi - xlo)
        };
        left + fraction * width
    };
    let map_y = |y: f64| top + (yhi - y) / (yhi - ylo) * height;
    let mut path = String::new();
    let mut drawing = false;
    for point in points {
        if point[0] < xlo || point[0] > xhi || !point[0].is_finite() || !point[1].is_finite() {
            drawing = false;
            continue;
        }
        let command = if drawing { 'L' } else { 'M' };
        let _ = write!(
            path,
            "{command}{:.2},{:.2}",
            map_x(point[0]),
            map_y(point[1])
        );
        drawing = true;
    }
    path
}

pub fn figure_svg(spec: &FigureSpec) -> String {
    let mut svg = String::new();
    let _ = write!(
        svg,
        r##"<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}"><rect width="100%" height="100%" fill="white"/><style>text{{font-family:Arial,Helvetica,sans-serif;fill:#1b2733}}.tick{{font-size:10px;fill:#526173}}.label{{font-size:12px}}.legend{{font-size:9px}}</style>"##,
    );
    if !spec.title.is_empty() {
        let _ = write!(
            svg,
            r##"<text x="{:.1}" y="24" font-size="15" font-weight="700" text-anchor="middle">{}</text>"##,
            WIDTH / 2.0,
            xml_escape(&spec.title)
        );
    }
    let count = spec.panels.len().max(1);
    let left = 78.0;
    let right = 18.0;
    let top = 42.0;
    let bottom = 55.0;
    let gap = 32.0;
    let panel_height =
        (HEIGHT - top - bottom - gap * (count.saturating_sub(1)) as f64) / count as f64;
    let panel_width = WIDTH - left - right;
    for (panel_index, panel) in spec.panels.iter().enumerate() {
        let panel_top = top + panel_index as f64 * (panel_height + gap);
        let area = (left, panel_top, panel_width, panel_height);
        let y_ticks = panel_y_ticks(panel);
        let y_range = (y_ticks.low, y_ticks.high);
        let (ylo, yhi) = y_range;
        let (x0, x1) = panel.x_range;
        let (xlo, xhi) = (x0.min(x1), x0.max(x1));
        let map_x = |x: f64| {
            let fraction = if panel.reverse_x {
                (xhi - x) / (xhi - xlo)
            } else {
                (x - xlo) / (xhi - xlo)
            };
            left + fraction * panel_width
        };
        let map_y = |y: f64| panel_top + (yhi - y) / (yhi - ylo) * panel_height;

        let _ = write!(
            svg,
            r##"<rect x="{left}" y="{panel_top}" width="{panel_width}" height="{panel_height}" fill="white" stroke="#95a2b3" stroke-width="0.8"/>"##
        );
        let x_ticks = rounded_axis_ticks(xlo, xhi, 6, panel.x_tick_quantum, panel.x_tick_quantum);
        for x_value in x_ticks.values {
            let x = map_x(x_value);
            let _ = write!(
                svg,
                r##"<line x1="{x:.2}" y1="{:.2}" x2="{x:.2}" y2="{:.2}" stroke="#95a2b3" stroke-width="0.7"/><text class="tick" x="{x:.2}" y="{:.2}" text-anchor="middle">{}</text>"##,
                panel_top + panel_height,
                panel_top + panel_height + 4.0,
                panel_top + panel_height + 16.0,
                format_axis_tick(x_value, x_ticks.step, false)
            );
        }
        for value in y_ticks.values {
            let y = map_y(value);
            let _ = write!(
                svg,
                r##"<line x1="{:.2}" y1="{y:.2}" x2="{left:.2}" y2="{y:.2}" stroke="#95a2b3" stroke-width="0.7"/><text class="tick" x="{:.2}" y="{:.2}" text-anchor="end">{}</text>"##,
                left - 4.0,
                left - 7.0,
                y + 3.5,
                format_axis_tick(value, y_ticks.step, panel.scientific_y)
            );
        }
        if panel.zero_line && ylo < 0.0 && yhi > 0.0 {
            let y = map_y(0.0);
            let _ = write!(
                svg,
                r##"<line x1="{left}" y1="{y:.2}" x2="{:.2}" y2="{y:.2}" stroke="#c2c9d2" stroke-width="0.9"/>"##,
                left + panel_width
            );
        }
        let _ = write!(
            svg,
            r##"<text class="label" transform="translate(18 {:.2}) rotate(-90)" text-anchor="middle">{}</text>"##,
            panel_top + panel_height / 2.0,
            xml_escape(&panel.y_label)
        );
        if let Some(label) = &panel.x_label {
            let _ = write!(
                svg,
                r##"<text class="label" x="{:.2}" y="{:.2}" text-anchor="middle">{}</text>"##,
                left + panel_width / 2.0,
                panel_top + panel_height + 38.0,
                xml_escape(label)
            );
        }

        let line_peak = panel
            .lines
            .iter()
            .flat_map(|line| line.points.iter().map(|point| point[1]))
            .fold(0.0_f64, |peak, value| peak.max(value.abs()))
            .max(1.0);
        for sticks in &panel.sticks {
            let stick_peak = max_abs(&sticks.height);
            if stick_peak <= 0.0 {
                continue;
            }
            for (&x_value, &height) in sticks.x.iter().zip(&sticks.height) {
                if x_value < xlo || x_value > xhi {
                    continue;
                }
                let scaled = if sticks.positive_only {
                    height.abs()
                } else {
                    height
                } / stick_peak
                    * line_peak
                    * 0.9;
                let _ = write!(
                    svg,
                    r##"<line x1="{:.2}" y1="{:.2}" x2="{:.2}" y2="{:.2}" stroke="{}" stroke-opacity="0.3" stroke-width="1"/>"##,
                    map_x(x_value),
                    map_y(0.0),
                    map_x(x_value),
                    map_y(scaled),
                    xml_escape(&sticks.color)
                );
            }
        }
        for line in &panel.lines {
            let path = svg_path(&line.points, panel, y_range, area);
            if !path.is_empty() {
                let dash = if line.dashed {
                    r##" stroke-dasharray="5,2""##
                } else {
                    ""
                };
                let _ = write!(
                    svg,
                    r##"<path d="{path}" fill="none" stroke="{}" stroke-width="{}"{dash}/>"##,
                    xml_escape(&line.color),
                    line.width
                );
            }
        }
        for marker in &panel.markers {
            if marker.x < xlo || marker.x > xhi {
                continue;
            }
            let x = map_x(marker.x);
            let y = map_y(marker.y);
            let points = if marker.upward {
                format!(
                    "{:.2},{:.2} {:.2},{:.2} {:.2},{:.2}",
                    x,
                    y - 5.0,
                    x - 4.0,
                    y + 3.0,
                    x + 4.0,
                    y + 3.0
                )
            } else {
                format!(
                    "{:.2},{:.2} {:.2},{:.2} {:.2},{:.2}",
                    x,
                    y + 5.0,
                    x - 4.0,
                    y - 3.0,
                    x + 4.0,
                    y - 3.0
                )
            };
            let _ = write!(
                svg,
                r##"<polygon points="{points}" fill="white" stroke="{}" stroke-width="1.3"/>"##,
                xml_escape(&marker.color)
            );
        }

        if spec.show_legend {
            let mut seen = BTreeSet::new();
            let legend: Vec<&LineSeries> = panel
                .lines
                .iter()
                .filter(|line| !line.label.is_empty() && seen.insert(line.label.clone()))
                .collect();
            if !legend.is_empty() {
                let longest = legend
                    .iter()
                    .map(|line| line.label.chars().count())
                    .max()
                    .unwrap_or(0) as f64;
                let legend_width = (50.0 + longest * 5.1).clamp(96.0, 154.0);
                let legend_height = 12.0 + legend.len() as f64 * 15.0;
                let corner =
                    best_legend_corner(panel, y_range, area, (legend_width, legend_height));
                let (legend_x, legend_y, _, _) =
                    legend_rect(corner, area, legend_width, legend_height);
                let _ = write!(svg, r##"<g data-legend-corner="{}">"##, corner.name());
                for (index, line) in legend.iter().enumerate() {
                    let x = legend_x + 8.0;
                    let y = legend_y + 12.0 + index as f64 * 15.0;
                    let dash = if line.dashed {
                        r##" stroke-dasharray="5,2""##
                    } else {
                        ""
                    };
                    let _ = write!(
                        svg,
                        r##"<line x1="{x:.2}" y1="{y:.2}" x2="{:.2}" y2="{y:.2}" stroke="{}" stroke-width="{}"{dash}/><text class="legend" x="{:.2}" y="{:.2}">{}</text>"##,
                        x + 22.0,
                        xml_escape(&line.color),
                        line.width,
                        x + 27.0,
                        y + 3.2,
                        xml_escape(&line.label)
                    );
                }
                svg.push_str("</g>");
            }
        }
    }
    svg.push_str("</svg>");
    svg
}

pub fn write_figure(spec: &FigureSpec, path: impl AsRef<Path>, dpi: u32) -> Result<()> {
    let path = path.as_ref();
    let svg = figure_svg(spec);
    match path
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or("")
        .to_ascii_lowercase()
        .as_str()
    {
        "svg" => {
            fs::write(path, svg).with_context(|| format!("could not write {}", path.display()))
        }
        "pdf" => {
            let mut options = svg2pdf::usvg::Options::default();
            options.fontdb_mut().load_system_fonts();
            let tree = svg2pdf::usvg::Tree::from_str(&svg, &options)
                .map_err(|error| anyhow!("could not parse the generated SVG: {error}"))?;
            let pdf = svg2pdf::to_pdf(
                &tree,
                svg2pdf::ConversionOptions::default(),
                svg2pdf::PageOptions::default(),
            )
            .map_err(|error| anyhow!("could not convert the figure to PDF: {error}"))?;
            fs::write(path, pdf).with_context(|| format!("could not write {}", path.display()))
        }
        "png" => {
            let mut options = resvg::usvg::Options::default();
            options.fontdb_mut().load_system_fonts();
            let tree = resvg::usvg::Tree::from_str(&svg, &options)
                .map_err(|error| anyhow!("could not parse the generated SVG: {error}"))?;
            let scale = dpi.max(72) as f32 / SVG_DPI as f32;
            let size = tree.size();
            let width = (size.width() * scale).ceil() as u32;
            let height = (size.height() * scale).ceil() as u32;
            let mut pixmap = resvg::tiny_skia::Pixmap::new(width, height)
                .ok_or_else(|| anyhow!("the requested raster figure is too large"))?;
            let mut target = pixmap.as_mut();
            resvg::render(
                &tree,
                resvg::tiny_skia::Transform::from_scale(scale, scale),
                &mut target,
            );
            pixmap
                .save_png(path)
                .with_context(|| format!("could not write {}", path.display()))
        }
        _ => bail!("figure extension must be .png, .pdf, or .svg"),
    }
}

fn scaled(values: &[f64], factor: f64) -> Vec<f64> {
    values.iter().map(|value| value * factor).collect()
}

pub fn electronic_figure(dataset: &mut ElectronicDataset) -> FigureSpec {
    let curves = dataset.curves();
    let range = (
        dataset.wavelength_min.min(dataset.wavelength_max),
        dataset.wavelength_min.max(dataset.wavelength_max),
    );
    let mut uv_lines = Vec::new();
    let mut ecd_lines = Vec::new();
    let calculated_label = if dataset.fitted {
        ELECTRONIC_CALCULATED_FITTED_LABEL
    } else {
        "Calculated"
    };
    let enantiomer_label = if dataset.fitted {
        ELECTRONIC_ENANTIOMER_FITTED_LABEL
    } else {
        "Enantiomer"
    };
    if let Some(experimental) = &dataset.experimental_uv {
        uv_lines.push(LineSeries::new(
            "Experimental",
            "#14202e",
            &experimental.x,
            &experimental.y,
        ));
    }
    if let Some(experimental) = &dataset.experimental_ecd {
        ecd_lines.push(LineSeries::new(
            "Experimental",
            "#14202e",
            &experimental.x,
            &experimental.y,
        ));
    }
    if let Some(curves) = &curves {
        uv_lines.push(LineSeries::new(
            calculated_label,
            "#c62828",
            &curves.wavelength,
            &scaled(&curves.uv, dataset.scale_uv),
        ));
        let ecd = scaled(&curves.ecd, dataset.scale_ecd);
        ecd_lines.push(LineSeries::new(
            calculated_label,
            "#c62828",
            &curves.wavelength,
            &ecd,
        ));
        if dataset.show_enantiomer {
            ecd_lines.push(
                LineSeries::new(
                    enantiomer_label,
                    "#1565c0",
                    &curves.wavelength,
                    &scaled(&ecd, -1.0),
                )
                .dashed(),
            );
        }
    }
    let mut uv_sticks = Vec::new();
    let mut ecd_sticks = Vec::new();
    if dataset.show_sticks
        && let Some(curves) = &curves
    {
        uv_sticks.push(StickSeries {
            color: "#c62828".into(),
            x: curves.stick_nm.clone(),
            height: curves.stick_f.clone(),
            positive_only: true,
        });
        ecd_sticks.push(StickSeries {
            color: "#c62828".into(),
            x: curves.stick_nm.clone(),
            height: curves.stick_r.clone(),
            positive_only: false,
        });
    }
    let mut uv_markers = Vec::new();
    let mut ecd_markers = Vec::new();
    if dataset.show_peaks {
        let report = dataset.band_report();
        if let Some(channel) = report.uv {
            uv_markers.extend(channel.experimental.into_iter().map(|feature| Marker {
                x: feature.x,
                y: feature.y,
                upward: feature.sign < 0,
                color: "#0b7a5a".into(),
            }));
        }
        if let Some(channel) = report.ecd {
            ecd_markers.extend(channel.experimental.into_iter().map(|feature| Marker {
                x: feature.x,
                y: feature.y,
                upward: feature.sign < 0,
                color: "#0b7a5a".into(),
            }));
        }
    }
    FigureSpec {
        title: dataset.name.clone(),
        show_legend: dataset.show_export_legend,
        panels: vec![
            PanelSpec {
                y_label: "Absorbance  (AU)".into(),
                x_label: None,
                x_range: range,
                x_tick_quantum: 10.0,
                y_tick_minimum: 0.1,
                scientific_y: false,
                reverse_x: false,
                symmetric_y: false,
                zero_line: false,
                lines: uv_lines,
                sticks: uv_sticks,
                markers: uv_markers,
            },
            PanelSpec {
                y_label: dataset.ecd_unit.axis_label().into(),
                x_label: Some("Wavelength (nm)".into()),
                x_range: range,
                x_tick_quantum: 10.0,
                y_tick_minimum: 0.0,
                scientific_y: false,
                reverse_x: false,
                symmetric_y: false,
                zero_line: true,
                lines: ecd_lines,
                sticks: ecd_sticks,
                markers: ecd_markers,
            },
        ],
    }
}

pub fn vibrational_figure(dataset: &mut VibDataset) -> FigureSpec {
    let evaluation = dataset.evaluate();
    let raw_curves = dataset.curves();
    let (low, high) = dataset.view_span();
    let range = (low, high);
    let mut ir_lines = Vec::new();
    let mut vcd_lines = Vec::new();
    let mut ir_sticks = Vec::new();
    let mut vcd_sticks = Vec::new();
    if let Some(matched) = &evaluation.curves {
        add_matched_lines(matched, dataset, &mut ir_lines, &mut vcd_lines);
    } else {
        if let Some(curves) = &raw_curves {
            ir_lines.push(LineSeries::new(
                "Calculated",
                "#a03048",
                &curves.frequency,
                &curves.ir,
            ));
            vcd_lines.push(LineSeries::new(
                "Calculated",
                "#a03048",
                &curves.frequency,
                &curves.vcd,
            ));
            if dataset.show_enantiomer {
                vcd_lines.push(
                    LineSeries::new(
                        "Enantiomer",
                        "#1565c0",
                        &curves.frequency,
                        &scaled(&curves.vcd, -1.0),
                    )
                    .dashed(),
                );
            }
            if dataset.show_sticks {
                ir_sticks.push(StickSeries {
                    color: "#a03048".into(),
                    x: curves.stick_x.clone(),
                    height: curves.stick_ir.clone(),
                    positive_only: true,
                });
                vcd_sticks.push(StickSeries {
                    color: "#a03048".into(),
                    x: curves.stick_x.clone(),
                    height: curves.stick_vcd.clone(),
                    positive_only: false,
                });
            }
        }
        if let Some(experimental) = &dataset.experimental_ir {
            ir_lines.push(LineSeries::new(
                "Experimental",
                "#1b2733",
                &experimental.x,
                &experimental.y,
            ));
        }
        if let Some(experimental) = &dataset.experimental_vcd {
            vcd_lines.push(LineSeries::new(
                "Experimental",
                "#1b2733",
                &experimental.x,
                &experimental.y,
            ));
        }
    }
    FigureSpec {
        title: dataset.name.clone(),
        show_legend: dataset.show_export_legend,
        panels: vec![
            PanelSpec {
                y_label: "Absorbance  (AU)".into(),
                x_label: None,
                x_range: range,
                x_tick_quantum: 50.0,
                y_tick_minimum: 0.1,
                scientific_y: false,
                reverse_x: true,
                symmetric_y: false,
                zero_line: false,
                lines: ir_lines,
                sticks: ir_sticks,
                markers: Vec::new(),
            },
            PanelSpec {
                y_label: "ΔA  (AU)".into(),
                x_label: Some("Wavenumber (cm⁻¹)".into()),
                x_range: range,
                x_tick_quantum: 50.0,
                y_tick_minimum: 0.0,
                scientific_y: true,
                reverse_x: true,
                symmetric_y: true,
                zero_line: true,
                lines: vcd_lines,
                sticks: vcd_sticks,
                markers: Vec::new(),
            },
        ],
    }
}

fn add_matched_lines(
    matched: &VibMatchedCurves,
    dataset: &VibDataset,
    ir_lines: &mut Vec<LineSeries>,
    vcd_lines: &mut Vec<LineSeries>,
) {
    let calculated_label = if dataset.fitted {
        VIB_CALCULATED_FITTED_LABEL
    } else {
        "Calculated"
    };
    ir_lines.push(LineSeries::new(
        "Experimental",
        "#1b2733",
        &matched.frequency,
        &matched.ir_observed,
    ));
    ir_lines.push(LineSeries::new(
        calculated_label,
        "#a03048",
        &matched.frequency,
        &matched.ir_calculated,
    ));
    vcd_lines.push(LineSeries::new(
        "Experimental",
        "#1b2733",
        &matched.frequency,
        &matched.vcd_observed,
    ));
    vcd_lines.push(LineSeries::new(
        calculated_label,
        "#a03048",
        &matched.frequency,
        &matched.vcd_calculated,
    ));
    if dataset.show_enantiomer {
        let values = if dataset.fitted {
            matched.vcd_opposite.clone()
        } else {
            scaled(&matched.vcd_calculated, -1.0)
        };
        let label = if dataset.fitted {
            VIB_ENANTIOMER_FITTED_LABEL
        } else {
            "Enantiomer"
        };
        vcd_lines.push(LineSeries::new(label, "#1565c0", &matched.frequency, &values).dashed());
    }
}

fn interpolated_or_nan(spectrum: &Spectrum, grid: &[f64]) -> Vec<f64> {
    let mut values = resample(&spectrum.x, &spectrum.y, grid);
    if let Some((low, high)) = min_max(&spectrum.x) {
        for (x, value) in grid.iter().zip(&mut values) {
            if *x < low || *x > high {
                *value = f64::NAN;
            }
        }
    }
    values
}

pub fn write_electronic_data(
    dataset: &mut ElectronicDataset,
    path: impl AsRef<Path>,
) -> Result<()> {
    if !dataset.has_any_experimental() && !dataset.has_calculation() {
        bail!("nothing is available to export");
    }
    let path = path.as_ref();
    let separator = if path
        .extension()
        .and_then(|v| v.to_str())
        .is_some_and(|v| v.eq_ignore_ascii_case("csv"))
    {
        ','
    } else {
        '\t'
    };
    let low = dataset.wavelength_min.min(dataset.wavelength_max);
    let high = dataset.wavelength_min.max(dataset.wavelength_max);
    let grid = linspace(low, high, 1000);
    let mut headers = vec!["wavelength_nm".to_string()];
    let mut columns = vec![grid.clone()];
    if let Some(spectrum) = &dataset.experimental_uv {
        headers.push("exp_uv".into());
        columns.push(interpolated_or_nan(spectrum, &grid));
    }
    if let Some(spectrum) = &dataset.experimental_ecd {
        headers.push(format!("exp_ecd_{}", dataset.ecd_unit.column_suffix()));
        columns.push(interpolated_or_nan(spectrum, &grid));
    }
    if let Some(curves) = dataset.curves() {
        let ecd_unit = dataset.ecd_unit.column_suffix();
        headers.extend([
            "calc_uv".into(),
            format!("calc_ecd_{ecd_unit}"),
            format!("calc_ecd_enantiomer_{ecd_unit}"),
        ]);
        columns.push(interpolated_or_nan(
            &Spectrum::new(
                curves.wavelength.clone(),
                scaled(&curves.uv, dataset.scale_uv),
            ),
            &grid,
        ));
        let ecd = interpolated_or_nan(
            &Spectrum::new(
                curves.wavelength.clone(),
                scaled(&curves.ecd, dataset.scale_ecd),
            ),
            &grid,
        );
        columns.push(ecd.clone());
        columns.push(scaled(&ecd, -1.0));
    }
    let mut output = headers.join(&separator.to_string());
    output.push('\n');
    for row in 0..grid.len() {
        for (column, values) in columns.iter().enumerate() {
            if column > 0 {
                output.push(separator);
            }
            let value = values[row];
            if value.is_nan() {
                output.push_str("nan")
            } else {
                let _ = write!(output, "{value:.6}");
            }
        }
        output.push('\n');
    }
    fs::write(path, output).with_context(|| format!("could not write {}", path.display()))
}

pub fn write_vibrational_data(dataset: &mut VibDataset, path: impl AsRef<Path>) -> Result<()> {
    let evaluation = dataset.evaluate();
    let result = evaluation
        .result
        .as_ref()
        .ok_or_else(|| anyhow!("nothing is matched yet"))?;
    let curves = evaluation
        .curves
        .as_ref()
        .ok_or_else(|| anyhow!("nothing is matched yet"))?;
    let mut output = String::new();
    let _ = writeln!(
        output,
        "# CDAR - vibrational matched spectra (normalised, region-shifted)"
    );
    let _ = writeln!(output, "# compound: {}", dataset.name);
    let _ = writeln!(
        output,
        "# SimIR={:.4} SimVCD={:.4} SimVCD_enantiomer={:.4} ESI={:+.4}",
        result.sim_ir, result.sim_vcd, result.sim_vcd_opposite, result.esi
    );
    let _ = writeln!(
        output,
        "# scale={:.3} gamma={:.1} window={}-{} max_shift={}",
        dataset.scale, dataset.gamma, dataset.range_low, dataset.range_high, dataset.max_shift
    );
    output.push_str("wavenumber,IR_measured,IR_calc,VCD_measured,VCD_calc,VCD_enantiomer\n");
    for index in 0..curves.frequency.len() {
        let _ = writeln!(
            output,
            "{:.0},{:.6},{:.6},{:.6},{:.6},{:.6}",
            curves.frequency[index],
            curves.ir_observed[index],
            curves.ir_calculated[index],
            curves.vcd_observed[index],
            curves.vcd_calculated[index],
            curves.vcd_opposite[index],
        );
    }
    fs::write(path.as_ref(), output)
        .with_context(|| format!("could not write {}", path.as_ref().display()))
}
