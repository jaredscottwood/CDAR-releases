//! Native egui front end for the electronic and vibrational workflows.

use std::collections::{BTreeSet, VecDeque};
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver, TryRecvError};
use std::time::{Duration, Instant};

use eframe::egui::{
    self, Align, Color32, ComboBox, Context, DragValue, Layout, RichText, ScrollArea, Sense,
    Slider, Stroke, TextWrapMode, TextureHandle, Ui, Vec2, ViewportBuilder, ViewportCommand,
    ViewportId,
};
use egui_plot::{
    AxisHints, Corner, GridInput, GridMark, HLine, Line, LineStyle, MarkerShape, Plot, PlotPoint,
    PlotPoints, PlotTransform, Points,
};

use crate::activity::ActivityLog;
use crate::assets::AppAssets;
use crate::electronic::{
    Conformer, ELECTRONIC_CALCULATED_FITTED_LABEL, ELECTRONIC_ENANTIOMER_FITTED_LABEL, EcdUnit,
    ElectronicAutoFitInput, ElectronicAutoFitOutput, ElectronicDataset, FitObjective, Gauge,
    ParsedExperimental, Profile, Sensitivity, Spectrum, dedupe_electronic, guess_roles,
    parse_experimental, parse_qm, run_electronic_auto_fit,
};
use crate::export::{
    electronic_figure, vibrational_figure, write_electronic_data, write_figure,
    write_vibrational_data,
};
use crate::help::{ABOUT, DEVELOPERS, ECD_METHODOLOGY, VCD_METHODOLOGY};
use crate::import::import_conformers;
use crate::math::{
    HARTREE_TO_KCAL, format_axis_tick, max_abs, min_max, nice_axis_range, rounded_axis_ticks,
    sanitize_filename,
};
use crate::state::FitStamp;
use crate::vibrational::{
    VIB_CALCULATED_FITTED_LABEL, VIB_ENANTIOMER_FITTED_LABEL, VibAutoFitInput, VibDataset,
    VibFitResult, VibKind, dedupe_vib, guess_vib_role, guess_vib_roles, looks_like_gaussian_log,
    parse_gaussian_vib, parse_vib_experimental, parse_vib_experimental_multi, run_vib_auto_fit,
};

const CHOOSER_BG: Color32 = Color32::from_rgb(39, 24, 43);
const CHOOSER_BLUE: Color32 = Color32::from_rgb(8, 27, 53);
const CHOOSER_RED: Color32 = Color32::from_rgb(76, 19, 38);
const ECD_BG: Color32 = Color32::from_rgb(11, 35, 64);
const ECD_PANEL: Color32 = Color32::from_rgb(246, 250, 255);
const VCD_BG: Color32 = Color32::from_rgb(76, 20, 36);
const VCD_PANEL: Color32 = Color32::from_rgb(255, 248, 249);
const CARD: Color32 = Color32::WHITE;
const INK: Color32 = Color32::from_rgb(25, 34, 46);
const MUTED: Color32 = Color32::from_rgb(93, 105, 120);
const HEADER_TEXT: Color32 = Color32::from_rgb(240, 245, 251);
const CHOOSER_MUTED: Color32 = Color32::from_rgb(205, 214, 228);
const ECD_HEADER: Color32 = Color32::from_rgb(151, 203, 255);
const ECD_DIVIDER: Color32 = Color32::from_rgb(91, 137, 184);
const VCD_DIVIDER: Color32 = Color32::from_rgb(184, 94, 115);
const GRID: Color32 = Color32::from_rgb(218, 224, 232);
const BASELINE: Color32 = Color32::from_rgb(150, 158, 168);
const ECD_ACCENT: Color32 = Color32::from_rgb(35, 96, 170);
const VCD_ACCENT: Color32 = Color32::from_rgb(174, 54, 67);
const CALC_RED: Color32 = Color32::from_rgb(198, 40, 40);
const ENANT_BLUE: Color32 = Color32::from_rgb(21, 101, 192);
const PEAK_GREEN: Color32 = Color32::from_rgb(11, 122, 90);
const RESULT_GOOD: Color32 = Color32::from_rgb(22, 115, 72);
const RESULT_CAUTION: Color32 = Color32::from_rgb(151, 96, 0);
const RESULT_BAD: Color32 = Color32::from_rgb(181, 45, 45);
const WORKSPACE_DIVIDER_WIDTH: f32 = 18.0;
const FOOTER_RESERVE: f32 = 71.0;
const PLOT_RIGHT_GUTTER: f32 = 26.0;
const SPECTRAL_STACK_RESERVE: f32 = 68.0;
const AXIS_TICK_LENGTH: f32 = 5.0;
const AXIS_TICK_LABEL_CLEARANCE: f32 = AXIS_TICK_LENGTH + 3.0;
const STATUS_ROW_HEIGHT: f32 = 28.0;
const STATUS_FONT_SIZE: f32 = 15.0;
const STATUS_COORDINATE_WIDTH: f32 = 460.0;
const WINDOW_INNER_MARGIN: i8 = 12;
const HEADER_ACTION_BUTTON_HEIGHT: f32 = 25.0;
const DISPLAY_SCALE_DECIMALS: usize = 6;
const DISPLAY_SCALE_DRAG_SPEED: f64 = 0.000_002;
const SPLASH_DURATION: Duration = Duration::from_millis(1_500);
const MAIN_WINDOW_SIZE: Vec2 = Vec2::new(1180.0, 780.0);
const MAIN_WINDOW_MIN_SIZE: Vec2 = Vec2::new(940.0, 560.0);
const INITIAL_ACTIVITY_MESSAGE: &str =
    "Drop calculation files and measured spectra here, or use the load buttons to begin.";
const NO_USABLE_IMPORT_MESSAGE: &str = "No usable files were imported.";
const FIT_RANGE_TO_DATA_LABEL: &str = "Fit range to data";
const ELECTRONIC_WORKSPACE_TITLE: &str = "Electronic  ·  UV / ECD";
const VIBRATIONAL_WORKSPACE_TITLE: &str = "Vibrational  ·  IR / VCD";

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum Screen {
    #[default]
    Chooser,
    Electronic,
    Vibrational,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum ControlTab {
    #[default]
    Fit,
    Conformers,
    View,
}

#[derive(Clone, Copy, Debug)]
enum MainWindowStartup {
    Pending,
    Verify { requested_at: Instant, retry: bool },
    Remaximize { unmaximized_at: Instant },
    Complete,
}

#[derive(Clone, Copy, Debug)]
struct PlotCoordinates {
    channel: &'static str,
    x: f64,
    y: f64,
    x_unit: &'static str,
    y_unit: Option<&'static str>,
}

#[derive(Clone, Copy, Debug)]
struct WorkspaceDimensions {
    plot_width: f32,
    controls_width: f32,
    body_height: f32,
}

fn workspace_dimensions(total_width: f32, available_height: f32) -> WorkspaceDimensions {
    let usable_width = (total_width - WORKSPACE_DIVIDER_WIDTH).max(0.0);
    let desired_controls = (total_width * 0.36).clamp(330.0, 420.0);
    let minimum_plot = 300.0_f32.min(usable_width);
    let controls_width = desired_controls.min((usable_width - minimum_plot).max(0.0));
    let plot_width = (usable_width - controls_width).max(0.0);
    let body_height = (available_height - FOOTER_RESERVE)
        .max(1.0)
        .min(available_height.max(1.0));
    WorkspaceDimensions {
        plot_width,
        controls_width,
        body_height,
    }
}

fn spectral_content_width(card_inner_width: f32) -> f32 {
    (card_inner_width - PLOT_RIGHT_GUTTER).max(120.0)
}

fn stacked_spectrum_height(card_inner_height: f32) -> f32 {
    ((card_inner_height - SPECTRAL_STACK_RESERVE) / 2.0).max(105.0)
}

fn maximized_geometry_is_sane(window_size: Vec2, monitor_size: Vec2) -> bool {
    window_size.x >= monitor_size.x * 0.90 && window_size.y >= monitor_size.y * 0.84
}

#[cfg(test)]
mod ui_layout_tests {
    use super::*;

    #[test]
    fn workspace_columns_and_footer_stay_inside_the_available_rect() {
        for width in [700.0, 916.0, 1_339.0, 2_000.0] {
            let dimensions = workspace_dimensions(width, 640.0);
            let occupied =
                dimensions.plot_width + WORKSPACE_DIVIDER_WIDTH + dimensions.controls_width;
            assert!((occupied - width).abs() < 0.01);
            assert!(dimensions.controls_width <= 420.0);
            assert!(dimensions.plot_width >= 300.0);
        }
        for height in [320.0, 536.0, 900.0] {
            let dimensions = workspace_dimensions(1_200.0, height);
            assert!(dimensions.body_height + FOOTER_RESERVE <= height + 0.01);
        }
    }

    #[test]
    fn maximize_check_rejects_the_three_quarter_window_case() {
        let monitor = Vec2::new(2560.0, 1440.0);
        assert!(maximized_geometry_is_sane(
            Vec2::new(2560.0, 1380.0),
            monitor
        ));
        assert!(!maximized_geometry_is_sane(
            Vec2::new(1920.0, 1080.0),
            monitor
        ));
    }

    #[test]
    fn slider_rounding_noise_does_not_clear_a_completed_fit() {
        assert!(!slider_value_materially_changed(
            0.370_000_000_000_000_1,
            0.37,
            0.005
        ));
        assert!(slider_value_materially_changed(0.37, 0.375, 0.005));
        egui::__run_test_ui(|ui| {
            ui.set_width(300.0);
            let mut fitted_value = 0.370_000_000_000_000_1;
            assert!(!aligned_f64_slider(
                ui,
                &mut fitted_value,
                0.03..=0.60,
                0.005,
                3,
            ));
        });
    }

    #[test]
    fn spectral_content_keeps_a_fixed_right_gutter_inside_the_card() {
        assert_eq!(spectral_content_width(900.0), 874.0);
        assert_eq!(spectral_content_width(180.0), 154.0);
        assert_eq!(spectral_content_width(140.0), 120.0);
    }

    #[test]
    fn live_axes_reserve_clearance_beyond_the_ticks() {
        assert_eq!(live_x_axes("Wavelength (nm)", false).len(), 2);
        assert_eq!(live_y_axes("Absorbance (AU)", false).len(), 2);
    }

    #[test]
    fn stacked_spectra_consume_the_small_lower_interior_surplus() {
        let card_height = 600.0;
        let spectrum_height = stacked_spectrum_height(card_height);
        assert_eq!(spectrum_height, 266.0);
        assert_eq!(spectrum_height * 2.0 + SPECTRAL_STACK_RESERVE, card_height);
    }

    #[test]
    fn only_physical_y_coordinates_receive_a_unit_suffix() {
        let ecd = PlotCoordinates {
            channel: "ECD",
            x: 245.5,
            y: -1.25,
            x_unit: "nm",
            y_unit: Some("mdeg"),
        };
        let uv = PlotCoordinates {
            channel: "UV",
            y_unit: None,
            ..ecd
        };
        assert_eq!(ecd.label(), "ECD   x = 245.50 nm   y = -1.25000 mdeg");
        assert_eq!(uv.label(), "UV   x = 245.50 nm   y = -1.25000");
    }

    #[test]
    fn footer_card_uses_the_same_separator_gap_as_the_main_cards() {
        egui::__run_test_ui(|ui| {
            ui.spacing_mut().item_spacing.y = 9.0;
            ui.set_width(700.0);
            let (card_rect, _) = ui.allocate_exact_size(Vec2::new(700.0, 100.0), Sense::hover());
            let separator_rect = workspace_separator(ui, ECD_DIVIDER);
            let (footer_card_rect, coordinates_rect, footer_outer_rect, _) =
                status_bar(ui, "Ready", None, ECD_ACCENT, ECD_DIVIDER);
            assert!(
                (coordinates_rect.left() - footer_card_rect.right() - WORKSPACE_DIVIDER_WIDTH)
                    .abs()
                    < 0.01
            );
            assert_eq!(coordinates_rect.top(), footer_card_rect.top());
            assert_eq!(coordinates_rect.bottom(), footer_card_rect.bottom());
            let main_gap = separator_rect.top() - card_rect.bottom();
            let footer_gap = footer_card_rect.top() - separator_rect.bottom();
            assert!((main_gap - footer_gap).abs() < 0.01);
            assert!(footer_card_rect.height() >= 40.0);
            assert_eq!(
                footer_outer_rect.bottom() - footer_card_rect.bottom(),
                f32::from(WINDOW_INNER_MARGIN)
            );
        });
    }
    #[test]
    fn log_card_can_be_clicked_and_footer_fits_laptop_width() {
        let context = Context::default();
        let mut click_point = egui::Pos2::ZERO;
        let screen = egui::Rect::from_min_size(egui::Pos2::ZERO, Vec2::new(940.0, 100.0));
        let mut clicked = false;
        for frame in 0..3 {
            let mut divider_points = [egui::Pos2::ZERO; 2];
            let mut input = egui::RawInput {
                screen_rect: Some(screen),
                ..Default::default()
            };
            if frame > 0 {
                input.events.push(egui::Event::PointerMoved(click_point));
                input.events.push(egui::Event::PointerButton {
                    pos: click_point,
                    button: egui::PointerButton::Primary,
                    pressed: frame == 1,
                    modifiers: egui::Modifiers::NONE,
                });
            }
            let mut output = context.run_ui(input, |ui| {
                let (log, coordinates, outer, response) = status_bar(
                    ui,
                    "47 files selected: 34 kept.\nFull report below.",
                    None,
                    ECD_ACCENT,
                    ECD_DIVIDER,
                );
                click_point = log.center();
                assert!(outer.right() <= screen.right() + 0.01);
                assert_eq!(log.height(), coordinates.height());
                assert!((coordinates.left() - log.right() - WORKSPACE_DIVIDER_WIDTH).abs() < 0.01);
                let divider_x = (coordinates.left() + log.right()) / 2.0;
                divider_points = [
                    egui::pos2(divider_x, log.top()),
                    egui::pos2(divider_x, log.bottom()),
                ];
                clicked |= response;
            });
            assert!(
                output.shapes.iter().any(|shape| {
                    matches!(&shape.shape, egui::Shape::LineSegment { points, stroke }
                    if *points == divider_points && *stroke == Stroke::new(1.25, ECD_DIVIDER))
                }),
                "footer divider must span the card height and use the workspace separator style"
            );
            output.textures_delta.clear();
        }
        assert!(clicked, "clicking the log card must open its details");
    }
}

impl PlotCoordinates {
    fn label(self) -> String {
        let y = if self.y != 0.0 && (self.y.abs() < 0.001 || self.y.abs() >= 10_000.0) {
            format!("{:.4e}", self.y)
        } else {
            format!("{:.5}", self.y)
        };
        let y_unit = self
            .y_unit
            .map(|unit| format!(" {unit}"))
            .unwrap_or_default();
        format!(
            "{}   x = {:.2} {}   y = {y}{y_unit}",
            self.channel, self.x, self.x_unit
        )
    }
}

struct ElectronicState {
    datasets: Vec<ElectronicDataset>,
    selected: usize,
    tab: ControlTab,
    objective: FitObjective,
    selected_conformers: BTreeSet<usize>,
    fit_receiver: Option<Receiver<(FitStamp, Result<ElectronicAutoFitOutput, String>)>>,
    show_grid: bool,
    show_baseline: bool,
    reset_plot_view: bool,
    activity: ActivityLog,
}

impl Default for ElectronicState {
    fn default() -> Self {
        Self {
            datasets: vec![ElectronicDataset::default()],
            selected: 0,
            tab: ControlTab::Fit,
            objective: FitObjective::PeakShape,
            selected_conformers: BTreeSet::new(),
            fit_receiver: None,
            show_grid: false,
            show_baseline: true,
            reset_plot_view: false,
            activity: ActivityLog::new(INITIAL_ACTIVITY_MESSAGE),
        }
    }
}

struct VibrationalState {
    datasets: Vec<VibDataset>,
    selected: usize,
    tab: ControlTab,
    selected_conformers: BTreeSet<usize>,
    fit_receiver: Option<Receiver<(FitStamp, Result<VibFitResult, String>)>>,
    show_grid: bool,
    show_baseline: bool,
    reset_plot_view: bool,
    activity: ActivityLog,
}

impl Default for VibrationalState {
    fn default() -> Self {
        Self {
            datasets: vec![VibDataset::default()],
            selected: 0,
            tab: ControlTab::Fit,
            selected_conformers: BTreeSet::new(),
            fit_receiver: None,
            show_grid: false,
            show_baseline: true,
            reset_plot_view: false,
            activity: ActivityLog::new(INITIAL_ACTIVITY_MESSAGE),
        }
    }
}

#[derive(Clone)]
struct PendingElectronicImport {
    dataset_id: u64,
    parsed: ParsedExperimental,
    label: String,
    wavelength: usize,
    uv: Option<usize>,
    ecd: Option<usize>,
}

#[derive(Clone)]
struct RenameDialog {
    vibrational: bool,
    index: usize,
    value: String,
}

#[derive(Clone)]
enum InfoDialog {
    Text { title: String, text: String },
    Activity(Screen),
}

pub struct CdarApp {
    splash_started: Instant,
    main_window_startup: MainWindowStartup,
    screen: Screen,
    icon_screen: Option<Screen>,
    assets: AppAssets,
    #[cfg(target_os = "windows")]
    native_icons: Option<crate::assets::WindowsWindowIcons>,
    electronic: ElectronicState,
    vibrational: VibrationalState,
    info: Option<InfoDialog>,
    error: Option<String>,
    rename: Option<RenameDialog>,
    pending_electronic: VecDeque<PendingElectronicImport>,
}

impl CdarApp {
    pub fn new(creation: &eframe::CreationContext<'_>) -> Self {
        creation.egui_ctx.set_theme(egui::Theme::Light);
        let assets = AppAssets::load(&creation.egui_ctx);
        let mut style = (*creation.egui_ctx.style_of(egui::Theme::Light)).clone();
        style.visuals = egui::Visuals::light();
        style.visuals.panel_fill = CHOOSER_BG;
        style.visuals.window_fill = CARD;
        style.visuals.extreme_bg_color = CARD;
        style.visuals.override_text_color = Some(INK);
        style.spacing.item_spacing = Vec2::new(10.0, 9.0);
        style.spacing.button_padding = Vec2::new(12.0, 7.0);
        style.spacing.interact_size.y = 30.0;
        creation.egui_ctx.set_style_of(egui::Theme::Light, style);
        Self {
            splash_started: Instant::now(),
            main_window_startup: MainWindowStartup::Pending,
            screen: Screen::Chooser,
            icon_screen: None,
            assets,
            #[cfg(target_os = "windows")]
            native_icons: None,
            electronic: ElectronicState::default(),
            vibrational: VibrationalState::default(),
            info: None,
            error: None,
            rename: None,
            pending_electronic: VecDeque::new(),
        }
    }

    fn poll_workers(&mut self) {
        let electronic_message = match self.electronic.fit_receiver.as_ref() {
            Some(receiver) => match receiver.try_recv() {
                Ok(message) => Some(Ok(message)),
                Err(TryRecvError::Disconnected) => {
                    Some(Err("electronic fit worker stopped unexpectedly".to_string()))
                }
                Err(TryRecvError::Empty) => None,
            },
            None => None,
        };
        if let Some(message) = electronic_message {
            self.electronic.fit_receiver = None;
            match message {
                Ok((stamp, Ok(output))) => self.finish_electronic_fit(stamp, output),
                Ok((stamp, Err(_)))
                    if !self
                        .electronic
                        .datasets
                        .iter()
                        .any(|d| d.state.stamp() == stamp) =>
                {
                    self.electronic.activity.push(
                        "Discarded an outdated fit because the compound or fit inputs changed."
                            .into(),
                    );
                }
                Ok((_, Err(error))) | Err(error) => {
                    self.electronic
                        .activity
                        .push(format!("Auto-fit failed: {error}"));
                    self.error = Some(error);
                }
            }
        }

        let vibrational_message = match self.vibrational.fit_receiver.as_ref() {
            Some(receiver) => match receiver.try_recv() {
                Ok(message) => Some(Ok(message)),
                Err(TryRecvError::Disconnected) => Some(Err(
                    "vibrational fit worker stopped unexpectedly".to_string(),
                )),
                Err(TryRecvError::Empty) => None,
            },
            None => None,
        };
        if let Some(message) = vibrational_message {
            self.vibrational.fit_receiver = None;
            match message {
                Ok((stamp, Ok(output))) => self.finish_vibrational_fit(stamp, output),
                Ok((stamp, Err(_)))
                    if !self
                        .vibrational
                        .datasets
                        .iter()
                        .any(|d| d.state.stamp() == stamp) =>
                {
                    self.vibrational.activity.push(
                        "Discarded an outdated fit because the compound or fit inputs changed."
                            .into(),
                    );
                }
                Ok((_, Err(error))) | Err(error) => {
                    self.vibrational
                        .activity
                        .push(format!("Auto-fit failed: {error}"));
                    self.error = Some(error);
                }
            }
        }
    }

    fn ingest_dropped_files(&mut self, context: &Context) {
        // Consume this event once. Keep the handles alive while parsing their
        // files, including when egui redraws this viewport within one frame.
        let files = context.input_mut(|input| std::mem::take(&mut input.raw.dropped_files));
        let paths: Vec<PathBuf> = files.iter().map(|file| file.path().to_path_buf()).collect();
        if paths.is_empty() {
            return;
        }
        match self.screen {
            Screen::Electronic => self.ingest_electronic_paths(paths),
            Screen::Vibrational => self.ingest_vibrational_paths(paths),
            Screen::Chooser => {}
        }
    }

    fn background(&self) -> Color32 {
        match self.screen {
            Screen::Chooser => CHOOSER_BG,
            Screen::Electronic => ECD_BG,
            Screen::Vibrational => VCD_BG,
        }
    }

    fn accent(&self) -> Color32 {
        match self.screen {
            Screen::Chooser => ECD_HEADER,
            Screen::Electronic => ECD_ACCENT,
            Screen::Vibrational => VCD_ACCENT,
        }
    }

    fn sync_window_icon(&mut self, context: &Context) {
        if self.icon_screen == Some(self.screen) {
            return;
        }
        let icon = match self.screen {
            Screen::Chooser => self.assets.primary_icon(),
            Screen::Electronic => self.assets.electronic_icon(),
            Screen::Vibrational => self.assets.vibrational_icon(),
        };
        context.send_viewport_cmd(ViewportCommand::Icon(Some(icon.clone())));

        #[cfg(target_os = "windows")]
        match crate::assets::set_windows_window_icon(crate::APP_TITLE, &icon) {
            Ok(icons) => {
                self.native_icons = Some(icons);
                self.icon_screen = Some(self.screen);
            }
            Err(error) => {
                log::debug!("workspace icon is not ready yet: {error}");
                context.request_repaint_after(Duration::from_millis(50));
            }
        }

        #[cfg(not(target_os = "windows"))]
        {
            self.icon_screen = Some(self.screen);
        }
    }

    fn splash(&self, ui: &mut Ui) {
        let rect = ui.max_rect();
        ui.painter().image(
            self.assets.logo.id(),
            rect,
            egui::Rect::from_min_max(egui::Pos2::ZERO, egui::pos2(1.0, 1.0)),
            Color32::WHITE,
        );
        ui.ctx()
            .request_repaint_after(SPLASH_DURATION.saturating_sub(self.splash_started.elapsed()));
    }

    fn main_window_is_properly_maximized(context: &Context) -> Option<bool> {
        context.input(|input| {
            let viewport = input.viewport();
            let outer_size = viewport.outer_rect?.size();
            let monitor_size = viewport.monitor_size?;
            Some(
                viewport.maximized.unwrap_or(false)
                    && maximized_geometry_is_sane(outer_size, monitor_size),
            )
        })
    }

    fn advance_main_window_startup(&mut self, context: &Context) {
        let now = Instant::now();
        match self.main_window_startup {
            MainWindowStartup::Pending => {
                context.send_viewport_cmd(ViewportCommand::Visible(true));
                context.send_viewport_cmd(ViewportCommand::Maximized(false));
                context.send_viewport_cmd(ViewportCommand::Maximized(true));
                context.send_viewport_cmd(ViewportCommand::Focus);
                self.main_window_startup = MainWindowStartup::Verify {
                    requested_at: now,
                    retry: false,
                };
                context.request_repaint_after(Duration::from_millis(300));
            }
            MainWindowStartup::Verify {
                requested_at,
                retry,
            } => {
                let elapsed = now.saturating_duration_since(requested_at);
                if elapsed < Duration::from_millis(300) {
                    context.request_repaint_after(Duration::from_millis(300) - elapsed);
                    return;
                }
                match Self::main_window_is_properly_maximized(context) {
                    Some(true) => {
                        self.main_window_startup = MainWindowStartup::Complete;
                    }
                    None if elapsed < Duration::from_millis(1_200) => {
                        context.request_repaint_after(Duration::from_millis(100));
                    }
                    Some(false) if !retry => {
                        context.send_viewport_cmd(ViewportCommand::Maximized(false));
                        self.main_window_startup = MainWindowStartup::Remaximize {
                            unmaximized_at: now,
                        };
                        context.request_repaint_after(Duration::from_millis(80));
                    }
                    Some(false) => {
                        context.send_viewport_cmd(ViewportCommand::Maximized(false));
                        self.main_window_startup = MainWindowStartup::Complete;
                    }
                    None if retry => {
                        context.send_viewport_cmd(ViewportCommand::Maximized(false));
                        self.main_window_startup = MainWindowStartup::Complete;
                    }
                    None => {
                        context.send_viewport_cmd(ViewportCommand::Maximized(false));
                        self.main_window_startup = MainWindowStartup::Remaximize {
                            unmaximized_at: now,
                        };
                        context.request_repaint_after(Duration::from_millis(80));
                    }
                }
            }
            MainWindowStartup::Remaximize { unmaximized_at } => {
                let elapsed = now.saturating_duration_since(unmaximized_at);
                if elapsed < Duration::from_millis(80) {
                    context.request_repaint_after(Duration::from_millis(80) - elapsed);
                    return;
                }
                context.send_viewport_cmd(ViewportCommand::Maximized(true));
                self.main_window_startup = MainWindowStartup::Verify {
                    requested_at: now,
                    retry: true,
                };
                context.request_repaint_after(Duration::from_millis(300));
            }
            MainWindowStartup::Complete => {}
        }
    }

    fn show_main_viewport(&mut self, root_context: &Context) {
        let first_frame = matches!(self.main_window_startup, MainWindowStartup::Pending);
        let window_icon = match self.screen {
            Screen::Chooser => self.assets.primary_icon(),
            Screen::Electronic => self.assets.electronic_icon(),
            Screen::Vibrational => self.assets.vibrational_icon(),
        };
        let mut builder = ViewportBuilder::default()
            .with_title(crate::APP_TITLE)
            .with_inner_size(MAIN_WINDOW_SIZE)
            .with_min_inner_size(MAIN_WINDOW_MIN_SIZE)
            .with_resizable(true)
            .with_decorations(true)
            .with_taskbar(true)
            .with_visible(!first_frame)
            .with_icon(window_icon);
        if let Some(monitor_size) = root_context.input(|input| input.viewport().monitor_size) {
            builder = builder.with_position([
                ((monitor_size.x - MAIN_WINDOW_SIZE.x) * 0.5).max(0.0),
                ((monitor_size.y - MAIN_WINDOW_SIZE.y) * 0.5).max(0.0),
            ]);
        }

        root_context.show_viewport_immediate(
            ViewportId::from_hash_of("cdar-main-window"),
            builder,
            |ui, _class| {
                if ui.ctx().input(|input| input.viewport().close_requested()) {
                    ui.ctx()
                        .send_viewport_cmd_to(ViewportId::ROOT, ViewportCommand::Close);
                    return;
                }
                self.advance_main_window_startup(ui.ctx());
                self.main_window_ui(ui);
            },
        );
    }

    fn chooser(&mut self, ui: &mut Ui) {
        let mut requested_screen = None;
        let mut about = false;
        ScrollArea::vertical()
            .id_salt("mode_chooser")
            .auto_shrink([false, false])
            .show(ui, |ui| {
                ui.set_min_width(ui.available_width());
                ui.with_layout(Layout::top_down(Align::Center), |ui| {
                    ui.add_space(12.0);
                    ui.add(
                        egui::Image::from_texture(&self.assets.cdar)
                            .fit_to_exact_size(Vec2::splat(112.0))
                            .corner_radius(24),
                    );
                    ui.label(
                        RichText::new("CDAR")
                            .size(36.0)
                            .strong()
                            .color(HEADER_TEXT),
                    );
                    ui.add(
                        egui::Label::new(
                            RichText::new("Circular Dichroism Analysis & Refinement")
                                .size(17.0)
                                .color(CHOOSER_MUTED),
                        )
                        .wrap(),
                    );
                    ui.add(
                        egui::Label::new(
                            RichText::new(format!("Developed by {DEVELOPERS}"))
                                .size(13.0)
                                .color(CHOOSER_MUTED),
                        )
                        .wrap(),
                    );
                    ui.add_space(18.0);

                    let available = ui.available_width();
                    let wide = available >= 760.0;
                    let card_height = if wide { 282.0 } else { 316.0 };
                    let content_width = (available - 24.0).clamp(300.0, 940.0);
                    if wide {
                        let gap = 18.0;
                        let card_width = (content_width - gap) / 2.0;
                        ui.allocate_ui_with_layout(
                            Vec2::new(content_width, card_height),
                            Layout::left_to_right(Align::Min),
                            |ui| {
                                if mode_card(
                                    ui,
                                    card_width,
                                    card_height,
                                    &self.assets.ecd,
                                    "Electronic Circular Dichroism",
                                    "UV + ECD",
                                    "Gaussian TD-DFT excited states\nBoltzmann weighting and broadening\nSpectral similarity and assignment diagnostics",
                                    ECD_ACCENT,
                                    ECD_PANEL,
                                ) {
                                    requested_screen = Some(Screen::Electronic);
                                }
                                ui.add_space(gap);
                                if mode_card(
                                    ui,
                                    card_width,
                                    card_height,
                                    &self.assets.vcd,
                                    "Vibrational Circular Dichroism",
                                    "IR + VCD",
                                    "Gaussian DFT harmonic frequencies\nRegion-shifted Shen similarity\nScale and bandwidth optimization",
                                    VCD_ACCENT,
                                    VCD_PANEL,
                                ) {
                                    requested_screen = Some(Screen::Vibrational);
                                }
                            },
                        );
                    } else {
                        let card_width = content_width.min(540.0);
                        if mode_card(
                            ui,
                            card_width,
                            card_height,
                            &self.assets.ecd,
                            "Electronic Circular Dichroism",
                            "UV + ECD",
                            "Gaussian TD-DFT excited states\nBoltzmann weighting and broadening\nSpectral similarity and assignment diagnostics",
                            ECD_ACCENT,
                            ECD_PANEL,
                        ) {
                            requested_screen = Some(Screen::Electronic);
                        }
                        ui.add_space(14.0);
                        if mode_card(
                            ui,
                            card_width,
                            card_height,
                            &self.assets.vcd,
                            "Vibrational Circular Dichroism",
                            "IR + VCD",
                            "Gaussian DFT harmonic frequencies\nRegion-shifted Shen similarity\nScale and bandwidth optimization",
                            VCD_ACCENT,
                            VCD_PANEL,
                        ) {
                            requested_screen = Some(Screen::Vibrational);
                        }
                    }
                    ui.add_space(16.0);
                    about = ui
                        .link(RichText::new("About CDAR").color(ECD_HEADER))
                        .clicked();
                    ui.add_space(12.0);
                });
            });
        if let Some(screen) = requested_screen {
            self.screen = screen;
        }
        if about {
            self.info = Some(InfoDialog::Text {
                title: "About CDAR".into(),
                text: ABOUT.into(),
            });
        }
    }

    fn electronic_header(&mut self, ui: &mut Ui) {
        let mut requested_screen = None;
        let names: Vec<String> = self
            .electronic
            .datasets
            .iter()
            .map(|dataset| dataset.name.clone())
            .collect();
        let mut selected = self.electronic.selected.min(names.len().saturating_sub(1));
        let mut create = false;
        let mut rename = false;
        ui.scope(|ui| {
            header_widget_visuals(ui, ECD_ACCENT);
            ui.horizontal(|ui| {
                ui.add_space(6.0);
                ui.label(
                    RichText::new(ELECTRONIC_WORKSPACE_TITLE)
                        .size(15.0)
                        .strong()
                        .color(HEADER_TEXT),
                );
                ui.add_space(10.0);
                ComboBox::from_id_salt("electronic_compound")
                    .selected_text(names.get(selected).cloned().unwrap_or_default())
                    .width(170.0)
                    .show_ui(ui, |ui| {
                        for (index, name) in names.iter().enumerate() {
                            ui.selectable_value(&mut selected, index, name);
                        }
                    });
                if header_action_button(ui, "New").clicked() {
                    create = true;
                }
                if header_action_button(ui, "Rename").clicked() {
                    rename = true;
                }
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if ui.button("Vibrational mode").clicked() {
                        requested_screen = Some(Screen::Vibrational);
                    }
                    if header_action_button(ui, "About").clicked() {
                        self.info = Some(InfoDialog::Text {
                            title: "About CDAR".into(),
                            text: ABOUT.into(),
                        });
                    }
                    if header_action_button(ui, "Methodology").clicked() {
                        self.info = Some(InfoDialog::Text {
                            title: "Electronic Circular Dichroism — Methodology".into(),
                            text: crate::help::reflow_methodology(ECD_METHODOLOGY),
                        });
                    }
                });
            });
        });
        if selected != self.electronic.selected {
            self.electronic.selected = selected;
            self.electronic.selected_conformers.clear();
        }
        if create {
            let number = self.electronic.datasets.len() + 1;
            self.electronic
                .datasets
                .push(ElectronicDataset::new(format!("Compound {number}")));
            self.electronic.selected = self.electronic.datasets.len() - 1;
            self.electronic.selected_conformers.clear();
            self.electronic
                .activity
                .push("Created a new compound.".into());
        }
        if rename {
            let index = self.electronic.selected;
            let value = self.electronic.datasets[index].name.clone();
            self.rename = Some(RenameDialog {
                vibrational: false,
                index,
                value,
            });
        }
        if let Some(screen) = requested_screen {
            self.screen = screen;
        }
    }

    fn vibrational_header(&mut self, ui: &mut Ui) {
        let mut requested_screen = None;
        let names: Vec<String> = self
            .vibrational
            .datasets
            .iter()
            .map(|dataset| dataset.name.clone())
            .collect();
        let mut selected = self.vibrational.selected.min(names.len().saturating_sub(1));
        let mut create = false;
        let mut rename = false;
        ui.scope(|ui| {
            header_widget_visuals(ui, VCD_ACCENT);
            ui.horizontal(|ui| {
                ui.add_space(6.0);
                ui.label(
                    RichText::new(VIBRATIONAL_WORKSPACE_TITLE)
                        .size(15.0)
                        .strong()
                        .color(HEADER_TEXT),
                );
                ui.add_space(10.0);
                ComboBox::from_id_salt("vibrational_compound")
                    .selected_text(names.get(selected).cloned().unwrap_or_default())
                    .width(170.0)
                    .show_ui(ui, |ui| {
                        for (index, name) in names.iter().enumerate() {
                            ui.selectable_value(&mut selected, index, name);
                        }
                    });
                if header_action_button(ui, "New").clicked() {
                    create = true;
                }
                if header_action_button(ui, "Rename").clicked() {
                    rename = true;
                }
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if ui.button("Electronic mode").clicked() {
                        requested_screen = Some(Screen::Electronic);
                    }
                    if header_action_button(ui, "About").clicked() {
                        self.info = Some(InfoDialog::Text {
                            title: "About CDAR".into(),
                            text: ABOUT.into(),
                        });
                    }
                    if header_action_button(ui, "Methodology").clicked() {
                        self.info = Some(InfoDialog::Text {
                            title: "Vibrational Circular Dichroism — Methodology".into(),
                            text: crate::help::reflow_methodology(VCD_METHODOLOGY),
                        });
                    }
                });
            });
        });
        if selected != self.vibrational.selected {
            self.vibrational.selected = selected;
            self.vibrational.selected_conformers.clear();
        }
        if create {
            let number = self.vibrational.datasets.len() + 1;
            self.vibrational
                .datasets
                .push(VibDataset::new(format!("Compound {number}")));
            self.vibrational.selected = self.vibrational.datasets.len() - 1;
            self.vibrational.selected_conformers.clear();
            self.vibrational
                .activity
                .push("Created a new compound.".into());
        }
        if rename {
            let index = self.vibrational.selected;
            let value = self.vibrational.datasets[index].name.clone();
            self.rename = Some(RenameDialog {
                vibrational: true,
                index,
                value,
            });
        }
        if let Some(screen) = requested_screen {
            self.screen = screen;
        }
    }

    fn electronic_screen(&mut self, ui: &mut Ui) {
        self.electronic_header(ui);
        workspace_separator(ui, ECD_DIVIDER);
        let mut coordinates = None;
        let dimensions = workspace_dimensions(ui.available_width(), ui.available_height());
        let height = dimensions.body_height;
        ui.with_layout(Layout::left_to_right(Align::Min), |ui| {
            ui.spacing_mut().item_spacing.x = 0.0;
            ui.allocate_ui_with_layout(
                Vec2::new(dimensions.plot_width, height),
                Layout::top_down(Align::Min),
                |ui| {
                    ui.set_width(dimensions.plot_width);
                    ui.set_height(height);
                    egui::Frame::new()
                        .fill(CARD)
                        .stroke(Stroke::new(1.0, GRID))
                        .corner_radius(8)
                        .inner_margin(8)
                        .show(ui, |ui| {
                            let inner_width = (dimensions.plot_width - 16.0).max(1.0);
                            let inner_height = (height - 16.0).max(1.0);
                            ui.set_width(inner_width);
                            ui.set_height(inner_height);
                            let content_width = spectral_content_width(inner_width);
                            ui.allocate_ui_with_layout(
                                Vec2::new(content_width, inner_height),
                                Layout::top_down(Align::Min),
                                |ui| {
                                    ui.set_width(content_width);
                                    ui.set_height(inner_height);
                                    coordinates = self.electronic_plots(ui);
                                },
                            );
                        });
                },
            );
            workspace_vertical_separator(ui, WORKSPACE_DIVIDER_WIDTH, height, ECD_DIVIDER);
            ui.allocate_ui_with_layout(
                Vec2::new(dimensions.controls_width, height),
                Layout::top_down(Align::Min),
                |ui| {
                    ui.set_height(height);
                    egui::Frame::new()
                        .fill(ECD_PANEL)
                        .stroke(Stroke::new(1.0, ECD_ACCENT.linear_multiply(0.25)))
                        .corner_radius(8)
                        .inner_margin(10)
                        .show(ui, |ui| {
                            let inner_height = (height - 20.0).max(1.0);
                            ui.set_height(inner_height);
                            ui.style_mut().wrap_mode = Some(TextWrapMode::Wrap);
                            ScrollArea::vertical()
                                .id_salt("electronic_controls_scroll")
                                .auto_shrink([false, false])
                                .max_height(inner_height.max(80.0))
                                .show(ui, |ui| {
                                    let content_width = (ui.available_width() - 10.0).max(1.0);
                                    ui.set_width(content_width);
                                    self.electronic_controls(ui);
                                });
                        });
                },
            );
        });
        workspace_separator(ui, ECD_DIVIDER);
        if status_bar(
            ui,
            self.electronic.activity.latest(),
            coordinates,
            ECD_ACCENT,
            ECD_DIVIDER,
        )
        .3
        {
            self.info = Some(InfoDialog::Activity(Screen::Electronic));
        }
    }

    fn vibrational_screen(&mut self, ui: &mut Ui) {
        self.vibrational_header(ui);
        workspace_separator(ui, VCD_DIVIDER);
        let mut coordinates = None;
        let dimensions = workspace_dimensions(ui.available_width(), ui.available_height());
        let height = dimensions.body_height;
        ui.with_layout(Layout::left_to_right(Align::Min), |ui| {
            ui.spacing_mut().item_spacing.x = 0.0;
            ui.allocate_ui_with_layout(
                Vec2::new(dimensions.plot_width, height),
                Layout::top_down(Align::Min),
                |ui| {
                    ui.set_width(dimensions.plot_width);
                    ui.set_height(height);
                    egui::Frame::new()
                        .fill(CARD)
                        .stroke(Stroke::new(1.0, GRID))
                        .corner_radius(8)
                        .inner_margin(8)
                        .show(ui, |ui| {
                            let inner_width = (dimensions.plot_width - 16.0).max(1.0);
                            let inner_height = (height - 16.0).max(1.0);
                            ui.set_width(inner_width);
                            ui.set_height(inner_height);
                            let content_width = spectral_content_width(inner_width);
                            ui.allocate_ui_with_layout(
                                Vec2::new(content_width, inner_height),
                                Layout::top_down(Align::Min),
                                |ui| {
                                    ui.set_width(content_width);
                                    ui.set_height(inner_height);
                                    coordinates = self.vibrational_plots(ui);
                                },
                            );
                        });
                },
            );
            workspace_vertical_separator(ui, WORKSPACE_DIVIDER_WIDTH, height, VCD_DIVIDER);
            ui.allocate_ui_with_layout(
                Vec2::new(dimensions.controls_width, height),
                Layout::top_down(Align::Min),
                |ui| {
                    ui.set_height(height);
                    egui::Frame::new()
                        .fill(VCD_PANEL)
                        .stroke(Stroke::new(1.0, VCD_ACCENT.linear_multiply(0.25)))
                        .corner_radius(8)
                        .inner_margin(10)
                        .show(ui, |ui| {
                            let inner_height = (height - 20.0).max(1.0);
                            ui.set_height(inner_height);
                            ui.style_mut().wrap_mode = Some(TextWrapMode::Wrap);
                            ScrollArea::vertical()
                                .id_salt("vibrational_controls_scroll")
                                .auto_shrink([false, false])
                                .max_height(inner_height.max(80.0))
                                .show(ui, |ui| {
                                    let content_width = (ui.available_width() - 10.0).max(1.0);
                                    ui.set_width(content_width);
                                    self.vibrational_controls(ui);
                                });
                        });
                },
            );
        });
        workspace_separator(ui, VCD_DIVIDER);
        if status_bar(
            ui,
            self.vibrational.activity.latest(),
            coordinates,
            VCD_ACCENT,
            VCD_DIVIDER,
        )
        .3
        {
            self.info = Some(InfoDialog::Activity(Screen::Vibrational));
        }
    }

    fn show_dialogs(&mut self, context: &Context) {
        self.show_info_dialog(context);
        self.show_error_dialog(context);
        self.show_rename_dialog(context);
        self.show_column_dialog(context);
    }

    fn show_info_dialog(&mut self, context: &Context) {
        let Some((title, text, is_log)) = self.info_content() else {
            return;
        };
        let mut open = true;
        let mut close = false;
        egui::Window::new(title)
            .open(&mut open)
            .collapsible(false)
            .resizable(true)
            .default_size(Vec2::new(620.0, 560.0))
            .show(context, |ui| {
                let scroll_height = (ui.available_height() - 44.0).max(80.0);
                ScrollArea::vertical()
                    .id_salt(("info_content", title))
                    .stick_to_bottom(is_log)
                    .auto_shrink([false, false])
                    .max_height(scroll_height)
                    .show(ui, |ui| {
                        let content_width = (ui.available_width() - 10.0).max(1.0);
                        ui.set_width(content_width);
                        ui.add(
                            egui::Label::new(RichText::new(text))
                                .wrap()
                                .selectable(true),
                        );
                    });
                ui.separator();
                ui.horizontal(|ui| {
                    if is_log && ui.button("Copy log").clicked() {
                        ui.ctx().copy_text(text.to_owned());
                    }
                    if ui.button("Close").clicked() {
                        close = true;
                    }
                });
            });
        if !open || close {
            self.info = None;
        }
    }

    fn info_content(&self) -> Option<(&str, &str, bool)> {
        match self.info.as_ref()? {
            InfoDialog::Text { title, text } => Some((title, text, false)),
            InfoDialog::Activity(Screen::Electronic) => {
                Some(("UV/ECD activity log", self.electronic.activity.text(), true))
            }
            InfoDialog::Activity(Screen::Vibrational) => Some((
                "IR/VCD activity log",
                self.vibrational.activity.text(),
                true,
            )),
            InfoDialog::Activity(Screen::Chooser) => None,
        }
    }

    fn electronic_error(&mut self, message: String) {
        self.electronic.activity.push(format!("Error: {message}"));
        self.error = Some(message);
    }

    fn vibrational_error(&mut self, message: String) {
        self.vibrational.activity.push(format!("Error: {message}"));
        self.error = Some(message);
    }

    fn show_error_dialog(&mut self, context: &Context) {
        let Some(message) = self.error.clone() else {
            return;
        };
        let mut open = true;
        let mut close = false;
        egui::Window::new("CDAR")
            .open(&mut open)
            .collapsible(false)
            .resizable(true)
            .show(context, |ui| {
                ui.label(message);
                ui.add_space(8.0);
                if ui.button("OK").clicked() {
                    close = true;
                }
            });
        if !open || close {
            self.error = None;
        }
    }

    fn show_rename_dialog(&mut self, context: &Context) {
        let Some(mut dialog) = self.rename.clone() else {
            return;
        };
        let mut open = true;
        let mut accept = false;
        let mut cancel = false;
        egui::Window::new("Rename compound")
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .show(context, |ui| {
                ui.label("Compound name");
                let response = ui.text_edit_singleline(&mut dialog.value);
                if response.lost_focus() && ui.input(|input| input.key_pressed(egui::Key::Enter)) {
                    accept = true;
                }
                ui.horizontal(|ui| {
                    if ui.button("Cancel").clicked() {
                        cancel = true;
                    }
                    if ui.button("OK").clicked() {
                        accept = true;
                    }
                });
            });
        if accept {
            let value = dialog.value.trim();
            if !value.is_empty() {
                if dialog.vibrational {
                    if let Some(dataset) = self.vibrational.datasets.get_mut(dialog.index) {
                        self.vibrational
                            .activity
                            .push(format!("Renamed {} to {value}.", dataset.name));
                        dataset.name = value.into();
                    }
                } else if let Some(dataset) = self.electronic.datasets.get_mut(dialog.index) {
                    self.electronic
                        .activity
                        .push(format!("Renamed {} to {value}.", dataset.name));
                    dataset.name = value.into();
                }
            }
            self.rename = None;
        } else if cancel || !open {
            self.rename = None;
        } else {
            self.rename = Some(dialog);
        }
    }

    fn show_column_dialog(&mut self, context: &Context) {
        let Some(mut pending) = self.pending_electronic.pop_front() else {
            return;
        };
        let mut open = true;
        let mut accept = false;
        let mut cancel = false;
        egui::Window::new("Map experimental columns")
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .show(context, |ui| {
                ui.label(format!("Assign columns in {}:", pending.label));
                column_combo(
                    ui,
                    "Wavelength",
                    "map_wavelength",
                    &mut pending.wavelength,
                    pending.parsed.ncolumns,
                );
                optional_column_combo(
                    ui,
                    "UV / absorbance",
                    "map_uv",
                    &mut pending.uv,
                    pending.parsed.ncolumns,
                );
                optional_column_combo(
                    ui,
                    "CD / ECD",
                    "map_ecd",
                    &mut pending.ecd,
                    pending.parsed.ncolumns,
                );
                ui.horizontal(|ui| {
                    if ui.button("Cancel").clicked() {
                        cancel = true;
                    }
                    if ui.button("OK").clicked() {
                        accept = true;
                    }
                });
            });
        if accept {
            if !self.apply_mapped_electronic(&pending) {
                self.pending_electronic.push_front(pending);
            }
        } else if cancel || !open {
            self.electronic
                .activity
                .push(format!("Cancelled column mapping for {}.", pending.label));
        } else {
            self.pending_electronic.push_front(pending);
        }
    }
}

impl CdarApp {
    fn main_window_ui(&mut self, ui: &mut Ui) {
        self.sync_window_icon(ui.ctx());
        self.ingest_dropped_files(ui.ctx());
        let background = self.background();
        let accent = self.accent();
        if self.screen == Screen::Chooser {
            paint_horizontal_gradient(ui, ui.max_rect(), CHOOSER_BLUE, CHOOSER_RED);
        }
        ui.scope(|ui| {
            let visuals = ui.visuals_mut();
            visuals.hyperlink_color = accent;
            visuals.selection.bg_fill = accent;
            visuals.selection.stroke = Stroke::new(1.0, Color32::WHITE);
            visuals.widgets.hovered.weak_bg_fill = accent.linear_multiply(0.12);
            visuals.widgets.hovered.bg_stroke = Stroke::new(1.0, accent.linear_multiply(0.65));
            visuals.widgets.active.bg_fill = accent;
            visuals.widgets.active.weak_bg_fill = accent;
            visuals.widgets.active.fg_stroke = Stroke::new(1.0, Color32::WHITE);
            egui::Frame::new()
                .fill(if self.screen == Screen::Chooser {
                    Color32::TRANSPARENT
                } else {
                    background
                })
                .inner_margin(WINDOW_INNER_MARGIN)
                .show(ui, |ui| {
                    ui.set_min_size(ui.available_size());
                    match self.screen {
                        Screen::Chooser => self.chooser(ui),
                        Screen::Electronic => self.electronic_screen(ui),
                        Screen::Vibrational => self.vibrational_screen(ui),
                    }
                });
        });
        self.sync_window_icon(ui.ctx());
        self.show_dialogs(ui.ctx());
    }
}

impl eframe::App for CdarApp {
    fn logic(&mut self, _context: &Context, _frame: &mut eframe::Frame) {
        self.poll_workers();
    }

    fn ui(&mut self, ui: &mut Ui, _frame: &mut eframe::Frame) {
        if self.splash_started.elapsed() < SPLASH_DURATION {
            self.splash(ui);
        } else {
            ui.ctx().send_viewport_cmd(ViewportCommand::Visible(false));
            self.show_main_viewport(ui.ctx());
        }
    }

    fn clear_color(&self, _visuals: &egui::Visuals) -> [f32; 4] {
        self.background().to_normalized_gamma_f32()
    }
}

fn paint_horizontal_gradient(ui: &Ui, rect: egui::Rect, left: Color32, right: Color32) {
    let mut mesh = egui::Mesh::default();
    mesh.colored_vertex(rect.left_top(), left);
    mesh.colored_vertex(rect.right_top(), right);
    mesh.colored_vertex(rect.left_bottom(), left);
    mesh.colored_vertex(rect.right_bottom(), right);
    mesh.add_triangle(0, 1, 2);
    mesh.add_triangle(2, 1, 3);
    ui.painter().add(egui::Shape::mesh(mesh));
}

#[allow(clippy::too_many_arguments)]
fn mode_card(
    ui: &mut Ui,
    width: f32,
    height: f32,
    artwork: &TextureHandle,
    heading: &str,
    channels: &str,
    body: &str,
    accent: Color32,
    fill: Color32,
) -> bool {
    ui.allocate_ui_with_layout(
        Vec2::new(width, height),
        Layout::top_down(Align::Min),
        |ui| {
            ui.set_width(width);
            let hovered = ui.rect_contains_pointer(ui.max_rect());
            let card_fill = if hovered {
                fill.blend(accent.gamma_multiply(0.10))
            } else {
                fill
            };
            let card_shadow = if hovered {
                egui::epaint::Shadow {
                    offset: [0, 7],
                    blur: 18,
                    spread: 1,
                    color: accent.gamma_multiply(0.18),
                }
            } else {
                egui::epaint::Shadow::NONE
            };
            let response = egui::Frame::new()
                .fill(card_fill)
                .stroke(Stroke::new(
                    if hovered { 2.0 } else { 1.0 },
                    accent.linear_multiply(if hovered { 0.85 } else { 0.38 }),
                ))
                .shadow(card_shadow)
                .corner_radius(12)
                .inner_margin(16)
                .show(ui, |ui| {
                    ui.set_min_size(Vec2::new((width - 32.0).max(1.0), (height - 32.0).max(1.0)));
                    ui.set_max_width((width - 32.0).max(1.0));
                    ui.style_mut().wrap_mode = Some(TextWrapMode::Wrap);
                    ui.with_layout(Layout::top_down(Align::Center), |ui| {
                        ui.add(
                            egui::Image::from_texture(artwork)
                                .fit_to_exact_size(Vec2::splat(104.0))
                                .corner_radius(16),
                        );
                        ui.add_space(3.0);
                        ui.label(RichText::new(channels).strong().color(accent));
                        ui.add(
                            egui::Label::new(RichText::new(heading).size(18.0).strong().color(INK))
                                .wrap()
                                .halign(Align::Center),
                        );
                        ui.add_space(7.0);
                        for line in body.lines() {
                            ui.add(
                                egui::Label::new(
                                    RichText::new(format!("• {line}")).size(14.0).color(MUTED),
                                )
                                .wrap()
                                .halign(Align::Center),
                            );
                        }
                    });
                })
                .response
                .interact(Sense::click())
                .on_hover_cursor(egui::CursorIcon::PointingHand);
            response.clicked()
        },
    )
    .inner
}

fn column_combo(ui: &mut Ui, label: &str, id: &str, value: &mut usize, count: usize) {
    ui.horizontal(|ui| {
        ui.label(label);
        ComboBox::from_id_salt(id)
            .selected_text(format!("column {}", *value + 1))
            .show_ui(ui, |ui| {
                for index in 0..count {
                    ui.selectable_value(value, index, format!("column {}", index + 1));
                }
            });
    });
}

fn optional_column_combo(
    ui: &mut Ui,
    label: &str,
    id: &str,
    value: &mut Option<usize>,
    count: usize,
) {
    ui.horizontal(|ui| {
        ui.label(label);
        let selected = value.map_or_else(
            || "(none)".to_string(),
            |index| format!("column {}", index + 1),
        );
        ComboBox::from_id_salt(id)
            .selected_text(selected)
            .show_ui(ui, |ui| {
                ui.selectable_value(value, None, "(none)");
                for index in 0..count {
                    ui.selectable_value(value, Some(index), format!("column {}", index + 1));
                }
            });
    });
}

fn plot_points(x: &[f64], y: &[f64], scale: f64, low: f64, high: f64) -> PlotPoints<'static> {
    x.iter()
        .copied()
        .zip(y.iter().copied())
        .filter(|(x, y)| x.is_finite() && y.is_finite() && *x >= low && *x <= high)
        .map(|(x, y)| [x, y * scale])
        .collect()
}

fn spectral_grid_marks(input: GridInput, minimum_step: f64, quantum: f64) -> Vec<GridMark> {
    let ticks = rounded_axis_ticks(input.bounds.0, input.bounds.1, 6, minimum_step, quantum);
    ticks
        .values
        .into_iter()
        .map(|value| GridMark {
            value,
            step_size: ticks.step,
        })
        .collect()
}

fn live_x_axes(label: &'static str, scientific_small: bool) -> Vec<AxisHints<'static>> {
    vec![
        AxisHints::new_x()
            .min_thickness(AXIS_TICK_LABEL_CLEARANCE)
            .formatter(|_, _| String::new()),
        AxisHints::new_x().label(label).formatter(move |mark, _| {
            format_axis_tick(mark.value, mark.step_size, scientific_small)
        }),
    ]
}

fn live_y_axes(label: &'static str, scientific_small: bool) -> Vec<AxisHints<'static>> {
    vec![
        AxisHints::new_y()
            .min_thickness(AXIS_TICK_LABEL_CLEARANCE)
            .formatter(|_, _| String::new()),
        AxisHints::new_y().label(label).formatter(move |mark, _| {
            format_axis_tick(mark.value, mark.step_size, scientific_small)
        }),
    ]
}

fn paint_outward_axis_ticks(
    ui: &Ui,
    transform: &PlotTransform,
    x_minimum_step: f64,
    x_quantum: f64,
    y_minimum_step: f64,
    y_quantum: f64,
) {
    let bounds = transform.bounds();
    let minimum = bounds.min();
    let maximum = bounds.max();
    let x_ticks = rounded_axis_ticks(minimum[0], maximum[0], 6, x_minimum_step, x_quantum);
    let y_ticks = rounded_axis_ticks(minimum[1], maximum[1], 6, y_minimum_step, y_quantum);
    let frame = *transform.frame();
    let painter = ui.painter();
    let stroke = Stroke::new(1.0, BASELINE);
    for value in x_ticks.values {
        let x = transform.position_from_point_x(value);
        if x >= frame.left() - 0.5 && x <= frame.right() + 0.5 {
            painter.line_segment(
                [
                    egui::pos2(x, frame.bottom()),
                    egui::pos2(x, frame.bottom() + AXIS_TICK_LENGTH),
                ],
                stroke,
            );
        }
    }
    for value in y_ticks.values {
        let y = transform.position_from_point_y(value);
        if y >= frame.top() - 0.5 && y <= frame.bottom() + 0.5 {
            painter.line_segment(
                [
                    egui::pos2(frame.left() - AXIS_TICK_LENGTH, y),
                    egui::pos2(frame.left(), y),
                ],
                stroke,
            );
        }
    }
}

#[derive(Clone, Copy)]
struct LegendSeries<'a> {
    x: &'a [f64],
    y: &'a [f64],
    scale: f64,
}

#[derive(Clone, Copy)]
struct LegendLine<'a> {
    label: &'a str,
    color: Color32,
    width: f32,
    dashed: bool,
}

impl<'a> LegendLine<'a> {
    const fn solid(label: &'a str, color: Color32, width: f32) -> Self {
        Self {
            label,
            color,
            width,
            dashed: false,
        }
    }

    const fn dashed(label: &'a str, color: Color32, width: f32) -> Self {
        Self {
            label,
            color,
            width,
            dashed: true,
        }
    }
}

fn positive_axis_upper(series: &[LegendSeries<'_>], minimum_step: f64) -> f64 {
    let maximum = series
        .iter()
        .flat_map(|item| item.y.iter().map(move |value| value * item.scale))
        .filter(|value| value.is_finite())
        .fold(0.0_f64, f64::max);
    let maximum = if maximum > 0.0 { maximum } else { 1.0 };
    nice_axis_range(0.0, maximum * 1.05, 6, minimum_step, false, true).high
}

fn spectral_legend_corner(
    series: &[LegendSeries<'_>],
    low: f64,
    high: f64,
    reverse_x: bool,
) -> Corner {
    let mut y_low = f64::INFINITY;
    let mut y_high = f64::NEG_INFINITY;
    for item in series {
        for (&x, &y) in item.x.iter().zip(item.y) {
            let y = y * item.scale;
            if x >= low && x <= high && y.is_finite() {
                y_low = y_low.min(y);
                y_high = y_high.max(y);
            }
        }
    }
    if !y_low.is_finite() || !y_high.is_finite() || y_high <= y_low || high <= low {
        return Corner::RightTop;
    }
    let candidates = [
        Corner::RightTop,
        Corner::LeftTop,
        Corner::RightBottom,
        Corner::LeftBottom,
    ];
    candidates
        .into_iter()
        .min_by_key(|corner| {
            series
                .iter()
                .flat_map(|item| {
                    item.x
                        .iter()
                        .zip(item.y)
                        .map(move |(x, y)| (*x, *y * item.scale))
                })
                .filter(|(x, y)| {
                    if *x < low || *x > high || !y.is_finite() {
                        return false;
                    }
                    let mut x_fraction = (*x - low) / (high - low);
                    if reverse_x {
                        x_fraction = 1.0 - x_fraction;
                    }
                    let y_fraction = (*y - y_low) / (y_high - y_low);
                    let in_horizontal = match corner {
                        Corner::LeftTop | Corner::LeftBottom => x_fraction <= 0.40,
                        Corner::RightTop | Corner::RightBottom => x_fraction >= 0.60,
                    };
                    let in_vertical = match corner {
                        Corner::LeftTop | Corner::RightTop => y_fraction >= 0.58,
                        Corner::LeftBottom | Corner::RightBottom => y_fraction <= 0.42,
                    };
                    in_horizontal && in_vertical
                })
                .count()
        })
        .unwrap_or(Corner::RightTop)
}

fn paint_spectral_legend(
    ui: &Ui,
    id: egui::Id,
    transform: &PlotTransform,
    series: &[LegendSeries<'_>],
    entries: &[LegendLine<'_>],
    range: (f64, f64),
    reverse_x: bool,
) {
    if entries.is_empty() {
        return;
    }
    let frame = transform.frame();
    let font_id = egui::TextStyle::Small.resolve(ui.style());
    let painter = ui.painter();
    let galleys: Vec<_> = entries
        .iter()
        .map(|entry| painter.layout_no_wrap(entry.label.to_owned(), font_id.clone(), INK))
        .collect();
    let swatch_width = 28.0;
    let swatch_gap = 7.0;
    let row_height = 18.0;
    let text_width = galleys
        .iter()
        .map(|galley| galley.size().x)
        .fold(0.0_f32, f32::max);
    let size = Vec2::new(
        swatch_width + swatch_gap + text_width,
        row_height * entries.len() as f32,
    );
    let inset = 13.0;
    let (low, high) = range;
    let corner = spectral_legend_corner(series, low, high, reverse_x);
    let left = match corner {
        Corner::LeftTop | Corner::LeftBottom => frame.left() + inset,
        Corner::RightTop | Corner::RightBottom => frame.right() - inset - size.x,
    };
    let top = match corner {
        Corner::LeftTop | Corner::RightTop => frame.top() + inset,
        Corner::LeftBottom | Corner::RightBottom => frame.bottom() - inset - size.y,
    };

    let mut hovered = None;
    for row in 0..entries.len() {
        let row_rect = egui::Rect::from_min_size(
            egui::pos2(left - 3.0, top + row as f32 * row_height),
            Vec2::new(size.x + 6.0, row_height),
        );
        if ui
            .interact(row_rect, id.with(row), Sense::hover())
            .hovered()
        {
            hovered = Some(row);
        }
    }
    if let Some(row) = hovered
        && let (Some(series), Some(entry)) = (series.get(row), entries.get(row))
    {
        paint_legend_highlight(ui, transform, series, entry, low, high);
    }

    for ((entry, galley), row) in entries.iter().zip(galleys.iter()).zip(0..) {
        let center_y = top + row_height * (row as f32 + 0.5);
        let start_x = left;
        let hovered_width = if hovered == Some(row) { 1.2 } else { 0.0 };
        if entry.dashed {
            let segment = 6.0;
            let gap = 4.0;
            let mut x = start_x;
            while x < start_x + swatch_width {
                let end = (x + segment).min(start_x + swatch_width);
                painter.line_segment(
                    [egui::pos2(x, center_y), egui::pos2(end, center_y)],
                    Stroke::new(entry.width + hovered_width, entry.color),
                );
                x += segment + gap;
            }
        } else {
            painter.line_segment(
                [
                    egui::pos2(start_x, center_y),
                    egui::pos2(start_x + swatch_width, center_y),
                ],
                Stroke::new(entry.width + hovered_width, entry.color),
            );
        }
        let text_position = egui::pos2(
            start_x + swatch_width + swatch_gap,
            center_y - galley.size().y * 0.5,
        );
        painter.galley(text_position, galley.clone(), INK);
        if hovered == Some(row) {
            painter.galley(text_position + egui::vec2(0.65, 0.0), galley.clone(), INK);
        }
    }
}

fn paint_legend_highlight(
    ui: &Ui,
    transform: &PlotTransform,
    series: &LegendSeries<'_>,
    entry: &LegendLine<'_>,
    low: f64,
    high: f64,
) {
    let painter = ui.painter().with_clip_rect(*transform.frame());
    let mut segment = Vec::new();
    let paint_segment = |points: &mut Vec<egui::Pos2>| {
        if points.len() >= 2 {
            let stroke = Stroke::new(entry.width + 2.2, entry.color);
            if entry.dashed {
                painter.extend(egui::Shape::dashed_line(points, stroke, 6.0, 4.0));
            } else {
                painter.add(egui::Shape::line(std::mem::take(points), stroke));
            }
        }
        points.clear();
    };
    for (&x, &y) in series.x.iter().zip(series.y) {
        let y = y * series.scale;
        if x.is_finite() && y.is_finite() && x >= low && x <= high {
            segment.push(transform.position_from_point(&PlotPoint::new(x, y)));
        } else {
            paint_segment(&mut segment);
        }
    }
    paint_segment(&mut segment);
}

fn add_peak_arrows(
    plot_ui: &mut egui_plot::PlotUi<'_>,
    prefix: &str,
    features: &[crate::electronic::Feature],
) {
    for (suffix, sign, shape) in [
        ("positive", 1, MarkerShape::Down),
        ("negative", -1, MarkerShape::Up),
    ] {
        let points: PlotPoints<'static> = features
            .iter()
            .filter(|feature| feature.sign == sign)
            .map(|feature| [feature.x, feature.y])
            .collect();
        if points.points().is_empty() {
            continue;
        }
        plot_ui.points(
            Points::new("", points)
                .id(format!("{prefix}-{suffix}"))
                .shape(shape)
                .color(PEAK_GREEN)
                .filled(false)
                .radius(5.0)
                .allow_hover(false),
        );
    }
}

fn result_tone(assignment: &str, reliability: &str, fallback: Color32) -> Color32 {
    let text = format!("{assignment} {reliability}").to_ascii_lowercase();
    if text.contains("not reliable") || text.contains("match failed") {
        RESULT_BAD
    } else if text.contains("inconclusive")
        || text.contains("low reliability")
        || text.contains("ambiguous")
    {
        RESULT_CAUTION
    } else if text.contains("high reliability") || text.contains("moderate reliability") {
        RESULT_GOOD
    } else {
        fallback
    }
}

fn conformer_details(
    ui: &mut Ui,
    selected: bool,
    name: &str,
    energy: &str,
    weight: &str,
    count: &str,
) -> bool {
    ui.spacing_mut().item_spacing.x = 6.0;
    let energy_width = 61.0;
    let weight_width = 50.0;
    let count_width = 82.0;
    let name_width = (ui.available_width()
        - energy_width
        - weight_width
        - count_width
        - ui.spacing().item_spacing.x * 3.0)
        .max(64.0);
    let clicked = ui
        .add_sized(
            [name_width, 24.0],
            egui::Button::selectable(selected, name).truncate(),
        )
        .on_hover_text(name)
        .clicked();
    for (text, width) in [
        (energy, energy_width),
        (weight, weight_width),
        (count, count_width),
    ] {
        ui.add_sized(
            [width, 20.0],
            egui::Label::new(RichText::new(text).size(11.0).color(MUTED))
                .truncate()
                .halign(Align::RIGHT),
        )
        .on_hover_text(text);
    }
    clicked
}

fn tab_bar(ui: &mut Ui, tab: &mut ControlTab) {
    let gap = 8.0;
    let tab_width = ((ui.available_width() - gap * 2.0) / 3.0).max(72.0);
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = gap;
        for (value, label) in [
            (ControlTab::Fit, "Fit"),
            (ControlTab::Conformers, "Conformers"),
            (ControlTab::View, "View / Export"),
        ] {
            if ui
                .add_sized(
                    [tab_width, 30.0],
                    egui::Button::selectable(*tab == value, label),
                )
                .clicked()
            {
                *tab = value;
            }
        }
    });
    ui.separator();
}

fn heading(ui: &mut Ui, text: &str, color: Color32) {
    ui.label(RichText::new(text).size(15.0).strong().color(color));
}

fn header_widget_visuals(ui: &mut Ui, accent: Color32) {
    let widgets = &mut ui.visuals_mut().widgets;
    widgets.hovered.bg_fill = accent;
    widgets.hovered.weak_bg_fill = accent;
    widgets.hovered.fg_stroke = Stroke::new(1.5, Color32::WHITE);
    widgets.hovered.bg_stroke = Stroke::new(1.0, Color32::WHITE);
    widgets.active.bg_fill = accent.gamma_multiply(0.82);
    widgets.active.weak_bg_fill = accent.gamma_multiply(0.82);
    widgets.active.fg_stroke = Stroke::new(1.5, Color32::WHITE);
}

fn header_action_button(ui: &mut Ui, text: &str) -> egui::Response {
    ui.add(
        egui::Button::new(text)
            .small()
            .min_size(Vec2::new(0.0, HEADER_ACTION_BUTTON_HEIGHT)),
    )
}

fn control_row<R>(
    ui: &mut Ui,
    label: impl Into<egui::WidgetText>,
    add_control: impl FnOnce(&mut Ui) -> R,
) -> R {
    let label = label.into();
    ui.horizontal(|ui| {
        ui.set_min_height(30.0);
        ui.spacing_mut().item_spacing.x = 12.0;
        let available = ui.available_width();
        let label_width = (available - 160.0).clamp(130.0, 184.0);
        ui.allocate_ui_with_layout(
            Vec2::new(label_width, 30.0),
            Layout::left_to_right(Align::Center),
            |ui| {
                ui.add(
                    egui::Label::new(label)
                        .truncate()
                        .show_tooltip_when_elided(true),
                );
            },
        );
        ui.allocate_ui_with_layout(
            Vec2::new(ui.available_width(), 30.0),
            Layout::left_to_right(Align::Center),
            add_control,
        )
        .inner
    })
    .inner
}

fn aligned_f64_slider(
    ui: &mut Ui,
    value: &mut f64,
    range: std::ops::RangeInclusive<f64>,
    step: f64,
    decimals: usize,
) -> bool {
    let before = *value;
    let value_width = 72.0_f32.min((ui.available_width() * 0.42).max(54.0));
    let slider_width = (ui.available_width() - value_width - 10.0).max(54.0);
    let slider_changed = ui
        .add_sized(
            [slider_width, 30.0],
            Slider::new(value, range.clone())
                .step_by(step)
                .show_value(false),
        )
        .changed();
    let value_changed = ui
        .add_sized(
            [value_width, 30.0],
            DragValue::new(value)
                .speed(step)
                .range(range)
                .fixed_decimals(decimals),
        )
        .changed();
    (slider_changed || value_changed) && slider_value_materially_changed(before, *value, step)
}

fn slider_value_materially_changed(before: f64, after: f64, step: f64) -> bool {
    (after - before).abs() > step.abs().max(f64::EPSILON) * 1.0e-6
}

fn workspace_separator(ui: &mut Ui, color: Color32) -> egui::Rect {
    let (rect, _) = ui.allocate_exact_size(Vec2::new(ui.available_width(), 1.0), Sense::hover());
    ui.painter().line_segment(
        [rect.left_center(), rect.right_center()],
        Stroke::new(1.25, color),
    );
    rect
}

fn workspace_vertical_separator(ui: &mut Ui, width: f32, height: f32, color: Color32) {
    let (rect, _) = ui.allocate_exact_size(Vec2::new(width, height), Sense::hover());
    ui.painter().line_segment(
        [rect.center_top(), rect.center_bottom()],
        Stroke::new(1.25, color),
    );
}

fn hovered_plot_coordinates<R>(
    response: &egui_plot::PlotResponse<R>,
    channel: &'static str,
    x_unit: &'static str,
    y_unit: Option<&'static str>,
) -> Option<PlotCoordinates> {
    let pointer = response.response.hover_pos()?;
    if !response.transform.frame().contains(pointer) {
        return None;
    }
    let point = response.transform.value_from_position(pointer);
    Some(PlotCoordinates {
        channel,
        x: point.x,
        y: point.y,
        x_unit,
        y_unit,
    })
}

fn status_bar(
    ui: &mut Ui,
    status: &str,
    coordinates: Option<PlotCoordinates>,
    accent: Color32,
    divider: Color32,
) -> (egui::Rect, egui::Rect, egui::Rect, bool) {
    let (coordinate_label, has_coordinates) = coordinates.map_or_else(
        || {
            (
                "Hover cursor over a spectrum for x/y coordinates".to_string(),
                false,
            )
        },
        |value| (value.label(), true),
    );
    let mut log_rect = egui::Rect::NOTHING;
    let mut coordinate_rect = egui::Rect::NOTHING;
    let mut clicked = false;
    let outer_rect = egui::Frame::new()
        .outer_margin(egui::Margin {
            left: 0,
            right: 0,
            top: 0,
            bottom: WINDOW_INNER_MARGIN,
        })
        .show(ui, |ui| {
            let total = ui.available_width();
            let coordinate_width =
                STATUS_COORDINATE_WIDTH.min((total - WORKSPACE_DIVIDER_WIDTH - 80.0).max(1.0));
            let log_width = (total - WORKSPACE_DIVIDER_WIDTH - coordinate_width).max(1.0);
            let card = || {
                egui::Frame::new()
                    .fill(CARD)
                    .stroke(Stroke::new(1.0, accent.linear_multiply(0.18)))
                    .corner_radius(8)
                    .inner_margin(egui::Margin::symmetric(8, 6))
            };
            ui.horizontal(|ui| {
                ui.spacing_mut().item_spacing.x = 0.0;
                let response = card()
                    .show(ui, |ui| {
                        let width = (log_width - 18.0).max(1.0);
                        ui.set_width(width);
                        ui.add_sized(
                            [width, STATUS_ROW_HEIGHT],
                            egui::Label::new(
                                RichText::new(status.lines().next().unwrap_or(status))
                                    .size(STATUS_FONT_SIZE)
                                    .color(MUTED),
                            )
                            .truncate()
                            .show_tooltip_when_elided(false),
                        );
                    })
                    .response
                    .interact(Sense::click())
                    .on_hover_cursor(egui::CursorIcon::PointingHand)
                    .on_hover_text("Click to open the complete activity log.");
                log_rect = response.rect;
                clicked = response.clicked();
                workspace_vertical_separator(
                    ui,
                    WORKSPACE_DIVIDER_WIDTH,
                    log_rect.height(),
                    divider,
                );
                coordinate_rect = card()
                    .show(ui, |ui| {
                        let width = (coordinate_width - 18.0).max(1.0);
                        ui.set_width(width);
                        let mut text = RichText::new(coordinate_label).size(STATUS_FONT_SIZE);
                        text = if has_coordinates {
                            text.strong().color(accent)
                        } else {
                            text.color(MUTED)
                        };
                        ui.add_sized(
                            [width, STATUS_ROW_HEIGHT],
                            egui::Label::new(text).truncate(),
                        );
                    })
                    .response
                    .rect;
            });
        })
        .response
        .rect;
    (log_rect, coordinate_rect, outer_rect, clicked)
}

impl CdarApp {
    fn electronic_plots(&mut self, ui: &mut Ui) -> Option<PlotCoordinates> {
        let index = self.electronic.selected;
        let show_grid = self.electronic.show_grid;
        let show_baseline = self.electronic.show_baseline;
        let reset_view = self.electronic.reset_plot_view;
        self.electronic.reset_plot_view = false;
        let dataset = &mut self.electronic.datasets[index];
        let compound_id = dataset.state.id();
        let curves = dataset.curves();
        let report = dataset.show_peaks.then(|| dataset.band_report());
        let experimental_uv = dataset.experimental_uv.clone();
        let experimental_ecd = dataset.experimental_ecd.clone();
        let low = dataset.wavelength_min.min(dataset.wavelength_max);
        let high = dataset.wavelength_min.max(dataset.wavelength_max);
        let scale_uv = dataset.scale_uv;
        let scale_ecd = dataset.scale_ecd;
        let ecd_axis_label = dataset.ecd_unit.axis_label();
        let show_enantiomer = dataset.show_enantiomer;
        let show_sticks = dataset.show_sticks;
        let calculated_label = if dataset.fitted {
            ELECTRONIC_CALCULATED_FITTED_LABEL
        } else {
            "Calculated"
        };
        let enantiomer_label = if dataset.fitted {
            ELECTRONIC_ENANTIOMER_FITTED_LABEL
        } else {
            "Enantiomer"
        };
        let plot_height = stacked_spectrum_height(ui.available_height());
        let plot_width = ui.available_width().max(120.0);

        let mut uv_legend_series = Vec::new();
        let mut uv_legend_entries = Vec::new();
        if let Some(spectrum) = &experimental_uv {
            uv_legend_series.push(LegendSeries {
                x: &spectrum.x,
                y: &spectrum.y,
                scale: 1.0,
            });
            uv_legend_entries.push(LegendLine::solid("Experimental", INK, 1.9));
        }
        if let Some(curves) = &curves {
            uv_legend_series.push(LegendSeries {
                x: &curves.wavelength,
                y: &curves.uv,
                scale: scale_uv,
            });
            uv_legend_entries.push(LegendLine::solid(calculated_label, CALC_RED, 1.8));
        }
        let uv_axis_upper = positive_axis_upper(&uv_legend_series, 0.1);

        heading(ui, "UV absorbance", ECD_ACCENT);
        let mut uv_plot = Plot::new(format!("electronic_uv_{compound_id}"))
            .height(plot_height)
            .width(plot_width)
            .custom_x_axes(live_x_axes("Wavelength (nm)", false))
            .custom_y_axes(live_y_axes("Absorbance (AU)", false))
            .x_grid_spacer(|input| spectral_grid_marks(input, 10.0, 10.0))
            .y_grid_spacer(|input| spectral_grid_marks(input, 0.1, 0.0))
            .default_x_bounds(low, high)
            .set_margin_fraction(Vec2::ZERO)
            .include_y(0.0)
            .include_y(uv_axis_upper)
            .show_grid(show_grid)
            .grid_color(GRID)
            .show_crosshair(false);
        if reset_view {
            uv_plot = uv_plot.reset();
        }
        let uv_plot = uv_plot.show(ui, |plot_ui| {
            if show_baseline {
                plot_ui.hline(
                    HLine::new("", 0.0)
                        .color(BASELINE)
                        .width(1.0)
                        .allow_hover(false),
                );
            }
            if let Some(spectrum) = &experimental_uv {
                plot_ui.line(
                    Line::new(
                        "Experimental",
                        plot_points(&spectrum.x, &spectrum.y, 1.0, low, high),
                    )
                    .color(INK)
                    .width(1.9),
                );
            }
            if let Some(curves) = &curves {
                plot_ui.line(
                    Line::new(
                        calculated_label,
                        plot_points(&curves.wavelength, &curves.uv, scale_uv, low, high),
                    )
                    .color(CALC_RED)
                    .width(1.8),
                );
                if show_sticks {
                    let display_peak = experimental_uv
                        .as_ref()
                        .map_or(0.0, |s| max_abs(&s.y))
                        .max(max_abs(&curves.uv) * scale_uv.abs())
                        .max(1.0);
                    add_sticks(
                        plot_ui,
                        "uv-stick",
                        &curves.stick_nm,
                        &curves.stick_f,
                        display_peak,
                        true,
                        CALC_RED,
                        low,
                        high,
                    );
                }
            }
            if let Some(channel) = report.as_ref().and_then(|value| value.uv.as_ref()) {
                add_peak_arrows(plot_ui, "uv-band", &channel.experimental);
            }
        });
        paint_outward_axis_ticks(ui, &uv_plot.transform, 10.0, 10.0, 0.1, 0.0);
        paint_spectral_legend(
            ui,
            ui.id().with(("electronic_uv_legend", index)),
            &uv_plot.transform,
            &uv_legend_series,
            &uv_legend_entries,
            (low, high),
            false,
        );
        let mut coordinates = hovered_plot_coordinates(&uv_plot, "UV", "nm", None);

        let mut ecd_legend_series = Vec::new();
        let mut ecd_legend_entries = Vec::new();
        if let Some(spectrum) = &experimental_ecd {
            ecd_legend_series.push(LegendSeries {
                x: &spectrum.x,
                y: &spectrum.y,
                scale: 1.0,
            });
            ecd_legend_entries.push(LegendLine::solid("Experimental", INK, 1.9));
        }
        if let Some(curves) = &curves {
            ecd_legend_series.push(LegendSeries {
                x: &curves.wavelength,
                y: &curves.ecd,
                scale: scale_ecd,
            });
            ecd_legend_entries.push(LegendLine::solid(calculated_label, CALC_RED, 1.8));
            if show_enantiomer {
                ecd_legend_series.push(LegendSeries {
                    x: &curves.wavelength,
                    y: &curves.ecd,
                    scale: -scale_ecd,
                });
                ecd_legend_entries.push(LegendLine::dashed(enantiomer_label, ENANT_BLUE, 1.5));
            }
        }

        heading(ui, "Electronic circular dichroism", ECD_ACCENT);
        let mut ecd_plot = Plot::new(format!("electronic_ecd_{compound_id}"))
            .height(plot_height)
            .width(plot_width)
            .custom_x_axes(live_x_axes("Wavelength (nm)", false))
            .custom_y_axes(live_y_axes(ecd_axis_label, false))
            .x_grid_spacer(|input| spectral_grid_marks(input, 10.0, 10.0))
            .y_grid_spacer(|input| spectral_grid_marks(input, 0.0, 0.0))
            .default_x_bounds(low, high)
            .set_margin_fraction(Vec2::new(0.0, 0.05))
            .include_y(0.0)
            .show_grid(show_grid)
            .grid_color(GRID)
            .show_crosshair(false);
        if reset_view {
            ecd_plot = ecd_plot.reset();
        }
        let ecd_plot = ecd_plot.show(ui, |plot_ui| {
            if show_baseline {
                plot_ui.hline(
                    HLine::new("", 0.0)
                        .color(BASELINE)
                        .width(1.0)
                        .allow_hover(false),
                );
            }
            if let Some(spectrum) = &experimental_ecd {
                plot_ui.line(
                    Line::new(
                        "Experimental",
                        plot_points(&spectrum.x, &spectrum.y, 1.0, low, high),
                    )
                    .color(INK)
                    .width(1.9),
                );
            }
            if let Some(curves) = &curves {
                plot_ui.line(
                    Line::new(
                        calculated_label,
                        plot_points(&curves.wavelength, &curves.ecd, scale_ecd, low, high),
                    )
                    .color(CALC_RED)
                    .width(1.8),
                );
                if show_enantiomer {
                    plot_ui.line(
                        Line::new(
                            enantiomer_label,
                            plot_points(&curves.wavelength, &curves.ecd, -scale_ecd, low, high),
                        )
                        .color(ENANT_BLUE)
                        .width(1.5)
                        .style(LineStyle::dashed_dense()),
                    );
                }
                if show_sticks {
                    let display_peak = experimental_ecd
                        .as_ref()
                        .map_or(0.0, |s| max_abs(&s.y))
                        .max(max_abs(&curves.ecd) * scale_ecd.abs())
                        .max(1.0);
                    add_sticks(
                        plot_ui,
                        "ecd-stick",
                        &curves.stick_nm,
                        &curves.stick_r,
                        display_peak,
                        false,
                        CALC_RED,
                        low,
                        high,
                    );
                }
            }
            if let Some(channel) = report.as_ref().and_then(|value| value.ecd.as_ref()) {
                add_peak_arrows(plot_ui, "ecd-band", &channel.experimental);
            }
        });
        paint_outward_axis_ticks(ui, &ecd_plot.transform, 10.0, 10.0, 0.0, 0.0);
        paint_spectral_legend(
            ui,
            ui.id().with(("electronic_ecd_legend", index)),
            &ecd_plot.transform,
            &ecd_legend_series,
            &ecd_legend_entries,
            (low, high),
            false,
        );
        if let Some(ecd_coordinates) = hovered_plot_coordinates(
            &ecd_plot,
            "ECD",
            "nm",
            Some(dataset.ecd_unit.coordinate_unit()),
        ) {
            coordinates = Some(ecd_coordinates);
        }
        coordinates
    }

    fn electronic_controls(&mut self, ui: &mut Ui) {
        heading(ui, "Input data", ECD_ACCENT);
        let mut load_combined = false;
        let mut load_uv = false;
        let mut load_ecd = false;
        let mut add_qm = false;
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing = Vec2::new(10.0, 8.0);
            if ui.button("UV + ECD…").clicked() {
                load_combined = true;
            }
            if ui.button("UV…").clicked() {
                load_uv = true;
            }
            if ui.button("ECD…").clicked() {
                load_ecd = true;
            }
            if ui.button("Gaussian LOGs…").clicked() {
                add_qm = true;
            }
        });
        ui.label(
            RichText::new(
                "Gaussian LOGs containing completed optimization and time-dependent calculations; CSV, TXT, DAT, XY, or TSV measured spectra.",
            )
            .small()
            .color(MUTED),
        );
        let index = self.electronic.selected;
        control_row(ui, "ECD data units", |ui| {
            let unit = &mut self.electronic.datasets[index].ecd_unit;
            let response = ComboBox::from_id_salt("electronic_ecd_unit")
                .selected_text(unit.label())
                .width(ui.available_width().min(190.0))
                .show_ui(ui, |ui| {
                    ui.selectable_value(unit, EcdUnit::Millidegrees, "Millidegrees (mdeg)");
                    ui.selectable_value(
                        unit,
                        EcdUnit::MolarEllipticity,
                        "Molar ellipticity (deg·cm²·dmol⁻¹)",
                    );
                });
            response.response.on_hover_text(
                "Labels imported ECD values and exports. CDAR does not numerically convert between mdeg and molar ellipticity because that requires concentration and path length.",
            );
        });
        ui.add_space(5.0);
        tab_bar(ui, &mut self.electronic.tab);
        match self.electronic.tab {
            ControlTab::Fit => self.electronic_fit_controls(ui),
            ControlTab::Conformers => self.electronic_conformer_controls(ui),
            ControlTab::View => self.electronic_view_controls(ui),
        }
        if load_combined {
            self.load_electronic_combined();
        }
        if load_uv {
            self.load_electronic_channel(VibKind::Ir);
        }
        if load_ecd {
            self.load_electronic_channel(VibKind::Vcd);
        }
        if add_qm
            && let Some(paths) = rfd::FileDialog::new()
                .set_title("Add Gaussian UV/ECD calculations")
                .add_filter("Gaussian output", &["log", "out", "txt"])
                .pick_files()
        {
            self.add_electronic_qm(paths);
        }
    }

    fn electronic_fit_controls(&mut self, ui: &mut Ui) {
        let mut start_fit = false;
        let mut reset = false;
        let mut autoscale = false;
        let fitting = self.electronic.fit_receiver.is_some();

        let objective_before = self.electronic.objective;
        control_row(ui, "Fitting objective", |ui| {
            ComboBox::from_id_salt("electronic_objective")
                .selected_text(self.electronic.objective.label())
                .width(ui.available_width().min(210.0))
                .show_ui(ui, |ui| {
                    for value in [
                        FitObjective::PeakShape,
                        FitObjective::CrossSection,
                        FitObjective::LeastSquares,
                        FitObjective::Cosine,
                    ] {
                        ui.selectable_value(&mut self.electronic.objective, value, value.label());
                    }
                });
        });

        let index = self.electronic.selected;
        {
            let dataset = &mut self.electronic.datasets[index];
            let mut invalidate = false;
            if objective_before != self.electronic.objective {
                dataset.invalidate_fit();
            }
            control_row(ui, "Band profile", |ui| {
                let before = dataset.profile;
                ComboBox::from_id_salt("electronic_profile")
                    .selected_text(dataset.profile.label())
                    .width(ui.available_width().min(150.0))
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut dataset.profile, Profile::Gaussian, "Gaussian");
                        ui.selectable_value(
                            &mut dataset.profile,
                            Profile::Lorentzian,
                            "Lorentzian",
                        );
                    });
                invalidate |= before != dataset.profile;
            });
            control_row(ui, "Rotatory-strength gauge", |ui| {
                let before = dataset.gauge;
                ComboBox::from_id_salt("electronic_gauge")
                    .selected_text(dataset.gauge.label())
                    .width(ui.available_width().min(160.0))
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut dataset.gauge, Gauge::Velocity, "Velocity");
                        ui.selectable_value(&mut dataset.gauge, Gauge::Length, "Length");
                    });
                invalidate |= before != dataset.gauge;
            });
            ui.add_space(4.0);
            if control_row(ui, "UV bandwidth σ (eV)", |ui| {
                aligned_f64_slider(ui, &mut dataset.sigma_uv, 0.03..=0.60, 0.005, 3)
            }) {
                if dataset.link_sigma {
                    dataset.sigma_ecd = dataset.sigma_uv;
                }
                invalidate = true;
            }
            if ui
                .checkbox(&mut dataset.link_sigma, "Use the UV bandwidth for ECD")
                .changed()
            {
                if dataset.link_sigma {
                    dataset.sigma_ecd = dataset.sigma_uv;
                }
                invalidate = true;
            }
            ui.add_enabled_ui(!dataset.link_sigma, |ui| {
                if control_row(ui, "ECD bandwidth σ (eV)", |ui| {
                    aligned_f64_slider(ui, &mut dataset.sigma_ecd, 0.03..=0.60, 0.005, 3)
                }) {
                    invalidate = true;
                }
            });
            if control_row(ui, "Wavelength shift (nm)", |ui| {
                aligned_f64_slider(ui, &mut dataset.shift, -80.0..=80.0, 0.25, 2)
            }) {
                invalidate = true;
            }
            ui.separator();
            ui.label("Display scales");
            control_row(ui, "UV scale", |ui| {
                ui.add_sized(
                    [ui.available_width().min(96.0), 30.0],
                    DragValue::new(&mut dataset.scale_uv)
                        .speed(DISPLAY_SCALE_DRAG_SPEED)
                        .fixed_decimals(DISPLAY_SCALE_DECIMALS)
                        .range(0.0..=1.0e6),
                );
            });
            control_row(ui, "ECD scale", |ui| {
                let input_width = ui.available_width().min(92.0);
                ui.add_sized(
                    [input_width, 30.0],
                    DragValue::new(&mut dataset.scale_ecd)
                        .speed(DISPLAY_SCALE_DRAG_SPEED)
                        .fixed_decimals(DISPLAY_SCALE_DECIMALS)
                        .range(0.0..=1.0e6),
                );
                if ui
                    .add_sized([54.0, 30.0], egui::Button::new("Auto"))
                    .clicked()
                {
                    autoscale = true;
                }
            });
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing.x = 22.0;
                ui.checkbox(&mut dataset.show_enantiomer, "Enantiomer");
                ui.checkbox(&mut dataset.show_sticks, "Sticks");
                ui.checkbox(&mut dataset.show_peaks, "Bands");
            });
            control_row(ui, "Band sensitivity", |ui| {
                let before = dataset.sensitivity;
                ComboBox::from_id_salt("electronic_sensitivity")
                    .selected_text(dataset.sensitivity.label())
                    .width(ui.available_width().min(160.0))
                    .show_ui(ui, |ui| {
                        ui.selectable_value(
                            &mut dataset.sensitivity,
                            Sensitivity::Permissive,
                            "permissive",
                        );
                        ui.selectable_value(
                            &mut dataset.sensitivity,
                            Sensitivity::Normal,
                            "normal",
                        );
                        ui.selectable_value(
                            &mut dataset.sensitivity,
                            Sensitivity::Strict,
                            "strict",
                        );
                    });
                if before != dataset.sensitivity {
                    dataset.invalidate_fit();
                }
            });
            if invalidate {
                dataset.invalidate_fit();
                dataset.invalidate();
            }
        }
        ui.add_space(8.0);
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 12.0;
            if ui
                .add_enabled(!fitting, egui::Button::new("Auto-Fit"))
                .clicked()
            {
                start_fit = true;
            }
            if ui.button("Reset").clicked() {
                reset = true;
            }
            if fitting {
                ui.add(egui::Spinner::new().size(24.0).color(ECD_ACCENT));
            }
        });
        ui.label(RichText::new("The UV fit anchors the shift. ECD bandwidth is then optimized independently, with a tightly UV-constrained ESI refinement.").small().color(MUTED));

        if autoscale {
            self.electronic.datasets[index].autoscale();
            self.electronic
                .activity
                .push("Scaled calculated curves to the measured peak amplitudes.".into());
        }
        if reset {
            self.electronic.datasets[index].reset_fit();
            self.electronic.activity.push("Fit reset.".into());
        }
        if start_fit {
            self.start_electronic_fit(ui.ctx().clone());
        }
        ui.add_space(14.0);
        ui.separator();
        self.electronic_results(ui);
    }

    fn electronic_conformer_controls(&mut self, ui: &mut Ui) {
        let mut add = false;
        let mut remove = false;
        let mut autogroup = false;
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing = Vec2::new(10.0, 8.0);
            if ui.button("Add Gaussian LOGs…").clicked() {
                add = true;
            }
            if ui.button("Remove selected").clicked() {
                remove = true;
            }
            if ui.button("Split by prefix").clicked() {
                autogroup = true;
            }
        });
        ui.add_space(4.0);
        let index = self.electronic.selected;
        let selected = &mut self.electronic.selected_conformers;
        let dataset = &mut self.electronic.datasets[index];
        let _ = dataset.curves();
        let energies: Vec<f64> = dataset
            .conformers
            .iter()
            .filter_map(Conformer::energy)
            .collect();
        let minimum = energies.iter().copied().reduce(f64::min);
        let mut changed = false;
        ScrollArea::vertical()
            .max_height(310.0)
            .id_salt("electronic_conformers")
            .show(ui, |ui| {
                ui.set_width((ui.available_width() - 10.0).max(1.0));
                for (row, conformer) in dataset.conformers.iter_mut().enumerate() {
                    let selected_row = selected.contains(&row);
                    let energy_text = conformer.energy().zip(minimum).map_or_else(
                        || "ΔG —".to_string(),
                        |(energy, base)| format!("ΔG {:.2}", (energy - base) * HARTREE_TO_KCAL),
                    );
                    ui.horizontal(|ui| {
                        changed |= ui.checkbox(&mut conformer.include, "").changed();
                        let weight_text = format!("w {:.3}", conformer.weight);
                        let state_text = format!("{} states", conformer.nstates());
                        if conformer_details(
                            ui,
                            selected_row,
                            &conformer.name,
                            &energy_text,
                            &weight_text,
                            &state_text,
                        ) {
                            if selected_row {
                                selected.remove(&row);
                            } else {
                                selected.insert(row);
                            }
                        }
                    });
                }
            });
        if dataset.conformers.is_empty() {
            ui.label(
                RichText::new("No conformers loaded.")
                    .italics()
                    .color(MUTED),
            );
        }
        ui.separator();
        control_row(ui, "Temperature (K)", |ui| {
            if ui
                .add_sized(
                    [ui.available_width().min(90.0), 30.0],
                    DragValue::new(&mut dataset.temperature)
                        .speed(1.0)
                        .range(1.0..=2000.0),
                )
                .changed()
            {
                changed = true;
            }
        });
        if changed {
            dataset.invalidate_fit();
            dataset.invalidate();
            dataset.autoscale();
        }
        if remove && !selected.is_empty() {
            let mut row = 0usize;
            dataset.conformers.retain(|_| {
                let keep = !selected.contains(&row);
                row += 1;
                keep
            });
            selected.clear();
            dataset.invalidate_fit();
            dataset.invalidate();
            dataset.autoscale();
            self.electronic
                .activity
                .push("Removed selected conformers.".into());
        }
        if add
            && let Some(paths) = rfd::FileDialog::new()
                .set_title("Add Gaussian UV/ECD calculations")
                .add_filter("Gaussian output", &["log", "out", "txt"])
                .pick_files()
        {
            self.add_electronic_qm(paths);
        }
        if autogroup {
            self.autogroup_electronic();
        }
        ui.label(RichText::new("Each Gaussian LOG must contain a completed ground-state optimization calculation, Gibbs free energy, and complete UV/ECD data from a time-dependent calculation. Boltzmann weighting uses the optimization Gibbs free energies; ΔG is reported in kcal/mol. Automatic duplicate detection requires |ΔG| ≤ 0.20 kcal/mol, symmetry-aware RMSD ≤ 0.10 Å, maximum atom displacement ≤ 0.15 Å, frequency RMSD ≤ 2.0 cm⁻¹, and maximum frequency difference ≤ 3.0 cm⁻¹.").text_style(egui::TextStyle::Body).color(MUTED));
    }

    fn electronic_view_controls(&mut self, ui: &mut Ui) {
        let index = self.electronic.selected;
        let mut fit_data = false;
        let mut range_changed = false;
        let mut export_figure_requested = false;
        let mut export_data_requested = false;
        heading(ui, "Plot appearance", ECD_ACCENT);
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing.x = 22.0;
            ui.checkbox(&mut self.electronic.show_baseline, "Zero baseline");
            ui.checkbox(&mut self.electronic.show_grid, "Gridlines");
        });
        ui.checkbox(
            &mut self.electronic.datasets[index].show_export_legend,
            "Legend in exported figures",
        );
        if ui.button("Re-center spectra").clicked() {
            self.electronic.reset_plot_view = true;
        }
        ui.separator();
        {
            let dataset = &mut self.electronic.datasets[index];
            let mut invalidate = false;
            heading(ui, "Display range", ECD_ACCENT);
            control_row(ui, "Minimum wavelength", |ui| {
                let changed = ui
                    .add_sized(
                        [ui.available_width().min(105.0), 30.0],
                        DragValue::new(&mut dataset.wavelength_min)
                            .speed(1.0)
                            .range(1.0..=100_000.0)
                            .suffix(" nm"),
                    )
                    .changed();
                invalidate |= changed;
                range_changed |= changed;
            });
            control_row(ui, "Maximum wavelength", |ui| {
                let changed = ui
                    .add_sized(
                        [ui.available_width().min(105.0), 30.0],
                        DragValue::new(&mut dataset.wavelength_max)
                            .speed(1.0)
                            .range(1.0..=100_000.0)
                            .suffix(" nm"),
                    )
                    .changed();
                invalidate |= changed;
                range_changed |= changed;
            });
            if ui.button(FIT_RANGE_TO_DATA_LABEL).clicked() {
                fit_data = true;
            }
            ui.separator();
            control_row(ui, "Curve points", |ui| {
                if ui
                    .add_sized(
                        [ui.available_width().min(90.0), 30.0],
                        DragValue::new(&mut dataset.npoints)
                            .speed(50)
                            .range(200..=12_000),
                    )
                    .changed()
                {
                    invalidate = true;
                }
            });
            control_row(ui, "Raster export DPI", |ui| {
                ui.add_sized(
                    [ui.available_width().min(80.0), 30.0],
                    DragValue::new(&mut dataset.dpi).speed(25).range(72..=2400),
                );
            });
            if invalidate {
                dataset.invalidate();
            }
            ui.add_space(10.0);
            if ui.button("Export figure  (PNG / PDF / SVG)…").clicked() {
                export_figure_requested = true;
            }
            if ui.button("Export spectra data  (CSV / TXT)…").clicked() {
                export_data_requested = true;
            }
        }
        if fit_data {
            self.electronic.datasets[index].set_default_range();
            range_changed = true;
            self.electronic
                .activity
                .push("Display range fitted to loaded data.".into());
        }
        if range_changed {
            self.electronic.reset_plot_view = true;
        }
        if export_figure_requested {
            self.export_electronic_figure();
        }
        if export_data_requested {
            self.export_electronic_data();
        }
    }

    fn electronic_results(&mut self, ui: &mut Ui) {
        let index = self.electronic.selected;
        let dataset = &mut self.electronic.datasets[index];
        let evaluation = dataset.evaluate();
        heading(ui, "Assignment", ECD_ACCENT);
        if evaluation.assignment.is_empty() {
            ui.add(
                egui::Label::new(
                    RichText::new("Load a calculation and measured spectrum to evaluate.")
                        .color(MUTED),
                )
                .wrap(),
            );
        } else {
            let tone = result_tone(&evaluation.assignment, &evaluation.reliability, ECD_ACCENT);
            ui.add(
                egui::Label::new(
                    RichText::new(&evaluation.assignment)
                        .size(17.0)
                        .strong()
                        .color(tone),
                )
                .wrap(),
            );
            ui.add(
                egui::Label::new(
                    RichText::new(&evaluation.reliability)
                        .size(13.5)
                        .strong()
                        .color(tone),
                )
                .wrap(),
            );
        }
        ui.separator();
        ui.label(
            RichText::new(
                "Metric values: green = strong or favoured; amber = limited; red = weak or unfavoured.",
            )
            .small()
            .color(MUTED),
        );
        let (calculated_tone, enantiomer_tone) = comparison_tones(
            evaluation.similarity_same,
            evaluation.similarity_enantiomer,
            0.05,
        );
        metric(
            ui,
            "UV cosine similarity",
            evaluation.uv_similarity,
            false,
            higher_score_tone(evaluation.uv_similarity, 0.90, 0.75),
        );
        metric(
            ui,
            "S(MSI), calculated",
            evaluation.similarity_same,
            false,
            calculated_tone,
        );
        metric(
            ui,
            "S(MSI), enantiomer",
            evaluation.similarity_enantiomer,
            false,
            enantiomer_tone,
        );
        metric(
            ui,
            "ESI",
            evaluation.esi,
            true,
            magnitude_tone(evaluation.esi, 0.20, 0.05),
        );
        metric(
            ui,
            "Fit-quality ceiling",
            evaluation.fit_quality,
            false,
            higher_score_tone(evaluation.fit_quality, 0.75, 0.45),
        );
        metric(
            ui,
            "Discrimination",
            evaluation.discrimination,
            true,
            magnitude_tone(evaluation.discrimination, 0.45, 0.20),
        );
        metric(
            ui,
            "Sign agreement",
            evaluation.sign_agreement,
            false,
            higher_score_tone(evaluation.sign_agreement, 0.65, 0.35),
        );
        metric(
            ui,
            "Shape where signed",
            evaluation.shape_where_signed,
            false,
            higher_score_tone(evaluation.shape_where_signed, 0.60, 0.35),
        );
        ui.separator();
        let report = dataset.band_report();
        if let Some(channel) = report.uv {
            ui.add(
                egui::Label::new(
                    RichText::new(format!(
                        "UV bands: {} experimental, {} calculated, {} matched",
                        channel.experimental.len(),
                        channel.calculated.len(),
                        channel.matched
                    ))
                    .color(INK),
                )
                .wrap(),
            );
        }
        if let Some(channel) = report.ecd {
            ui.add(
                egui::Label::new(
                    RichText::new(format!(
                        "ECD bands: {} experimental, {} calculated, {} matched",
                        channel.experimental.len(),
                        channel.calculated.len(),
                        channel.matched
                    ))
                    .color(INK),
                )
                .wrap(),
            );
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn add_sticks(
    plot_ui: &mut egui_plot::PlotUi<'_>,
    prefix: &str,
    x: &[f64],
    strength: &[f64],
    display_peak: f64,
    positive_only: bool,
    color: Color32,
    low: f64,
    high: f64,
) {
    let stick_peak = max_abs(strength);
    if stick_peak <= 0.0 {
        return;
    }
    for (index, (&x, &strength)) in x.iter().zip(strength).enumerate() {
        if x < low || x > high || !x.is_finite() || !strength.is_finite() {
            continue;
        }
        let value = if positive_only {
            strength.abs()
        } else {
            strength
        };
        let height = value / stick_peak * display_peak * 0.24;
        let points: PlotPoints<'static> = vec![[x, 0.0], [x, height]].into();
        plot_ui.line(
            Line::new("", points)
                .id(format!("{prefix}-{index}"))
                .color(color)
                .width(0.7)
                .allow_hover(false),
        );
    }
}

fn higher_score_tone(value: Option<f64>, good: f64, caution: f64) -> Color32 {
    match value {
        None => MUTED,
        Some(value) if value >= good => RESULT_GOOD,
        Some(value) if value >= caution => RESULT_CAUTION,
        Some(_) => RESULT_BAD,
    }
}

fn magnitude_tone(value: Option<f64>, good: f64, caution: f64) -> Color32 {
    higher_score_tone(value.map(f64::abs), good, caution)
}

fn comparison_tones(
    first: Option<f64>,
    second: Option<f64>,
    minimum_separation: f64,
) -> (Color32, Color32) {
    let (Some(first), Some(second)) = (first, second) else {
        return (MUTED, MUTED);
    };
    if (first - second).abs() < minimum_separation {
        (RESULT_CAUTION, RESULT_CAUTION)
    } else if first > second {
        (RESULT_GOOD, RESULT_BAD)
    } else {
        (RESULT_BAD, RESULT_GOOD)
    }
}

fn metric(ui: &mut Ui, label: &str, value: Option<f64>, signed: bool, tone: Color32) {
    let width = ui.available_width();
    let block_width = width.min(330.0);
    let value_width = 72.0_f32.min(block_width * 0.28);
    let gap = 16.0;
    let label_width = (block_width - value_width - gap).max(80.0);
    ui.allocate_ui_with_layout(
        Vec2::new(width, 24.0),
        Layout::left_to_right(Align::Center),
        |ui| {
            ui.spacing_mut().item_spacing.x = 0.0;
            ui.add_space(((width - block_width) * 0.5).max(0.0));
            ui.add_sized(
                [label_width, 22.0],
                egui::Label::new(RichText::new(label).size(13.5).color(INK))
                    .truncate()
                    .halign(Align::RIGHT),
            )
            .on_hover_text(label);
            ui.add_space(gap);
            let text = value.map_or_else(
                || "—".to_string(),
                |value| {
                    if signed {
                        format!("{value:+.3}")
                    } else {
                        format!("{value:.3}")
                    }
                },
            );
            ui.add_sized(
                [value_width, 22.0],
                egui::Label::new(RichText::new(text).size(13.5).strong().color(tone))
                    .halign(Align::LEFT),
            );
        },
    );
}

impl CdarApp {
    fn load_electronic_combined(&mut self) {
        let Some(path) = rfd::FileDialog::new()
            .set_title("Load measured UV and/or ECD")
            .add_filter("Spectral data", &["csv", "txt", "dat", "xy", "tsv"])
            .pick_file()
        else {
            return;
        };
        match parse_experimental(&path) {
            Ok(parsed) => {
                self.route_electronic_experimental(parsed, file_label(&path));
            }
            Err(error) => {
                self.electronic_error(format!("Could not read {}:\n{error}", path.display()))
            }
        }
    }

    /// `VibKind::Ir` denotes UV here and `VibKind::Vcd` denotes ECD. Both
    /// pairs share the same one-sided/bipolar data-role semantics.
    fn load_electronic_channel(&mut self, channel: VibKind) {
        let title = match channel {
            VibKind::Ir => "Load measured UV absorbance",
            VibKind::Vcd => "Load measured ECD / CD",
        };
        let Some(path) = rfd::FileDialog::new()
            .set_title(title)
            .add_filter("Spectral data", &["csv", "txt", "dat", "xy", "tsv"])
            .pick_file()
        else {
            return;
        };
        let parsed = match parse_experimental(&path) {
            Ok(parsed) => parsed,
            Err(error) => {
                self.electronic_error(format!("Could not read {}:\n{error}", path.display()));
                return;
            }
        };
        if parsed.columns.is_empty() {
            self.electronic_error("No intensity column was found.".into());
            return;
        }
        let (uv, ecd) = guess_roles(&parsed.columns);
        let column = match channel {
            VibKind::Ir => uv.unwrap_or(0),
            VibKind::Vcd => ecd.unwrap_or(0),
        }
        .min(parsed.columns.len() - 1);
        let spectrum = Spectrum::new(parsed.wavelength, parsed.columns[column].clone()).sorted();
        if let Err(error) = spectrum.validate_wavelength_domain() {
            self.electronic_error(error.to_string());
            return;
        }
        let label = file_label(&path);
        let index = self.electronic.selected;
        let dataset = &mut self.electronic.datasets[index];
        match channel {
            VibKind::Ir => {
                dataset.experimental_uv = Some(spectrum);
                dataset.experimental_source =
                    append_source(&dataset.experimental_source, "UV", &label);
            }
            VibKind::Vcd => {
                dataset.experimental_ecd = Some(spectrum);
                dataset.experimental_source =
                    append_source(&dataset.experimental_source, "ECD", &label);
            }
        }
        dataset.invalidate_fit();
        dataset.set_default_range();
        dataset.invalidate();
        dataset.autoscale();
        let kept = match channel {
            VibKind::Ir if dataset.has_experimental_ecd() => " (ECD kept)",
            VibKind::Vcd if dataset.has_experimental_uv() => " (UV kept)",
            _ => "",
        };
        self.electronic.reset_plot_view = true;
        self.electronic.activity.push(format!(
            "Loaded {} from {label}{kept}.",
            if channel == VibKind::Ir { "UV" } else { "ECD" }
        ));
    }

    fn route_electronic_experimental(&mut self, parsed: ParsedExperimental, label: String) -> bool {
        let (uv, ecd) = guess_roles(&parsed.columns);
        if parsed.ncolumns > 3 || (uv.is_none() && ecd.is_none()) {
            self.electronic
                .activity
                .push(format!("Awaiting column mapping for {label}."));
            self.pending_electronic.push_back(PendingElectronicImport {
                dataset_id: self.electronic.datasets[self.electronic.selected]
                    .state
                    .id(),
                wavelength: 0,
                uv: uv.map(|index| index + 1),
                ecd: ecd.map(|index| index + 1),
                parsed,
                label,
            });
            return true;
        }
        self.apply_electronic_columns(
            self.electronic.datasets[self.electronic.selected]
                .state
                .id(),
            parsed,
            label,
            0,
            uv.map(|index| index + 1),
            ecd.map(|index| index + 1),
        )
    }

    fn apply_mapped_electronic(&mut self, pending: &PendingElectronicImport) -> bool {
        self.apply_electronic_columns(
            pending.dataset_id,
            pending.parsed.clone(),
            pending.label.clone(),
            pending.wavelength,
            pending.uv,
            pending.ecd,
        )
    }

    fn apply_electronic_columns(
        &mut self,
        dataset_id: u64,
        parsed: ParsedExperimental,
        label: String,
        wavelength: usize,
        uv: Option<usize>,
        ecd: Option<usize>,
    ) -> bool {
        if uv == Some(wavelength) || ecd == Some(wavelength) || (uv.is_some() && uv == ecd) {
            self.electronic_error("Choose distinct wavelength, UV, and ECD columns.".into());
            return false;
        }
        let mut columns = Vec::with_capacity(parsed.columns.len() + 1);
        columns.push(parsed.wavelength);
        columns.extend(parsed.columns);
        let Some(x) = columns.get(wavelength).cloned() else {
            self.electronic_error("The selected wavelength column is unavailable.".into());
            return false;
        };
        if x.len() < 2
            || x.iter().any(|v| !v.is_finite() || *v <= 0.0)
            || min_max(&x).is_none_or(|(lo, hi)| hi <= lo)
        {
            self.electronic_error(
                "Wavelengths must be positive and span at least two distinct values.".into(),
            );
            return false;
        }
        let Some(dataset) = self
            .electronic
            .datasets
            .iter_mut()
            .find(|d| d.state.id() == dataset_id)
        else {
            self.electronic_error("The compound for this measurement was split or removed; import the file into its intended compound again.".into());
            return true; // Do not keep an orphaned mapping at the front of the queue.
        };
        let mut loaded = Vec::new();
        if let Some(column) = uv.and_then(|column| columns.get(column)) {
            dataset.experimental_uv = Some(Spectrum::new(x.clone(), column.clone()).sorted());
            loaded.push("UV");
        }
        if let Some(column) = ecd.and_then(|column| columns.get(column)) {
            dataset.experimental_ecd = Some(Spectrum::new(x, column.clone()).sorted());
            loaded.push("ECD");
        }
        if loaded.is_empty() {
            self.electronic_error("No UV or ECD intensity column was assigned.".into());
            return false;
        }
        dataset.experimental_source = label.clone();
        dataset.invalidate_fit();
        dataset.set_default_range();
        dataset.invalidate();
        dataset.autoscale();
        self.electronic.reset_plot_view = true;
        self.electronic.activity.push(format!(
            "Loaded measured {} from {label} into {}.",
            loaded.join(" + "),
            dataset.name
        ));
        true
    }

    fn add_electronic_qm(&mut self, paths: Vec<PathBuf>) {
        let dataset = &mut self.electronic.datasets[self.electronic.selected];
        let report = import_conformers(
            &mut dataset.conformers,
            paths,
            |path| parse_qm(path),
            |c| &c.path,
            dedupe_electronic,
        );
        if report.changed() {
            self.electronic.selected_conformers.clear();
            if !dataset.has_any_experimental() {
                dataset.set_default_range();
            }
            dataset.invalidate_fit();
            dataset.invalidate();
            dataset.autoscale();
        }
        self.electronic.activity.push(report.text());
    }

    fn ingest_electronic_paths(&mut self, paths: Vec<PathBuf>) {
        let (calculations, measurements): (Vec<_>, Vec<_>) = paths
            .into_iter()
            .partition(|path| looks_like_gaussian_log(path));
        let mut notes = Vec::new();
        let had_calculations = !calculations.is_empty();
        if had_calculations {
            self.add_electronic_qm(calculations);
        }
        let mut failures = Vec::new();
        let mut loaded = 0;
        let queued_before = self.pending_electronic.len();
        for path in measurements {
            match parse_experimental(&path) {
                Ok(parsed) => {
                    if self.route_electronic_experimental(parsed, file_label(&path)) {
                        loaded += 1;
                    } else {
                        failures.push(format!(
                            "{}: {}",
                            path.display(),
                            self.error
                                .as_deref()
                                .unwrap_or("could not assign measurement columns")
                        ));
                    }
                }
                Err(error) => failures.push(format!("{}: {error}", path.display())),
            }
        }
        if loaded > 0 {
            let queued = self.pending_electronic.len() - queued_before;
            notes.push(format!("Read {loaded} measured spectrum file(s): {} loaded, {queued} awaiting column mapping.", loaded - queued));
        }
        if !failures.is_empty() {
            notes.push(format!(
                "MEASUREMENT IMPORT ERRORS ({} files)\n{}",
                failures.len(),
                failures.join("\n")
            ));
        }
        if !notes.is_empty() {
            self.electronic.activity.push(notes.join("\n\n"));
        } else if !had_calculations {
            self.electronic
                .activity
                .push(NO_USABLE_IMPORT_MESSAGE.into());
        }
    }

    fn autogroup_electronic(&mut self) {
        use std::collections::BTreeMap;
        let index = self.electronic.selected;
        let original = self.electronic.datasets[index].clone();
        let mut groups: BTreeMap<String, Vec<Conformer>> = BTreeMap::new();
        for conformer in &original.conformers {
            let prefix = conformer
                .name
                .rsplit_once('_')
                .map_or_else(|| conformer.name.clone(), |(prefix, _)| prefix.to_string());
            groups.entry(prefix).or_default().push(conformer.clone());
        }
        if groups.len() <= 1 {
            self.electronic
                .activity
                .push("Conformers share one filename prefix; nothing was split.".into());
            return;
        }
        let count = groups.len();
        let mut replacements: Vec<ElectronicDataset> = groups
            .into_iter()
            .map(|(name, conformers)| {
                let mut dataset = original.clone();
                dataset.state = Default::default();
                dataset.name = name;
                dataset.conformers = conformers;
                dataset.experimental_uv = None;
                dataset.experimental_ecd = None;
                dataset.experimental_source.clear();
                dataset.invalidate_fit();
                dataset.set_default_range();
                dataset
            })
            .collect();
        let target = replacements
            .iter()
            .position(|dataset| original.name.contains(&dataset.name))
            .unwrap_or(0);
        replacements[target].experimental_uv = original.experimental_uv;
        replacements[target].experimental_ecd = original.experimental_ecd;
        replacements[target].experimental_source = original.experimental_source;
        replacements[target].set_default_range();
        replacements[target].autoscale();
        self.electronic.datasets.splice(index..=index, replacements);
        self.electronic.selected = index;
        self.electronic.selected_conformers.clear();
        self.electronic
            .activity
            .push(format!("Split into {count} compounds by filename prefix."));
    }

    fn start_electronic_fit(&mut self, context: Context) {
        if self.electronic.fit_receiver.is_some() {
            return;
        }
        let index = self.electronic.selected;
        let dataset = &self.electronic.datasets[index];
        if !dataset.has_calculation() {
            self.electronic_error("Load validated Gaussian calculations first.".into());
            return;
        }
        if !dataset.has_any_experimental() {
            self.electronic_error("Load measured UV or ECD data first.".into());
            return;
        }
        let input = ElectronicAutoFitInput::from_dataset(dataset, self.electronic.objective);
        let (sender, receiver) = mpsc::channel();
        let stamp = dataset.state.stamp();
        self.electronic.fit_receiver = Some(receiver);
        self.electronic.activity.push(
            if dataset.has_experimental_uv() && dataset.has_experimental_ecd() {
                "Fitting UV bandwidth and shift, then ECD bandwidth independently…".into()
            } else {
                "Running the bandwidth/shift grid search…".into()
            },
        );
        std::thread::spawn(move || {
            let result = run_electronic_auto_fit(input).map_err(|error| error.to_string());
            let _ = sender.send((stamp, result));
            context.request_repaint();
        });
    }

    fn finish_electronic_fit(&mut self, stamp: FitStamp, output: ElectronicAutoFitOutput) {
        let Some(dataset) = self
            .electronic
            .datasets
            .iter_mut()
            .find(|d| d.state.stamp() == stamp)
        else {
            self.electronic.activity.push("Discarded an outdated fit because the compound or fit inputs changed. Run Auto-Fit again to fit the current inputs.".into());
            return;
        };
        if let Some(sigma) = output.sigma_uv {
            dataset.sigma_uv = sigma;
        }
        dataset.shift = output.shift;
        if output.ecd_fitted {
            if let Some(sigma) = output.sigma_ecd {
                dataset.sigma_ecd = sigma;
            }
            dataset.link_sigma = false;
        }
        dataset.invalidate();
        dataset.autoscale();
        dataset.fitted = true;
        let mut parts = Vec::new();
        if let Some(value) = output.sigma_uv {
            parts.push(format!("σ(UV)={value:.3}"));
        }
        if output.ecd_fitted
            && let Some(value) = output.sigma_ecd
        {
            parts.push(format!("σ(ECD)={value:.3}"));
        }
        parts.push(format!("shift={:+.2} nm", output.shift));
        if let Some(value) = output.uv_similarity {
            parts.push(format!("S(UV)={value:.3}"));
        }
        let mut status = format!("Fit complete: {}", parts.join(", "));
        if output.shift_adjusted_for_esi
            && let (Some(before), Some(after)) =
                (output.esi_before_adjustment, dataset.evaluate().esi)
        {
            status.push_str(&format!(
                " (UV-constrained ESI refinement: {before:.3} → {:.3})",
                after.abs()
            ));
        }
        self.electronic.activity.push(status);
    }

    fn export_electronic_figure(&mut self) {
        let index = self.electronic.selected;
        let dataset = &mut self.electronic.datasets[index];
        if !dataset.has_any_experimental() && !dataset.has_calculation() {
            self.electronic_error("Nothing is available to export yet.".into());
            return;
        }
        let filename = format!("{}_ECD.png", sanitize_filename(&dataset.name));
        let Some(path) = rfd::FileDialog::new()
            .set_title("Export figure")
            .set_file_name(filename)
            .add_filter("Figure", &["png", "pdf", "svg"])
            .save_file()
        else {
            return;
        };
        let spec = electronic_figure(dataset);
        match write_figure(&spec, &path, dataset.dpi) {
            Ok(()) => self
                .electronic
                .activity
                .push(format!("Figure exported: {}", path.display())),
            Err(error) => self.electronic_error(format!("Figure export failed:\n{error}")),
        }
    }

    fn export_electronic_data(&mut self) {
        let index = self.electronic.selected;
        let dataset = &mut self.electronic.datasets[index];
        let filename = format!("{}_spectra.csv", sanitize_filename(&dataset.name));
        let Some(path) = rfd::FileDialog::new()
            .set_title("Export spectra data")
            .set_file_name(filename)
            .add_filter("Spectral table", &["csv", "txt"])
            .save_file()
        else {
            return;
        };
        match write_electronic_data(dataset, &path) {
            Ok(()) => self
                .electronic
                .activity
                .push(format!("Data exported: {}", path.display())),
            Err(error) => self.electronic_error(format!("Data export failed:\n{error}")),
        }
    }
}

fn file_label(path: &Path) -> String {
    path.file_name()
        .and_then(|value| value.to_str())
        .unwrap_or("file")
        .to_string()
}

fn append_source(previous: &str, channel: &str, label: &str) -> String {
    let entry = format!("{channel}:{label}");
    if previous.is_empty() {
        entry
    } else {
        format!("{previous}; {entry}")
    }
}

#[cfg(test)]
mod state_tests {
    use super::*;

    fn app() -> CdarApp {
        CdarApp {
            splash_started: Instant::now(),
            main_window_startup: MainWindowStartup::Pending,
            screen: Screen::Electronic,
            icon_screen: None,
            assets: AppAssets::load(&Context::default()),
            #[cfg(target_os = "windows")]
            native_icons: None,
            electronic: ElectronicState::default(),
            vibrational: VibrationalState::default(),
            info: None,
            error: None,
            rename: None,
            pending_electronic: VecDeque::new(),
        }
    }

    fn ecd_output() -> ElectronicAutoFitOutput {
        ElectronicAutoFitOutput {
            sigma_uv: Some(0.3),
            sigma_ecd: Some(0.25),
            shift: 10.0,
            ecd_fitted: true,
            ..Default::default()
        }
    }

    #[test]
    fn activity_dialogs_follow_live_mode_history_and_keep_import_reports_once() {
        let mut app = app();
        let path = std::env::temp_dir().join(format!("cdar-history-{}.log", std::process::id()));
        std::fs::write(&path, " Entering Gaussian System\n #p opt freq\n").unwrap();
        app.ingest_electronic_paths(vec![path.clone()]);
        let ecd_import = app.electronic.activity.latest().to_owned();
        app.ingest_vibrational_paths(vec![path.clone()]);
        let vcd_import = app.vibrational.activity.latest().to_owned();
        std::fs::remove_file(path).unwrap();
        for (mode, title, report) in [
            (Screen::Electronic, "UV/ECD activity log", &ecd_import),
            (Screen::Vibrational, "IR/VCD activity log", &vcd_import),
        ] {
            assert!(report.contains("REJECTED"), "{report}");
            app.info = Some(InfoDialog::Activity(mode));
            let (actual_title, text, is_log) = app.info_content().unwrap();
            assert_eq!(actual_title, title);
            assert!(is_log);
            assert_eq!(text.matches(report.as_str()).count(), 1);
            assert!(!text.contains(NO_USABLE_IMPORT_MESSAGE));
        }
        // An open UV/ECD dialog follows UV/ECD events even after switching modes.
        app.info = Some(InfoDialog::Activity(Screen::Electronic));
        app.screen = Screen::Vibrational;
        app.electronic_error("Electronic export failed.".into());
        app.vibrational_error("IR import failed.".into());
        let (_, text, _) = app.info_content().unwrap();
        assert!(text.contains(&ecd_import));
        assert!(text.ends_with("Error: Electronic export failed."));
        assert!(!text.contains("IR import failed."));
        app.info = Some(InfoDialog::Activity(Screen::Vibrational));
        assert!(
            app.info_content()
                .unwrap()
                .1
                .ends_with("Error: IR import failed.")
        );
        // Worker results append; they do not erase preceding imports and errors.
        app.finish_electronic_fit(app.electronic.datasets[0].state.stamp(), ecd_output());
        assert!(
            app.electronic
                .activity
                .text()
                .contains("Electronic export failed.")
        );
        assert!(
            app.electronic
                .activity
                .latest()
                .starts_with("Fit complete:")
        );
    }

    #[test]
    fn analogous_shared_messages_are_identical_between_modes() {
        let mut app = app();
        assert_eq!(
            app.electronic.activity.latest(),
            app.vibrational.activity.latest()
        );
        assert_eq!(app.electronic.activity.latest(), INITIAL_ACTIVITY_MESSAGE);

        app.ingest_electronic_paths(Vec::new());
        app.ingest_vibrational_paths(Vec::new());
        assert_eq!(
            app.electronic.activity.latest(),
            app.vibrational.activity.latest()
        );
        assert_eq!(app.electronic.activity.latest(), NO_USABLE_IMPORT_MESSAGE);
        assert_eq!(FIT_RANGE_TO_DATA_LABEL, "Fit range to data");
    }

    #[test]
    fn developer_credit_and_unbranded_workspace_titles_stay_consistent() {
        assert_eq!(DEVELOPERS, "Jared Wood and OpenAI GPT-5.6 Sol");
        assert!(ABOUT.contains(&format!("Authors / developers: {DEVELOPERS}")));
        for title in [ELECTRONIC_WORKSPACE_TITLE, VIBRATIONAL_WORKSPACE_TITLE] {
            assert!(!title.contains("CDAR"));
        }
    }

    #[test]
    fn late_worker_results_cannot_undo_resets_in_either_mode() {
        let mut app = app();
        let (send_e, recv_e) = mpsc::channel();
        let (send_v, recv_v) = mpsc::channel();
        app.electronic.fit_receiver = Some(recv_e);
        app.vibrational.fit_receiver = Some(recv_v);
        send_e
            .send((app.electronic.datasets[0].state.stamp(), Ok(ecd_output())))
            .unwrap();
        send_v
            .send((
                app.vibrational.datasets[0].state.stamp(),
                Ok(VibFitResult {
                    scale: 0.95,
                    gamma: 10.0,
                    ir_similarity: 0.9,
                }),
            ))
            .unwrap();
        app.electronic.datasets[0].reset_fit();
        app.vibrational.datasets[0].reset_fit();
        app.poll_workers();
        assert!(!app.electronic.datasets[0].fitted);
        assert_eq!(app.electronic.datasets[0].shift, 0.0);
        assert!(!app.vibrational.datasets[0].fitted);
        assert_eq!(app.vibrational.datasets[0].scale, 0.98);
        assert!(app.electronic.fit_receiver.is_none());
        assert!(app.vibrational.fit_receiver.is_none());
        assert!(app.error.is_none());
    }

    #[test]
    fn split_preserves_units_and_settings_and_fit_follows_its_compound() {
        let mut app = app();
        let original = &mut app.electronic.datasets[0];
        original.ecd_unit = EcdUnit::MolarEllipticity;
        original.temperature = 333.0;
        original.gauge = Gauge::Length;
        original.conformers = ["alpha_1", "beta_1"]
            .into_iter()
            .map(|name| Conformer {
                name: name.into(),
                ..Default::default()
            })
            .collect();
        let removed_stamp = original.state.stamp();
        app.electronic
            .datasets
            .push(ElectronicDataset::new("Waiting for fit"));
        let retained_stamp = app.electronic.datasets[1].state.stamp();
        app.autogroup_electronic();
        assert_eq!(app.electronic.datasets.len(), 3);
        for dataset in &app.electronic.datasets[..2] {
            assert_eq!(dataset.ecd_unit, EcdUnit::MolarEllipticity);
            assert_eq!(dataset.temperature, 333.0);
            assert_eq!(dataset.gauge, Gauge::Length);
            assert!(!dataset.fitted);
        }
        app.finish_electronic_fit(removed_stamp, ecd_output());
        assert!(app.electronic.datasets.iter().all(|d| !d.fitted));
        app.finish_electronic_fit(retained_stamp, ecd_output());
        assert!(!app.electronic.datasets[1].fitted);
        assert!(app.electronic.datasets[2].fitted);
        assert_eq!(app.electronic.datasets[2].shift, 10.0);
    }

    #[test]
    fn display_changes_do_not_discard_valid_background_fits() {
        let mut app = app();
        let e = app.electronic.datasets[0].state.stamp();
        let v = app.vibrational.datasets[0].state.stamp();
        app.electronic.datasets[0].wavelength_max = 600.;
        app.electronic.datasets[0].invalidate();
        app.vibrational.datasets[0].show_enantiomer = true;
        app.vibrational.datasets[0].view_high = 2000;
        app.vibrational.datasets[0].invalidate();
        app.finish_electronic_fit(e, ecd_output());
        app.finish_vibrational_fit(
            v,
            VibFitResult {
                scale: 0.97,
                gamma: 5.,
                ir_similarity: 0.9,
            },
        );
        assert!(app.electronic.datasets[0].fitted);
        assert!(app.vibrational.datasets[0].fitted);
        assert_eq!(app.vibrational.datasets[0].view_high, 2000);
    }

    #[test]
    fn mapping_queue_keeps_all_files_and_their_original_compounds() {
        let mut app = app();
        let parsed = crate::electronic::parse_experimental_text("200,1,-2,3\n210,2,3,4").unwrap();
        app.route_electronic_experimental(parsed.clone(), "first.csv".into());
        app.electronic
            .datasets
            .push(ElectronicDataset::new("Other"));
        app.electronic.selected = 1;
        app.route_electronic_experimental(parsed, "second.csv".into());
        assert_eq!(app.pending_electronic.len(), 2);
        let first = app.pending_electronic.pop_front().unwrap();
        assert!(app.apply_mapped_electronic(&first));
        assert!(app.electronic.datasets[0].has_any_experimental());
        assert!(!app.electronic.datasets[1].has_any_experimental());
        let second = app.pending_electronic.pop_front().unwrap();
        app.electronic.selected = 0;
        assert!(app.apply_mapped_electronic(&second));
        assert_eq!(app.electronic.datasets[0].experimental_source, "first.csv");
        assert_eq!(app.electronic.datasets[1].experimental_source, "second.csv");
        let mut invalid = second;
        invalid.uv = Some(invalid.wavelength);
        assert!(!app.apply_mapped_electronic(&invalid));
        let bad = crate::electronic::parse_experimental_text("-10,1\n-20,2").unwrap();
        assert!(!app.route_electronic_experimental(bad, "invalid.csv".into()));
        assert_eq!(app.electronic.datasets[0].experimental_source, "first.csv");
    }
}

impl CdarApp {
    fn vibrational_plots(&mut self, ui: &mut Ui) -> Option<PlotCoordinates> {
        let index = self.vibrational.selected;
        let show_grid = self.vibrational.show_grid;
        let show_baseline = self.vibrational.show_baseline;
        let reset_view = self.vibrational.reset_plot_view;
        self.vibrational.reset_plot_view = false;
        let dataset = &mut self.vibrational.datasets[index];
        let compound_id = dataset.state.id();
        let evaluation = dataset.evaluate();
        let raw_curves = dataset.curves();
        let experimental_ir = dataset.experimental_ir.clone();
        let experimental_vcd = dataset.experimental_vcd.clone();
        let matched = evaluation.curves.clone();
        let fitted = dataset.fitted;
        let calculated_label = if fitted {
            VIB_CALCULATED_FITTED_LABEL
        } else {
            "Calculated"
        };
        let show_enantiomer = dataset.show_enantiomer;
        let show_sticks = dataset.show_sticks;
        let (low, high) = dataset.view_span();
        let plot_height = stacked_spectrum_height(ui.available_height());
        let plot_width = ui.available_width().max(120.0);

        let mut ir_legend_series = Vec::new();
        let mut ir_legend_entries = Vec::new();
        if let Some(curves) = &matched {
            ir_legend_series.extend([
                LegendSeries {
                    x: &curves.frequency,
                    y: &curves.ir_observed,
                    scale: 1.0,
                },
                LegendSeries {
                    x: &curves.frequency,
                    y: &curves.ir_calculated,
                    scale: 1.0,
                },
            ]);
            ir_legend_entries.extend([
                LegendLine::solid("Experimental", INK, 1.9),
                LegendLine::solid(calculated_label, VCD_ACCENT, 1.8),
            ]);
        } else {
            if let Some(spectrum) = &experimental_ir {
                ir_legend_series.push(LegendSeries {
                    x: &spectrum.x,
                    y: &spectrum.y,
                    scale: 1.0,
                });
                ir_legend_entries.push(LegendLine::solid("Experimental", INK, 1.9));
            }
            if let Some(curves) = &raw_curves {
                ir_legend_series.push(LegendSeries {
                    x: &curves.frequency,
                    y: &curves.ir,
                    scale: 1.0,
                });
                ir_legend_entries.push(LegendLine::solid("Calculated", VCD_ACCENT, 1.8));
            }
        }
        let ir_axis_upper = positive_axis_upper(&ir_legend_series, 0.1);

        heading(ui, "Infrared absorbance", VCD_ACCENT);
        let mut ir_plot = Plot::new(format!("vibrational_ir_{compound_id}"))
            .height(plot_height)
            .width(plot_width)
            .invert_x(true)
            .custom_x_axes(live_x_axes("Wavenumber (cm⁻¹)", false))
            .custom_y_axes(live_y_axes("Absorbance (AU)", false))
            .x_grid_spacer(|input| spectral_grid_marks(input, 50.0, 50.0))
            .y_grid_spacer(|input| spectral_grid_marks(input, 0.1, 0.0))
            .default_x_bounds(low, high)
            .set_margin_fraction(Vec2::ZERO)
            .include_y(0.0)
            .include_y(ir_axis_upper)
            .show_grid(show_grid)
            .grid_color(GRID)
            .show_crosshair(false);
        if reset_view {
            ir_plot = ir_plot.reset();
        }
        let ir_plot = ir_plot.show(ui, |plot_ui| {
            if show_baseline {
                plot_ui.hline(
                    HLine::new("", 0.0)
                        .color(BASELINE)
                        .width(1.0)
                        .allow_hover(false),
                );
            }
            if let Some(curves) = &matched {
                plot_ui.line(
                    Line::new(
                        "Experimental",
                        plot_points(&curves.frequency, &curves.ir_observed, 1.0, low, high),
                    )
                    .color(INK)
                    .width(1.9),
                );
                plot_ui.line(
                    Line::new(
                        calculated_label,
                        plot_points(&curves.frequency, &curves.ir_calculated, 1.0, low, high),
                    )
                    .color(VCD_ACCENT)
                    .width(1.8),
                );
            } else {
                if let Some(spectrum) = &experimental_ir {
                    plot_ui.line(
                        Line::new(
                            "Experimental",
                            plot_points(&spectrum.x, &spectrum.y, 1.0, low, high),
                        )
                        .color(INK)
                        .width(1.9),
                    );
                }
                if let Some(curves) = &raw_curves {
                    plot_ui.line(
                        Line::new(
                            "Calculated",
                            plot_points(&curves.frequency, &curves.ir, 1.0, low, high),
                        )
                        .color(VCD_ACCENT)
                        .width(1.8),
                    );
                }
            }
            if show_sticks && let Some(curves) = &raw_curves {
                let display_peak = matched
                    .as_ref()
                    .map_or_else(
                        || {
                            experimental_ir
                                .as_ref()
                                .map_or(0.0, |s| max_abs(&s.y))
                                .max(max_abs(&curves.ir))
                        },
                        |matched| {
                            max_abs(&matched.ir_observed).max(max_abs(&matched.ir_calculated))
                        },
                    )
                    .max(1.0);
                add_sticks(
                    plot_ui,
                    "ir-mode",
                    &curves.stick_x,
                    &curves.stick_ir,
                    display_peak,
                    true,
                    VCD_ACCENT,
                    low,
                    high,
                );
            }
        });
        paint_outward_axis_ticks(ui, &ir_plot.transform, 50.0, 50.0, 0.1, 0.0);
        paint_spectral_legend(
            ui,
            ui.id().with(("vibrational_ir_legend", index)),
            &ir_plot.transform,
            &ir_legend_series,
            &ir_legend_entries,
            (low, high),
            true,
        );
        let mut coordinates = hovered_plot_coordinates(&ir_plot, "IR", "cm⁻¹", None);

        let mut vcd_legend_series = Vec::new();
        let mut vcd_legend_entries = Vec::new();
        if let Some(curves) = &matched {
            vcd_legend_series.extend([
                LegendSeries {
                    x: &curves.frequency,
                    y: &curves.vcd_observed,
                    scale: 1.0,
                },
                LegendSeries {
                    x: &curves.frequency,
                    y: &curves.vcd_calculated,
                    scale: 1.0,
                },
            ]);
            vcd_legend_entries.extend([
                LegendLine::solid("Experimental", INK, 1.9),
                LegendLine::solid(calculated_label, VCD_ACCENT, 1.8),
            ]);
            if show_enantiomer {
                vcd_legend_series.push(LegendSeries {
                    x: &curves.frequency,
                    y: if fitted {
                        &curves.vcd_opposite
                    } else {
                        &curves.vcd_calculated
                    },
                    scale: if fitted { 1.0 } else { -1.0 },
                });
                vcd_legend_entries.push(LegendLine::dashed(
                    if fitted {
                        VIB_ENANTIOMER_FITTED_LABEL
                    } else {
                        "Enantiomer"
                    },
                    ENANT_BLUE,
                    1.5,
                ));
            }
        } else {
            if let Some(spectrum) = &experimental_vcd {
                vcd_legend_series.push(LegendSeries {
                    x: &spectrum.x,
                    y: &spectrum.y,
                    scale: 1.0,
                });
                vcd_legend_entries.push(LegendLine::solid("Experimental", INK, 1.9));
            }
            if let Some(curves) = &raw_curves {
                vcd_legend_series.push(LegendSeries {
                    x: &curves.frequency,
                    y: &curves.vcd,
                    scale: 1.0,
                });
                vcd_legend_entries.push(LegendLine::solid("Calculated", VCD_ACCENT, 1.8));
                if show_enantiomer {
                    vcd_legend_series.push(LegendSeries {
                        x: &curves.frequency,
                        y: &curves.vcd,
                        scale: -1.0,
                    });
                    vcd_legend_entries.push(LegendLine::dashed("Enantiomer", ENANT_BLUE, 1.5));
                }
            }
        }

        heading(ui, "Vibrational circular dichroism", VCD_ACCENT);
        let mut vcd_plot = Plot::new(format!("vibrational_vcd_{compound_id}"))
            .height(plot_height)
            .width(plot_width)
            .invert_x(true)
            .custom_x_axes(live_x_axes("Wavenumber (cm⁻¹)", false))
            .custom_y_axes(live_y_axes("ΔA (AU)", true))
            .x_grid_spacer(|input| spectral_grid_marks(input, 50.0, 50.0))
            .y_grid_spacer(|input| spectral_grid_marks(input, 0.0, 0.0))
            .default_x_bounds(low, high)
            .set_margin_fraction(Vec2::new(0.0, 0.05))
            .include_y(0.0)
            .show_grid(show_grid)
            .grid_color(GRID)
            .show_crosshair(false);
        if reset_view {
            vcd_plot = vcd_plot.reset();
        }
        let vcd_plot = vcd_plot.show(ui, |plot_ui| {
            if show_baseline {
                plot_ui.hline(
                    HLine::new("", 0.0)
                        .color(BASELINE)
                        .width(1.0)
                        .allow_hover(false),
                );
            }
            if let Some(curves) = &matched {
                plot_ui.line(
                    Line::new(
                        "Experimental",
                        plot_points(&curves.frequency, &curves.vcd_observed, 1.0, low, high),
                    )
                    .color(INK)
                    .width(1.9),
                );
                plot_ui.line(
                    Line::new(
                        calculated_label,
                        plot_points(&curves.frequency, &curves.vcd_calculated, 1.0, low, high),
                    )
                    .color(VCD_ACCENT)
                    .width(1.8),
                );
                if show_enantiomer {
                    let values = if fitted {
                        &curves.vcd_opposite
                    } else {
                        &curves.vcd_calculated
                    };
                    let scale = if fitted { 1.0 } else { -1.0 };
                    plot_ui.line(
                        Line::new(
                            if fitted {
                                VIB_ENANTIOMER_FITTED_LABEL
                            } else {
                                "Enantiomer"
                            },
                            plot_points(&curves.frequency, values, scale, low, high),
                        )
                        .color(ENANT_BLUE)
                        .width(1.5)
                        .style(LineStyle::dashed_dense()),
                    );
                }
            } else {
                if let Some(spectrum) = &experimental_vcd {
                    plot_ui.line(
                        Line::new(
                            "Experimental",
                            plot_points(&spectrum.x, &spectrum.y, 1.0, low, high),
                        )
                        .color(INK)
                        .width(1.9),
                    );
                }
                if let Some(curves) = &raw_curves {
                    plot_ui.line(
                        Line::new(
                            "Calculated",
                            plot_points(&curves.frequency, &curves.vcd, 1.0, low, high),
                        )
                        .color(VCD_ACCENT)
                        .width(1.8),
                    );
                    if show_enantiomer {
                        plot_ui.line(
                            Line::new(
                                "Enantiomer",
                                plot_points(&curves.frequency, &curves.vcd, -1.0, low, high),
                            )
                            .color(ENANT_BLUE)
                            .width(1.5)
                            .style(LineStyle::dashed_dense()),
                        );
                    }
                }
            }
            if show_sticks && let Some(curves) = &raw_curves {
                let display_peak = matched
                    .as_ref()
                    .map_or_else(
                        || {
                            experimental_vcd
                                .as_ref()
                                .map_or(0.0, |s| max_abs(&s.y))
                                .max(max_abs(&curves.vcd))
                        },
                        |matched| {
                            max_abs(&matched.vcd_observed).max(max_abs(&matched.vcd_calculated))
                        },
                    )
                    .max(1.0);
                add_sticks(
                    plot_ui,
                    "vcd-mode",
                    &curves.stick_x,
                    &curves.stick_vcd,
                    display_peak,
                    false,
                    VCD_ACCENT,
                    low,
                    high,
                );
            }
        });
        paint_outward_axis_ticks(ui, &vcd_plot.transform, 50.0, 50.0, 0.0, 0.0);
        paint_spectral_legend(
            ui,
            ui.id().with(("vibrational_vcd_legend", index)),
            &vcd_plot.transform,
            &vcd_legend_series,
            &vcd_legend_entries,
            (low, high),
            true,
        );
        if let Some(vcd_coordinates) = hovered_plot_coordinates(&vcd_plot, "VCD", "cm⁻¹", None) {
            coordinates = Some(vcd_coordinates);
        }
        coordinates
    }

    fn vibrational_controls(&mut self, ui: &mut Ui) {
        heading(ui, "Input data", VCD_ACCENT);
        let mut combined = false;
        let mut ir = false;
        let mut vcd = false;
        let mut logs = false;
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing = Vec2::new(10.0, 8.0);
            if ui.button("IR + VCD…").clicked() {
                combined = true;
            }
            if ui.button("IR…").clicked() {
                ir = true;
            }
            if ui.button("VCD…").clicked() {
                vcd = true;
            }
            if ui.button("Gaussian LOGs…").clicked() {
                logs = true;
            }
        });
        ui.label(RichText::new("Gaussian LOGs containing completed optimization and harmonic-frequency calculations; CSV, TXT, DAT, XY, or TSV measured spectra.").small().color(MUTED));
        ui.add_space(5.0);
        tab_bar(ui, &mut self.vibrational.tab);
        match self.vibrational.tab {
            ControlTab::Fit => self.vibrational_fit_controls(ui),
            ControlTab::Conformers => self.vibrational_conformer_controls(ui),
            ControlTab::View => self.vibrational_view_controls(ui),
        }
        if combined {
            self.load_vibrational_combined();
        }
        if ir {
            self.load_vibrational_channel(VibKind::Ir);
        }
        if vcd {
            self.load_vibrational_channel(VibKind::Vcd);
        }
        if logs
            && let Some(paths) = rfd::FileDialog::new()
                .set_title("Add Gaussian IR/VCD calculations")
                .add_filter("Gaussian output", &["log", "out"])
                .pick_files()
        {
            self.add_vibrational_logs(paths);
        }
    }

    fn vibrational_fit_controls(&mut self, ui: &mut Ui) {
        let index = self.vibrational.selected;
        let fitting = self.vibrational.fit_receiver.is_some();
        let mut start_fit = false;
        let mut reset = false;
        let mut fit_window = false;
        {
            let dataset = &mut self.vibrational.datasets[index];
            let mut invalidate = false;
            if control_row(ui, "Frequency scale factor", |ui| {
                aligned_f64_slider(ui, &mut dataset.scale, 0.90..=1.02, 0.001, 3)
            }) {
                dataset.invalidate_fit();
                invalidate = true;
            }
            if control_row(ui, "Lorentzian half-width γ (cm⁻¹)", |ui| {
                aligned_f64_slider(ui, &mut dataset.gamma, 1.0..=20.0, 0.1, 1)
            }) {
                dataset.invalidate_fit();
                invalidate = true;
            }
            ui.separator();
            ui.label("Match window (cm⁻¹)");
            control_row(ui, "From", |ui| {
                if ui
                    .add_sized(
                        [ui.available_width().min(90.0), 30.0],
                        DragValue::new(&mut dataset.range_low)
                            .speed(5)
                            .range(200..=4000),
                    )
                    .changed()
                {
                    dataset.invalidate_fit();
                    dataset.invalidate_evaluation();
                }
            });
            control_row(ui, "To", |ui| {
                let input_width = ui.available_width().min(78.0);
                if ui
                    .add_sized(
                        [input_width, 30.0],
                        DragValue::new(&mut dataset.range_high)
                            .speed(5)
                            .range(200..=4000),
                    )
                    .changed()
                {
                    dataset.invalidate_fit();
                    dataset.invalidate_evaluation();
                }
                if ui
                    .add_sized([54.0, 30.0], egui::Button::new("Data"))
                    .clicked()
                {
                    fit_window = true;
                }
            });
            control_row(ui, "Max band shift", |ui| {
                if ui
                    .add_sized(
                        [ui.available_width().min(110.0), 30.0],
                        DragValue::new(&mut dataset.max_shift)
                            .speed(1)
                            .range(0..=60)
                            .suffix(" cm⁻¹"),
                    )
                    .changed()
                {
                    dataset.invalidate_fit();
                    dataset.invalidate_evaluation();
                }
            });
            ui.label(RichText::new("Each band region may move independently toward lower frequency by this amount.").small().color(MUTED));
            ui.separator();
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing.x = 22.0;
                ui.checkbox(&mut dataset.show_enantiomer, "Enantiomer");
                ui.checkbox(&mut dataset.show_sticks, "Sticks");
            });
            if invalidate {
                dataset.invalidate();
            }
        }
        ui.add_space(8.0);
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 12.0;
            if ui
                .add_enabled(!fitting, egui::Button::new("Auto-Fit"))
                .clicked()
            {
                start_fit = true;
            }
            if ui.button("Reset").clicked() {
                reset = true;
            }
            if fitting {
                ui.add(egui::Spinner::new().size(24.0).color(VCD_ACCENT));
            }
        });
        ui.label(
            RichText::new(
                "Auto-Fit uses measured IR only, so it cannot be biased toward either enantiomer.",
            )
            .small()
            .color(MUTED),
        );
        if fit_window {
            self.vibrational.datasets[index].fit_window_to_data();
            self.vibrational.reset_plot_view = true;
            self.vibrational
                .activity
                .push("Match window fitted to the available measured range.".into());
        }
        if reset {
            self.vibrational.datasets[index].reset_fit();
            self.vibrational
                .activity
                .push("Reset to scale 0.98, γ 6 cm⁻¹, and the 1000–1600 cm⁻¹ window.".into());
        }
        if start_fit {
            self.start_vibrational_fit(ui.ctx().clone());
        }
        ui.add_space(14.0);
        ui.separator();
        self.vibrational_results(ui);
    }

    fn vibrational_conformer_controls(&mut self, ui: &mut Ui) {
        let mut add = false;
        let mut remove = false;
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing = Vec2::new(10.0, 8.0);
            if ui.button("Add Gaussian LOGs…").clicked() {
                add = true;
            }
            if ui.button("Remove selected").clicked() {
                remove = true;
            }
        });
        let index = self.vibrational.selected;
        let selected = &mut self.vibrational.selected_conformers;
        let dataset = &mut self.vibrational.datasets[index];
        let _ = dataset.curves();
        let energies: Vec<f64> = dataset
            .conformers
            .iter()
            .filter_map(|conformer| conformer.weighting_energy())
            .collect();
        let minimum = energies.iter().copied().reduce(f64::min);
        let mut changed = false;
        ScrollArea::vertical()
            .max_height(310.0)
            .id_salt("vibrational_conformers")
            .show(ui, |ui| {
                ui.set_width((ui.available_width() - 10.0).max(1.0));
                for (row, conformer) in dataset.conformers.iter_mut().enumerate() {
                    let selected_row = selected.contains(&row);
                    let energy_text = conformer.weighting_energy().zip(minimum).map_or_else(
                        || "ΔG —".to_string(),
                        |(energy, base)| format!("ΔG {:.2}", (energy - base) * HARTREE_TO_KCAL),
                    );
                    ui.horizontal(|ui| {
                        changed |= ui.checkbox(&mut conformer.include, "").changed();
                        let imag = if conformer.imaginary_modes > 0 {
                            format!(
                                "{} modes · {}i",
                                conformer.nmodes(),
                                conformer.imaginary_modes
                            )
                        } else {
                            format!("{} modes", conformer.nmodes())
                        };
                        let weight_text = format!("w {:.3}", conformer.weight);
                        if conformer_details(
                            ui,
                            selected_row,
                            &conformer.name,
                            &energy_text,
                            &weight_text,
                            &imag,
                        ) {
                            if selected_row {
                                selected.remove(&row);
                            } else {
                                selected.insert(row);
                            }
                        }
                    });
                }
            });
        if dataset.conformers.is_empty() {
            ui.label(
                RichText::new("No conformers loaded.")
                    .italics()
                    .color(MUTED),
            );
        }
        ui.separator();
        control_row(ui, "Temperature (K)", |ui| {
            changed |= ui
                .add_sized(
                    [ui.available_width().min(90.0), 30.0],
                    DragValue::new(&mut dataset.temperature)
                        .speed(1.0)
                        .range(1.0..=2000.0),
                )
                .changed();
        });
        if changed {
            dataset.invalidate_fit();
            dataset.invalidate();
        }
        if remove && !selected.is_empty() {
            let mut row = 0usize;
            dataset.conformers.retain(|_| {
                let keep = !selected.contains(&row);
                row += 1;
                keep
            });
            selected.clear();
            dataset.invalidate_fit();
            dataset.invalidate();
            self.vibrational
                .activity
                .push("Removed selected conformers.".into());
        }
        if add
            && let Some(paths) = rfd::FileDialog::new()
                .set_title("Add Gaussian IR/VCD calculations")
                .add_filter("Gaussian output", &["log", "out"])
                .pick_files()
        {
            self.add_vibrational_logs(paths);
        }
        ui.label(
            RichText::new(
                "Each Gaussian LOG must contain a completed ground-state optimization calculation, Gibbs free energy, and complete IR/VCD data from a harmonic frequency calculation. Boltzmann weighting uses the optimization Gibbs free energies; ΔG is reported in kcal/mol. Automatic duplicate detection requires |ΔG| ≤ 0.20 kcal/mol, symmetry-aware RMSD ≤ 0.10 Å, maximum atom displacement ≤ 0.15 Å, frequency RMSD ≤ 2.0 cm⁻¹, and maximum frequency difference ≤ 3.0 cm⁻¹.",
            )
            .text_style(egui::TextStyle::Body)
            .color(MUTED),
        );
    }

    fn vibrational_view_controls(&mut self, ui: &mut Ui) {
        let index = self.vibrational.selected;
        let mut fit_data = false;
        let mut match_window = false;
        let mut view_changed = false;
        let mut export_figure_requested = false;
        let mut export_data_requested = false;
        heading(ui, "Plot appearance", VCD_ACCENT);
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing.x = 22.0;
            ui.checkbox(&mut self.vibrational.show_baseline, "Zero baseline");
            ui.checkbox(&mut self.vibrational.show_grid, "Gridlines");
        });
        ui.checkbox(
            &mut self.vibrational.datasets[index].show_export_legend,
            "Legend in exported figures",
        );
        if ui.button("Re-center spectra").clicked() {
            self.vibrational.reset_plot_view = true;
        }
        ui.separator();
        {
            let dataset = &mut self.vibrational.datasets[index];
            heading(ui, "Display range", VCD_ACCENT);
            control_row(ui, "Minimum wavenumber", |ui| {
                view_changed |= ui
                    .add_sized(
                        [ui.available_width().min(115.0), 30.0],
                        DragValue::new(&mut dataset.view_low)
                            .speed(5)
                            .range(200..=4000)
                            .suffix(" cm⁻¹"),
                    )
                    .changed();
            });
            control_row(ui, "Maximum wavenumber", |ui| {
                view_changed |= ui
                    .add_sized(
                        [ui.available_width().min(115.0), 30.0],
                        DragValue::new(&mut dataset.view_high)
                            .speed(5)
                            .range(200..=4000)
                            .suffix(" cm⁻¹"),
                    )
                    .changed();
            });
            ui.horizontal(|ui| {
                ui.spacing_mut().item_spacing.x = 12.0;
                if ui.button(FIT_RANGE_TO_DATA_LABEL).clicked() {
                    fit_data = true;
                }
                if ui.button("Match window").clicked() {
                    match_window = true;
                }
            });
            ui.label(RichText::new("Display scaling is independent from the analysis window, so out-of-range bands do not flatten the region of interest.").small().color(MUTED));
            ui.separator();
            control_row(ui, "Curve points", |ui| {
                if ui
                    .add_sized(
                        [ui.available_width().min(90.0), 30.0],
                        DragValue::new(&mut dataset.npoints)
                            .speed(50)
                            .range(200..=12_000),
                    )
                    .changed()
                {
                    dataset.invalidate();
                }
            });
            control_row(ui, "Raster export DPI", |ui| {
                ui.add_sized(
                    [ui.available_width().min(80.0), 30.0],
                    DragValue::new(&mut dataset.dpi).speed(25).range(72..=2400),
                );
            });
            ui.add_space(10.0);
            if ui.button("Export figure  (PNG / PDF / SVG)…").clicked() {
                export_figure_requested = true;
            }
            if ui.button("Export matched data  (CSV / TXT)…").clicked() {
                export_data_requested = true;
            }
        }
        if fit_data {
            self.vibrational.datasets[index].view_to_data();
            view_changed = true;
            self.vibrational
                .activity
                .push("Display range fitted to measured data.".into());
        }
        if match_window {
            let dataset = &mut self.vibrational.datasets[index];
            dataset.view_low = dataset.range_low;
            dataset.view_high = dataset.range_high;
            view_changed = true;
            self.vibrational
                .activity
                .push("Display range set to the match window.".into());
        }
        if view_changed {
            self.vibrational.reset_plot_view = true;
        }
        if export_figure_requested {
            self.export_vibrational_figure();
        }
        if export_data_requested {
            self.export_vibrational_data();
        }
    }

    fn vibrational_results(&mut self, ui: &mut Ui) {
        let index = self.vibrational.selected;
        let evaluation = self.vibrational.datasets[index].evaluate();
        heading(ui, "Assignment", VCD_ACCENT);
        if evaluation.assignment.is_empty() {
            ui.add(
                egui::Label::new(
                    RichText::new("Load calculated modes plus measured IR and VCD to evaluate.")
                        .color(MUTED),
                )
                .wrap(),
            );
        } else {
            let tone = result_tone(&evaluation.assignment, &evaluation.reliability, VCD_ACCENT);
            ui.add(
                egui::Label::new(
                    RichText::new(&evaluation.assignment)
                        .size(17.0)
                        .strong()
                        .color(tone),
                )
                .wrap(),
            );
            ui.add(
                egui::Label::new(
                    RichText::new(&evaluation.reliability)
                        .size(13.5)
                        .strong()
                        .color(tone),
                )
                .wrap(),
            );
        }
        ui.separator();
        ui.label(
            RichText::new(
                "Metric values: green = strong or favoured; amber = limited; red = weak or unfavoured.",
            )
            .small()
            .color(MUTED),
        );
        if let Some(result) = &evaluation.result {
            let (calculated_tone, enantiomer_tone) =
                comparison_tones(Some(result.sim_vcd), Some(result.sim_vcd_opposite), 0.05);
            metric(
                ui,
                "IR similarity",
                Some(result.sim_ir),
                false,
                higher_score_tone(Some(result.sim_ir), 0.50, 0.30),
            );
            metric(
                ui,
                "IR before region shifts",
                Some(result.sim_ir_original),
                false,
                higher_score_tone(Some(result.sim_ir_original), 0.50, 0.30),
            );
            metric(
                ui,
                "VCD similarity",
                Some(result.sim_vcd),
                true,
                calculated_tone,
            );
            metric(
                ui,
                "VCD enantiomer",
                Some(result.sim_vcd_opposite),
                true,
                enantiomer_tone,
            );
            metric(
                ui,
                "ESI",
                Some(result.esi),
                true,
                magnitude_tone(Some(result.esi), 0.30, 0.05),
            );
            ui.separator();
            ui.label(
                RichText::new(format!(
                    "Window: {}–{} cm⁻¹",
                    result.range_low, result.range_high
                ))
                .color(INK),
            );
        } else {
            metric(ui, "IR similarity", None, false, MUTED);
            metric(ui, "VCD similarity", None, true, MUTED);
            metric(ui, "VCD enantiomer", None, true, MUTED);
            metric(ui, "ESI", None, true, MUTED);
        }
    }
}

impl CdarApp {
    fn load_vibrational_combined(&mut self) {
        let Some(path) = rfd::FileDialog::new()
            .set_title("Load measured IR and/or VCD")
            .add_filter("Spectral data", &["csv", "txt", "dat", "xy", "tsv"])
            .add_filter("Gaussian output", &["log", "out"])
            .pick_file()
        else {
            return;
        };
        if looks_like_gaussian_log(&path) {
            self.add_vibrational_logs(vec![path]);
            return;
        }
        let (x, columns) = match parse_vib_experimental_multi(&path) {
            Ok(value) => value,
            Err(error) => {
                self.vibrational_error(format!("Could not read {}:\n{error}", path.display()));
                return;
            }
        };
        let index = self.vibrational.selected;
        let dataset = &mut self.vibrational.datasets[index];
        let window = Some((dataset.range_low as f64, dataset.range_high as f64));
        let (ir, vcd) = guess_vib_roles(&x, &columns, window);
        let mut loaded = Vec::new();
        if let Some(column_index) = ir {
            let Some(column) = columns.get(column_index) else {
                return;
            };
            dataset.experimental_ir = Some(Spectrum::new(x.clone(), column.clone()).sorted());
            loaded.push(format!("IR (column {})", column_index + 2));
        }
        if let Some(column_index) = vcd {
            let Some(column) = columns.get(column_index) else {
                return;
            };
            dataset.experimental_vcd = Some(Spectrum::new(x.clone(), column.clone()).sorted());
            loaded.push(format!("VCD (column {})", column_index + 2));
        }
        if loaded.is_empty() {
            self.vibrational_error("No usable IR or VCD intensity column was found.".into());
            return;
        }
        dataset.invalidate_fit();
        dataset.invalidate();
        self.vibrational.reset_plot_view = true;
        self.vibrational.activity.push(format!(
            "Loaded {} from {} — assigned from sign content, not column order.",
            loaded.join(" and "),
            file_label(&path),
        ));
    }

    fn load_vibrational_channel(&mut self, kind: VibKind) {
        let title = match kind {
            VibKind::Ir => "Load measured IR",
            VibKind::Vcd => "Load measured VCD",
        };
        let Some(path) = rfd::FileDialog::new()
            .set_title(title)
            .add_filter("Spectral data", &["csv", "txt", "dat", "xy", "tsv"])
            .pick_file()
        else {
            return;
        };
        if looks_like_gaussian_log(&path) {
            self.add_vibrational_logs(vec![path]);
            return;
        }
        let spectrum = match parse_vib_experimental(&path) {
            Ok(spectrum) => spectrum,
            Err(error) => {
                self.vibrational_error(format!("Could not read {}:\n{error}", path.display()));
                return;
            }
        };
        let index = self.vibrational.selected;
        let dataset = &mut self.vibrational.datasets[index];
        let detected = guess_vib_role(
            &spectrum.x,
            &spectrum.y,
            Some((dataset.range_low as f64, dataset.range_high as f64)),
        );
        let note = if detected != kind {
            match detected {
                VibKind::Ir => " Note: its sign content looks more like IR data.",
                VibKind::Vcd => " Note: its sign content looks strongly bipolar, like VCD data.",
            }
        } else {
            ""
        };
        let count = spectrum.len();
        let range = min_max(&spectrum.x).unwrap_or((0.0, 0.0));
        match kind {
            VibKind::Ir => dataset.experimental_ir = Some(spectrum),
            VibKind::Vcd => dataset.experimental_vcd = Some(spectrum),
        }
        dataset.invalidate_fit();
        dataset.invalidate();
        self.vibrational.reset_plot_view = true;
        self.vibrational.activity.push(format!(
            "Loaded {}: {count} points, {:.0}–{:.0} cm⁻¹ from {}.{note}",
            kind.label(),
            range.0,
            range.1,
            file_label(&path),
        ));
    }

    fn add_vibrational_logs(&mut self, paths: Vec<PathBuf>) {
        let dataset = &mut self.vibrational.datasets[self.vibrational.selected];
        let report = import_conformers(
            &mut dataset.conformers,
            paths,
            |path| parse_gaussian_vib(path),
            |c| &c.path,
            |conformers| {
                let result = dedupe_vib(conformers);
                *conformers = result.conformers;
                result.report
            },
        );
        if report.changed() {
            self.vibrational.selected_conformers.clear();
            self.vibrational.reset_plot_view = true;
            dataset.invalidate_fit();
            dataset.invalidate();
        }
        self.vibrational.activity.push(report.text());
    }

    fn ingest_vibrational_paths(&mut self, paths: Vec<PathBuf>) {
        let mut logs = Vec::new();
        let mut spectra = Vec::new();
        for path in paths {
            if looks_like_gaussian_log(&path) {
                logs.push(path);
            } else {
                spectra.push(path);
            }
        }
        let mut notes = Vec::new();
        let had_calculations = !logs.is_empty();
        if had_calculations {
            self.add_vibrational_logs(logs);
        }
        let mut failures = Vec::new();
        let mut spectra_loaded = 0usize;
        for path in spectra {
            match parse_vib_experimental_multi(&path) {
                Ok((x, columns)) => {
                    let index = self.vibrational.selected;
                    let dataset = &mut self.vibrational.datasets[index];
                    let roles = guess_vib_roles(
                        &x,
                        &columns,
                        Some((dataset.range_low as f64, dataset.range_high as f64)),
                    );
                    if let Some(column) = roles.0.and_then(|column| columns.get(column)) {
                        dataset.experimental_ir =
                            Some(Spectrum::new(x.clone(), column.clone()).sorted());
                    }
                    if let Some(column) = roles.1.and_then(|column| columns.get(column)) {
                        dataset.experimental_vcd =
                            Some(Spectrum::new(x.clone(), column.clone()).sorted());
                    }
                    dataset.invalidate_fit();
                    dataset.invalidate();
                    self.vibrational.reset_plot_view = true;
                    spectra_loaded += 1;
                    self.vibrational.activity.push(format!(
                        "Loaded measured spectrum from {} into {}.",
                        file_label(&path),
                        dataset.name
                    ));
                }
                Err(error) => failures.push(format!("{}: {error}", file_label(&path))),
            }
        }
        if spectra_loaded > 0 {
            notes.push(format!(
                "Loaded {spectra_loaded} measured spectrum file(s) by drag-and-drop."
            ));
        }
        if !failures.is_empty() {
            notes.push(format!(
                "{} file(s) failed: {}",
                failures.len(),
                failures.join("\n")
            ));
        }
        if !notes.is_empty() {
            self.vibrational.activity.push(notes.join("\n\n"));
        } else if !had_calculations {
            self.vibrational
                .activity
                .push(NO_USABLE_IMPORT_MESSAGE.into());
        }
    }

    fn start_vibrational_fit(&mut self, context: Context) {
        if self.vibrational.fit_receiver.is_some() {
            return;
        }
        let index = self.vibrational.selected;
        let dataset = &self.vibrational.datasets[index];
        if !dataset.has_calculation() {
            self.vibrational_error(
                "Load at least one DFT frequency file with a Gibbs free energy first.".into(),
            );
            return;
        }
        let Some(ir) = dataset.experimental_ir.clone() else {
            self.vibrational_error("Auto-Fit needs a measured IR spectrum.".into());
            return;
        };
        let input = VibAutoFitInput {
            ir,
            conformers: dataset.conformers.clone(),
            temperature: dataset.temperature,
            range: (dataset.range_low, dataset.range_high),
            max_shift: dataset.max_shift,
        };
        let (sender, receiver) = mpsc::channel();
        let stamp = dataset.state.stamp();
        self.vibrational.fit_receiver = Some(receiver);
        self.vibrational
            .activity
            .push("Optimizing scale factor and bandwidth against measured IR…".into());
        std::thread::spawn(move || {
            let result = run_vib_auto_fit(input).map_err(|error| error.to_string());
            let _ = sender.send((stamp, result));
            context.request_repaint();
        });
    }

    fn finish_vibrational_fit(&mut self, stamp: FitStamp, output: VibFitResult) {
        let Some(dataset) = self
            .vibrational
            .datasets
            .iter_mut()
            .find(|d| d.state.stamp() == stamp)
        else {
            self.vibrational.activity.push("Discarded an outdated fit because the compound or fit inputs changed. Run Auto-Fit again to fit the current inputs.".into());
            return;
        };
        dataset.scale = output.scale;
        dataset.gamma = output.gamma;
        dataset.fitted = true;
        dataset.invalidate();
        self.vibrational.activity.push(format!(
            "Fit complete: scale={:.3}, γ={:.1} cm⁻¹, IR similarity={:.3}",
            output.scale, output.gamma, output.ir_similarity,
        ));
    }

    fn export_vibrational_figure(&mut self) {
        let index = self.vibrational.selected;
        let dataset = &mut self.vibrational.datasets[index];
        if !dataset.has_calculation()
            && !dataset.has_experimental_ir()
            && !dataset.has_experimental_vcd()
        {
            self.vibrational_error("Nothing is available to export yet.".into());
            return;
        }
        let filename = format!("{}_VCD.png", sanitize_filename(&dataset.name));
        let Some(path) = rfd::FileDialog::new()
            .set_title("Export figure")
            .set_file_name(filename)
            .add_filter("Figure", &["png", "pdf", "svg"])
            .save_file()
        else {
            return;
        };
        let spec = vibrational_figure(dataset);
        match write_figure(&spec, &path, dataset.dpi) {
            Ok(()) => self
                .vibrational
                .activity
                .push(format!("Figure exported: {}", path.display())),
            Err(error) => self.vibrational_error(format!("Figure export failed:\n{error}")),
        }
    }

    fn export_vibrational_data(&mut self) {
        let index = self.vibrational.selected;
        let dataset = &mut self.vibrational.datasets[index];
        let filename = format!("{}_matched.csv", sanitize_filename(&dataset.name));
        let Some(path) = rfd::FileDialog::new()
            .set_title("Export matched spectra")
            .set_file_name(filename)
            .add_filter("Spectral table", &["csv", "txt"])
            .save_file()
        else {
            return;
        };
        match write_vibrational_data(dataset, &path) {
            Ok(()) => self
                .vibrational
                .activity
                .push(format!("Matched data exported: {}", path.display())),
            Err(error) => self.vibrational_error(format!("Data export failed:\n{error}")),
        }
    }
}
