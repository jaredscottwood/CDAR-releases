//! Stable compound identity and fit revisions, independent of UI list indices.
use std::sync::atomic::{AtomicU64, Ordering};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct FitStamp {
    id: u64,
    revision: u64,
}

#[derive(Clone, Debug)]
pub(crate) struct DatasetState(FitStamp);

impl Default for DatasetState {
    fn default() -> Self {
        static NEXT_ID: AtomicU64 = AtomicU64::new(1);
        Self(FitStamp {
            id: NEXT_ID.fetch_add(1, Ordering::Relaxed),
            revision: 0,
        })
    }
}

impl DatasetState {
    pub fn id(&self) -> u64 {
        self.0.id
    }
    pub fn stamp(&self) -> FitStamp {
        self.0
    }
    pub fn changed(&mut self) {
        self.0.revision += 1;
    }
}
