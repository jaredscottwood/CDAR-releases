#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::sync::Arc;

use cdar::{APP_TITLE, app::CdarApp, assets::primary_window_icon};
use eframe::egui;

fn main() -> eframe::Result {
    let _ = env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("warn"))
        .try_init();
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("CDAR splash")
            .with_inner_size([280.0, 280.0])
            .with_min_inner_size([280.0, 280.0])
            .with_max_inner_size([280.0, 280.0])
            .with_resizable(false)
            .with_decorations(false)
            .with_taskbar(false)
            .with_window_level(egui::WindowLevel::AlwaysOnTop)
            .with_icon(Arc::new(primary_window_icon())),
        centered: true,
        persist_window: false,
        ..Default::default()
    };
    eframe::run_native(
        APP_TITLE,
        options,
        Box::new(|creation| Ok(Box::new(CdarApp::new(creation)))),
    )
}
