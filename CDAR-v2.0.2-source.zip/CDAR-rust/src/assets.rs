//! Embedded application artwork, window icons, and font fallbacks.

use std::sync::Arc;

use eframe::egui::{
    ColorImage, Context, FontData, FontDefinitions, FontFamily, IconData, TextureFilter,
    TextureHandle, TextureOptions,
};

const CDAR_PNG: &[u8] = include_bytes!("../assets/cdar.png");
const ECD_PNG: &[u8] = include_bytes!("../assets/ecd.png");
const LOGO_PNG: &[u8] = include_bytes!("../assets/logo.png");
const VCD_PNG: &[u8] = include_bytes!("../assets/vcd.png");
const DEJAVU_SANS: &[u8] = include_bytes!("../assets/fonts/DejaVuSans.ttf");

#[derive(Debug)]
struct DecodedPng {
    size: [usize; 2],
    rgba: Vec<u8>,
}

impl DecodedPng {
    fn color_image(&self) -> ColorImage {
        ColorImage::from_rgba_unmultiplied(self.size, &self.rgba)
    }

    fn padded_icon_data(&self) -> IconData {
        let padding = ((self.size[0].max(self.size[1]) as f32) * 0.08).round() as usize;
        let width = self.size[0] + padding * 2;
        let height = self.size[1] + padding * 2;
        let mut rgba = vec![0; width * height * 4];
        let row_bytes = self.size[0] * 4;
        for row in 0..self.size[1] {
            let source_start = row * row_bytes;
            let destination_start = ((row + padding) * width + padding) * 4;
            rgba[destination_start..destination_start + row_bytes]
                .copy_from_slice(&self.rgba[source_start..source_start + row_bytes]);
        }
        IconData {
            rgba,
            width: width as u32,
            height: height as u32,
        }
    }
}

fn decode_png(bytes: &[u8], name: &str) -> DecodedPng {
    let rgba = image::load_from_memory(bytes)
        .unwrap_or_else(|error| panic!("embedded {name} could not be decoded: {error}"))
        .into_rgba8();
    let size = [rgba.width() as usize, rgba.height() as usize];
    DecodedPng {
        size,
        rgba: rgba.into_raw(),
    }
}

fn load_texture(context: &Context, name: &str, image: &DecodedPng) -> TextureHandle {
    context.load_texture(
        name,
        image.color_image(),
        TextureOptions::LINEAR.with_mipmap_mode(Some(TextureFilter::Linear)),
    )
}

fn install_unicode_fallback(context: &Context) {
    let mut fonts = FontDefinitions::default();
    let name = "cdar-dejavu-fallback".to_owned();
    fonts
        .font_data
        .insert(name.clone(), Arc::new(FontData::from_static(DEJAVU_SANS)));
    for family in [FontFamily::Proportional, FontFamily::Monospace] {
        fonts
            .families
            .get_mut(&family)
            .expect("default egui font family is missing")
            .push(name.clone());
    }
    context.set_fonts(fonts);
}

/// Textures and high-resolution native icons decoded once when the app starts.
pub struct AppAssets {
    pub cdar: TextureHandle,
    pub ecd: TextureHandle,
    pub logo: TextureHandle,
    pub vcd: TextureHandle,
    primary_icon: Arc<IconData>,
    electronic_icon: Arc<IconData>,
    vibrational_icon: Arc<IconData>,
}

impl AppAssets {
    pub fn load(context: &Context) -> Self {
        install_unicode_fallback(context);
        let cdar = decode_png(CDAR_PNG, "cdar.png");
        let ecd = decode_png(ECD_PNG, "ecd.png");
        let logo = decode_png(LOGO_PNG, "logo.png");
        let vcd = decode_png(VCD_PNG, "vcd.png");
        Self {
            cdar: load_texture(context, "cdar-primary", &cdar),
            ecd: load_texture(context, "cdar-electronic", &ecd),
            logo: load_texture(context, "cdar-splash", &logo),
            vcd: load_texture(context, "cdar-vibrational", &vcd),
            primary_icon: Arc::new(cdar.padded_icon_data()),
            electronic_icon: Arc::new(ecd.padded_icon_data()),
            vibrational_icon: Arc::new(vcd.padded_icon_data()),
        }
    }

    pub fn primary_icon(&self) -> Arc<IconData> {
        Arc::clone(&self.primary_icon)
    }

    pub fn electronic_icon(&self) -> Arc<IconData> {
        Arc::clone(&self.electronic_icon)
    }

    pub fn vibrational_icon(&self) -> Arc<IconData> {
        Arc::clone(&self.vibrational_icon)
    }
}

/// Initial native window icon used before the first UI frame is created.
pub fn primary_window_icon() -> IconData {
    decode_png(CDAR_PNG, "cdar.png").padded_icon_data()
}

/// Set both Windows' small title-bar icon and large taskbar icon for a named window.
#[cfg(target_os = "windows")]
#[expect(unsafe_code)]
pub fn set_windows_window_icon(
    title: &str,
    icon_data: &IconData,
) -> Result<WindowsWindowIcons, String> {
    use std::iter;

    use windows_sys::Win32::UI::WindowsAndMessaging::{
        CreateIconFromResourceEx, FindWindowW, GetSystemMetrics, HICON, ICON_BIG, ICON_SMALL,
        LR_DEFAULTCOLOR, SM_CXICON, SM_CXSMICON, SendMessageW, WM_SETICON,
    };

    let title: Vec<u16> = title.encode_utf16().chain(iter::once(0)).collect();
    // SAFETY: `title` is a valid null-terminated UTF-16 string and the class name is null.
    let window = unsafe { FindWindowW(std::ptr::null(), title.as_ptr()) };
    if window.is_null() {
        return Err("the workspace window is not available yet".into());
    }

    let image =
        image::RgbaImage::from_raw(icon_data.width, icon_data.height, icon_data.rgba.clone())
            .ok_or_else(|| "the embedded icon dimensions are invalid".to_string())?;

    fn create_icon(image: &image::RgbaImage, size: i32) -> HICON {
        let scaled = image::imageops::resize(
            image,
            size.max(1) as u32,
            size.max(1) as u32,
            image::imageops::Lanczos3,
        );
        let mut png = Vec::new();
        if scaled
            .write_to(&mut std::io::Cursor::new(&mut png), image::ImageFormat::Png)
            .is_err()
        {
            return std::ptr::null_mut();
        }
        // SAFETY: Windows reads the complete in-memory PNG during this call.
        unsafe {
            CreateIconFromResourceEx(
                png.as_mut_ptr(),
                png.len() as u32,
                1,
                0x0003_0000,
                size,
                size,
                LR_DEFAULTCOLOR,
            )
        }
    }

    // SAFETY: system-metric getters have no side effects.
    let large = create_icon(&image, unsafe { GetSystemMetrics(SM_CXICON) });
    // SAFETY: system-metric getters have no side effects.
    let small = create_icon(&image, unsafe { GetSystemMetrics(SM_CXSMICON) });
    let icons = WindowsWindowIcons {
        window,
        large,
        small,
    };
    if large.is_null() || small.is_null() {
        return Err("Windows could not create the requested icon sizes".into());
    }

    // SAFETY: both handles were created successfully and `window` names the live workspace.
    unsafe {
        SendMessageW(window, WM_SETICON, ICON_BIG as usize, large as isize);
        SendMessageW(window, WM_SETICON, ICON_SMALL as usize, small as isize);
    }
    Ok(icons)
}

/// Own only the non-shared handles CDAR creates, never handles returned by
/// egui/winit. Replacing this guard releases the previous pair after use.
#[cfg(target_os = "windows")]
pub struct WindowsWindowIcons {
    window: windows_sys::Win32::Foundation::HWND,
    large: windows_sys::Win32::UI::WindowsAndMessaging::HICON,
    small: windows_sys::Win32::UI::WindowsAndMessaging::HICON,
}

#[cfg(target_os = "windows")]
impl Drop for WindowsWindowIcons {
    fn drop(&mut self) {
        use windows_sys::Win32::UI::WindowsAndMessaging::{
            DestroyIcon, ICON_BIG, ICON_SMALL, SendMessageW, WM_GETICON, WM_SETICON,
        };
        for (kind, icon) in [(ICON_BIG, self.large), (ICON_SMALL, self.small)] {
            if icon.is_null() {
                continue;
            }
            // SAFETY: these handles are uniquely owned, created without
            // LR_SHARED on the UI thread. Detach an icon if it is still in use
            // by the window, then destroy it. A closed HWND is harmless here.
            unsafe {
                if SendMessageW(self.window, WM_GETICON, kind as usize, 0) == icon as isize {
                    SendMessageW(self.window, WM_SETICON, kind as usize, 0);
                }
                DestroyIcon(icon);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn embedded_icons_decode_at_high_resolution() {
        for (bytes, name) in [
            (CDAR_PNG, "cdar.png"),
            (ECD_PNG, "ecd.png"),
            (LOGO_PNG, "logo.png"),
            (VCD_PNG, "vcd.png"),
        ] {
            let image = decode_png(bytes, name);
            assert!(image.size[0] >= 720);
            assert!(image.size[1] >= 720);
            assert_eq!(image.rgba.len(), image.size[0] * image.size[1] * 4);
            let icon = image.padded_icon_data();
            assert!(icon.width > image.size[0] as u32);
            assert!(icon.height > image.size[1] as u32);
            assert_eq!(
                icon.rgba.len(),
                icon.width as usize * icon.height as usize * 4
            );
        }

        let splash = decode_png(LOGO_PNG, "logo.png");
        assert_eq!(splash.size[0], splash.size[1]);
        assert_eq!(splash.rgba[3], 255, "the square splash must be opaque");
        let center = ((splash.size[1] / 2) * splash.size[0] + splash.size[0] / 2) * 4;
        assert_eq!(splash.rgba[center + 3], 255);
    }
}
