//! Small numerical helpers used by both spectroscopy engines.
//!
//! CDAR only needs one-dimensional vectors and tiny least-squares systems, so
//! keeping these operations local avoids pulling a full linear-algebra stack
//! into the desktop binary.

use std::cmp::Ordering;

pub const R_GAS: f64 = 1.987_203_6e-3;
pub const T_DEFAULT: f64 = 298.15;
pub const HARTREE_TO_KCAL: f64 = 627.509_474;
pub const EV_PER_CM1: f64 = 1.0 / 8065.544;
pub const NM_EV: f64 = 1_239.841_984;

#[inline]
pub fn ev_to_nm(ev: f64) -> f64 {
    if ev == 0.0 { f64::INFINITY } else { NM_EV / ev }
}

#[inline]
pub fn nm_to_ev(nm: f64) -> f64 {
    if nm == 0.0 { f64::INFINITY } else { NM_EV / nm }
}

pub fn linspace(start: f64, end: f64, count: usize) -> Vec<f64> {
    match count {
        0 => Vec::new(),
        1 => vec![start],
        n => {
            let step = (end - start) / (n - 1) as f64;
            (0..n).map(|i| start + i as f64 * step).collect()
        }
    }
}

/// Floating-point equivalent of NumPy's `arange`, including `start` and
/// excluding `stop` (apart from ordinary floating-point roundoff).
pub fn arange(start: f64, stop: f64, step: f64) -> Vec<f64> {
    if step == 0.0 || !start.is_finite() || !stop.is_finite() || !step.is_finite() {
        return Vec::new();
    }
    let mut out = Vec::new();
    let mut value = start;
    if step > 0.0 {
        while value < stop {
            out.push(value);
            value = start + out.len() as f64 * step;
        }
    } else {
        while value > stop {
            out.push(value);
            value = start + out.len() as f64 * step;
        }
    }
    out
}

pub fn min_max(values: &[f64]) -> Option<(f64, f64)> {
    let mut iter = values.iter().copied().filter(|v| v.is_finite());
    let first = iter.next()?;
    let mut lo = first;
    let mut hi = first;
    for value in iter {
        lo = lo.min(value);
        hi = hi.max(value);
    }
    Some((lo, hi))
}

pub fn max_abs(values: &[f64]) -> f64 {
    values.iter().fold(0.0_f64, |m, v| m.max(v.abs()))
}

#[derive(Clone, Debug, PartialEq)]
pub struct AxisTicks {
    pub low: f64,
    pub high: f64,
    pub step: f64,
    pub values: Vec<f64>,
}

fn nice_numeric_step(span: f64, target_intervals: usize, minimum_step: f64) -> f64 {
    let target = target_intervals.max(1) as f64;
    let raw = (span.abs() / target).max(minimum_step.max(f64::MIN_POSITIVE));
    if !raw.is_finite() {
        return minimum_step.max(1.0);
    }
    let magnitude = 10.0_f64.powf(raw.log10().floor());
    let normalized = raw / magnitude;
    let multiplier = [1.0, 2.0, 2.5, 5.0, 10.0]
        .into_iter()
        .find(|candidate| normalized <= *candidate + 1e-12)
        .unwrap_or(10.0);
    (multiplier * magnitude).max(minimum_step)
}

fn close_to_integer(value: f64) -> bool {
    (value - value.round()).abs() <= 1e-8 * value.abs().max(1.0)
}

fn rounded_interval_step(
    low: f64,
    high: f64,
    target_intervals: usize,
    minimum_step: f64,
    quantum: f64,
) -> f64 {
    let span = (high - low).abs();
    if quantum <= 0.0 || !quantum.is_finite() {
        return nice_numeric_step(span, target_intervals, minimum_step);
    }

    let target = target_intervals.max(1);
    let first = target.saturating_sub(2).max(3);
    let last = target.saturating_add(2).max(first);
    if close_to_integer(low / quantum) && close_to_integer(high / quantum) {
        let mut candidates: Vec<(usize, f64)> = (first..=last)
            .filter_map(|intervals| {
                let step = span / intervals as f64;
                (step >= minimum_step && close_to_integer(step / quantum))
                    .then_some((intervals.abs_diff(target), step))
            })
            .collect();
        candidates.sort_by(|left, right| {
            left.0
                .cmp(&right.0)
                .then_with(|| left.1.total_cmp(&right.1))
        });
        if let Some((_, step)) = candidates.first() {
            return *step;
        }
    }

    let raw = span / target as f64;
    ((raw / quantum).ceil().max(1.0) * quantum).max(minimum_step)
}

fn tick_values(low: f64, high: f64, step: f64) -> Vec<f64> {
    if !low.is_finite() || !high.is_finite() || !step.is_finite() || step <= 0.0 {
        return Vec::new();
    }
    let epsilon = step * 1e-9;
    let first = ((low - epsilon) / step).ceil() as i64;
    let last = ((high + epsilon) / step).floor() as i64;
    if last < first || last - first > 1_000 {
        return Vec::new();
    }
    (first..=last)
        .map(|index| {
            let value = index as f64 * step;
            if value.abs() <= epsilon { 0.0 } else { value }
        })
        .collect()
}

/// Generate conventional ticks for a fixed spectroscopy domain. `quantum`
/// constrains the interval to familiar units (10 nm or 50 cm⁻¹, for example),
/// while retaining exact rounded endpoints when they divide evenly.
pub fn rounded_axis_ticks(
    low: f64,
    high: f64,
    target_intervals: usize,
    minimum_step: f64,
    quantum: f64,
) -> AxisTicks {
    let (mut low, mut high) = if low <= high {
        (low, high)
    } else {
        (high, low)
    };
    if !low.is_finite() || !high.is_finite() {
        low = 0.0;
        high = quantum.max(minimum_step).max(1.0);
    }
    if high <= low {
        let padding = quantum.max(minimum_step).max(1.0);
        low -= padding;
        high += padding;
    }
    let step = rounded_interval_step(low, high, target_intervals, minimum_step, quantum);
    let exact_intervals = (high - low) / step;
    let rounded_low = if quantum > 0.0 {
        close_to_integer(low / quantum)
    } else {
        close_to_integer(low / step)
    };
    let values = if close_to_integer(exact_intervals) && rounded_low {
        let count = exact_intervals.round().max(1.0) as usize;
        (0..=count).map(|index| low + index as f64 * step).collect()
    } else {
        tick_values(low, high, step)
    };
    AxisTicks {
        low,
        high,
        step,
        values,
    }
}

/// Expand a data range to rounded numerical limits and return every major tick.
pub fn nice_axis_range(
    low: f64,
    high: f64,
    target_intervals: usize,
    minimum_step: f64,
    symmetric: bool,
    include_zero: bool,
) -> AxisTicks {
    let (mut low, mut high) = if low <= high {
        (low, high)
    } else {
        (high, low)
    };
    if !low.is_finite() || !high.is_finite() {
        low = -1.0;
        high = 1.0;
    }
    if include_zero {
        low = low.min(0.0);
        high = high.max(0.0);
    }
    if high <= low {
        let padding = low.abs().max(minimum_step).max(1.0) * 0.1;
        low -= padding;
        high += padding;
    }
    let step = nice_numeric_step(high - low, target_intervals, minimum_step);
    let (low, high) = if symmetric {
        let limit = (low.abs().max(high.abs()) / step).ceil().max(1.0) * step;
        (-limit, limit)
    } else {
        ((low / step).floor() * step, (high / step).ceil() * step)
    };
    AxisTicks {
        low,
        high,
        step,
        values: tick_values(low, high, step),
    }
}

/// Format a major tick using the precision implied by its interval. Very small
/// VCD intervals can opt into compact scientific notation.
pub fn format_axis_tick(value: f64, step: f64, scientific_small: bool) -> String {
    if value.abs() <= step.abs() * 1e-10 {
        return "0".into();
    }
    let absolute_step = step.abs();
    if (scientific_small && absolute_step < 1e-3) || value.abs() >= 1.0e6 {
        let mut text = format!("{value:.1e}");
        if let Some((mantissa, exponent)) = text.split_once('e') {
            let mantissa = mantissa.trim_end_matches('0').trim_end_matches('.');
            let exponent = exponent.parse::<i32>().unwrap_or_default();
            text = format!("{mantissa}e{exponent}");
        }
        return text;
    }
    let decimals = (0_usize..=8)
        .find(|digits| {
            let factor = 10.0_f64.powi(*digits as i32);
            close_to_integer(absolute_step * factor)
        })
        .unwrap_or(8);
    format!("{value:.decimals$}")
}

pub fn mean(values: &[f64]) -> f64 {
    if values.is_empty() {
        0.0
    } else {
        values.iter().sum::<f64>() / values.len() as f64
    }
}

pub fn std_dev(values: &[f64]) -> f64 {
    if values.is_empty() {
        return 0.0;
    }
    let mu = mean(values);
    (values.iter().map(|v| (v - mu).powi(2)).sum::<f64>() / values.len() as f64).sqrt()
}

pub fn median(values: &[f64]) -> f64 {
    if values.is_empty() {
        return 0.0;
    }
    let mut sorted = values.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
    let n = sorted.len();
    if n.is_multiple_of(2) {
        (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
    } else {
        sorted[n / 2]
    }
}

pub fn rmsd(a: &[f64], b: &[f64]) -> f64 {
    let n = a.len().min(b.len());
    if n == 0 {
        return 0.0;
    }
    (a.iter()
        .zip(b)
        .take(n)
        .map(|(x, y)| (x - y).powi(2))
        .sum::<f64>()
        / n as f64)
        .sqrt()
}

pub fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}

/// Sort paired x/y data by x, discarding any unpaired tail.
pub fn sorted_xy(x: &[f64], y: &[f64]) -> (Vec<f64>, Vec<f64>) {
    let mut pairs: Vec<(f64, f64)> = x.iter().copied().zip(y.iter().copied()).collect();
    pairs.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(Ordering::Equal));
    pairs.into_iter().unzip()
}

/// NumPy-compatible linear interpolation. Values outside the source domain
/// are clamped to the first/last ordinate.
pub fn interp_sorted(x: &[f64], y: &[f64], grid: &[f64]) -> Vec<f64> {
    let n = x.len().min(y.len());
    if n == 0 {
        return vec![0.0; grid.len()];
    }
    if n == 1 {
        return vec![y[0]; grid.len()];
    }
    grid.iter()
        .map(|&g| {
            if g <= x[0] {
                return y[0];
            }
            if g >= x[n - 1] {
                return y[n - 1];
            }
            let upper = x[..n].partition_point(|v| *v < g);
            let lower = upper.saturating_sub(1);
            let dx = x[upper] - x[lower];
            if dx == 0.0 {
                y[lower]
            } else {
                y[lower] + (g - x[lower]) / dx * (y[upper] - y[lower])
            }
        })
        .collect()
}

pub fn resample(x: &[f64], y: &[f64], grid: &[f64]) -> Vec<f64> {
    let (sx, sy) = sorted_xy(x, y);
    interp_sorted(&sx, &sy, grid)
}

/// Solve a dense square system using Gauss-Jordan elimination with partial
/// pivoting. The matrices here are at most a few elements across.
pub fn solve_linear(mut a: Vec<Vec<f64>>, mut b: Vec<f64>) -> Option<Vec<f64>> {
    let n = b.len();
    if a.len() != n || a.iter().any(|row| row.len() != n) {
        return None;
    }
    for col in 0..n {
        let pivot = (col..n).max_by(|&i, &j| {
            a[i][col]
                .abs()
                .partial_cmp(&a[j][col].abs())
                .unwrap_or(Ordering::Equal)
        })?;
        if a[pivot][col].abs() < 1e-15 {
            return None;
        }
        a.swap(col, pivot);
        b.swap(col, pivot);
        let d = a[col][col];
        for value in &mut a[col][col..] {
            *value /= d;
        }
        b[col] /= d;
        let pivot_row = a[col].clone();
        for row in 0..n {
            if row == col {
                continue;
            }
            let factor = a[row][col];
            if factor == 0.0 {
                continue;
            }
            for (value, pivot_value) in a[row][col..].iter_mut().zip(&pivot_row[col..]) {
                *value -= factor * pivot_value;
            }
            b[row] -= factor * b[col];
        }
    }
    Some(b)
}

/// Weighted polynomial least-squares coefficients, highest power first (the
/// same ordering returned by NumPy's `polyfit`).
pub fn polyfit_weighted(x: &[f64], y: &[f64], order: usize, weights: &[f64]) -> Option<Vec<f64>> {
    let n = x.len().min(y.len()).min(weights.len());
    let m = order + 1;
    if n < m {
        return None;
    }
    let mut normal = vec![vec![0.0; m]; m];
    let mut rhs = vec![0.0; m];
    for i in 0..n {
        let w2 = weights[i] * weights[i]; // numpy.polyfit applies w to residuals
        let mut powers = vec![1.0; 2 * order + 1];
        for p in 1..powers.len() {
            powers[p] = powers[p - 1] * x[i];
        }
        for (row, normal_row) in normal.iter_mut().enumerate() {
            let pr = order - row;
            rhs[row] += w2 * y[i] * powers[pr];
            for (col, cell) in normal_row.iter_mut().enumerate() {
                let pc = order - col;
                *cell += w2 * powers[pr + pc];
            }
        }
    }
    solve_linear(normal, rhs)
}

pub fn polyval(coefficients: &[f64], x: f64) -> f64 {
    coefficients.iter().fold(0.0, |acc, c| acc * x + c)
}

/// Intercept coefficients for a centred Savitzky-Golay window.
pub fn savgol_coefficients(window: usize, poly: usize) -> Option<Vec<f64>> {
    if window == 0 || window.is_multiple_of(2) || poly + 1 > window {
        return None;
    }
    let m = poly + 1;
    let half = (window / 2) as isize;
    let xs: Vec<f64> = (-half..=half).map(|v| v as f64).collect();
    let mut ata = vec![vec![0.0; m]; m];
    for &x in &xs {
        let mut powers = vec![1.0; 2 * poly + 1];
        for p in 1..powers.len() {
            powers[p] = powers[p - 1] * x;
        }
        for i in 0..m {
            for j in 0..m {
                ata[i][j] += powers[i + j];
            }
        }
    }
    let mut e0 = vec![0.0; m];
    e0[0] = 1.0;
    let z = solve_linear(ata, e0)?;
    Some(
        xs.iter()
            .map(|&x| {
                z.iter()
                    .enumerate()
                    .map(|(p, c)| c * x.powi(p as i32))
                    .sum()
            })
            .collect(),
    )
}

fn reflect_index(mut index: isize, len: usize) -> usize {
    if len <= 1 {
        return 0;
    }
    let last = len as isize - 1;
    while index < 0 || index > last {
        if index < 0 {
            index = -index;
        }
        if index > last {
            index = 2 * last - index;
        }
    }
    index as usize
}

pub fn savgol_smooth(y: &[f64], window: Option<usize>, poly: usize) -> Vec<f64> {
    let n = y.len();
    if n < 7 {
        return y.to_vec();
    }
    let mut win = window.unwrap_or_else(|| ((n as f64 * 0.03).round() as usize).max(5));
    win = win.max(5);
    if win.is_multiple_of(2) {
        win += 1;
    }
    if win > n {
        win = if n % 2 == 1 { n } else { n - 1 };
    }
    if win < poly + 2 {
        return y.to_vec();
    }
    let Some(coefficients) = savgol_coefficients(win, poly) else {
        return y.to_vec();
    };
    let half = (win / 2) as isize;
    (0..n)
        .map(|i| {
            coefficients
                .iter()
                .enumerate()
                .map(|(j, c)| {
                    let source = reflect_index(i as isize + j as isize - half, n);
                    c * y[source]
                })
                .sum()
        })
        .collect()
}

pub fn sanitize_filename(name: &str) -> String {
    let mut out = String::with_capacity(name.len());
    let mut underscore = false;
    for ch in name.chars() {
        if ch.is_ascii_alphanumeric() || matches!(ch, '_' | '.' | '-') {
            out.push(ch);
            underscore = false;
        } else if !underscore {
            out.push('_');
            underscore = true;
        }
    }
    let clean = out.trim_matches('_');
    if clean.is_empty() {
        "compound".into()
    } else {
        clean.into()
    }
}
