//! Shared logdedup.py protocol. All atoms participate; only graph automorphisms
//! and proper rotations are permitted. No Python runtime is required.
use crate::gaussian::GaussianEvidence;
use std::collections::{BTreeMap, BTreeSet, VecDeque};

pub use crate::math::HARTREE_TO_KCAL;
pub const ENERGY_WINDOW: f64 = 0.20;
pub const RMSD_THRESHOLD: f64 = 0.10;
pub const MAX_DEVIATION_THRESHOLD: f64 = 0.15;
pub const FREQUENCY_RMSD_THRESHOLD: f64 = 2.0;
pub const FREQUENCY_MAX_DIFF_THRESHOLD: f64 = 3.0;
const INERTIA_TOLERANCE: f64 = 0.05;
const MAX_AUTOMORPHISMS: usize = 500_000;
const NODE_BUDGET: usize = 10_000_000;
const MAX_SEEDS: usize = 720;
const MAX_ITERATIONS: usize = 25;
type Point = [f64; 3];
type Rotation = [[f64; 3]; 3];

fn mass(z: u16) -> f64 {
    match z {
        1 => 1.008,
        5 => 10.81,
        6 => 12.011,
        7 => 14.007,
        8 => 15.999,
        9 => 18.998,
        11 => 22.990,
        12 => 24.305,
        13 => 26.982,
        14 => 28.085,
        15 => 30.974,
        16 => 32.06,
        17 => 35.45,
        19 => 39.098,
        20 => 40.078,
        26 => 55.845,
        30 => 65.38,
        34 => 78.971,
        35 => 79.904,
        53 => 126.904,
        _ => 12.011,
    }
}
fn norm2(p: Point) -> f64 {
    p.iter().map(|v| v * v).sum()
}
fn sub(a: Point, b: Point) -> Point {
    std::array::from_fn(|i| a[i] - b[i])
}
fn rotate(p: Point, r: Rotation) -> Point {
    std::array::from_fn(|j| (0..3).map(|i| p[i] * r[i][j]).sum())
}
fn centroid(p: &[Point]) -> Point {
    std::array::from_fn(|i| p.iter().map(|p| p[i]).sum::<f64>() / p.len() as f64)
}
fn centered(p: &[Point]) -> Vec<Point> {
    let c = centroid(p);
    p.iter().map(|&p| sub(p, c)).collect()
}

/// Jacobi diagonalization of a small real symmetric matrix; eigenvectors are columns.
fn eigen<const N: usize>(mut a: [[f64; N]; N]) -> ([f64; N], [[f64; N]; N]) {
    let mut v = std::array::from_fn(|i| std::array::from_fn(|j| if i == j { 1.0 } else { 0.0 }));
    for _ in 0..256 {
        let (mut p, mut q, mut largest) = (0, 1, 0.0);
        for (i, row) in a.iter().enumerate() {
            for (j, value) in row.iter().enumerate().skip(i + 1) {
                if value.abs() > largest {
                    (p, q, largest) = (i, j, value.abs());
                }
            }
        }
        let scale = (0..N).map(|i| a[i][i].abs()).fold(1.0, f64::max);
        if largest <= 1e-15 * scale {
            break;
        }
        let angle = 0.5 * (2.0 * a[p][q]).atan2(a[q][q] - a[p][p]);
        let (s, c) = angle.sin_cos();
        let (pp, qq, pq) = (a[p][p], a[q][q], a[p][q]);
        for (k, (pk, qk)) in a[p].into_iter().zip(a[q]).enumerate() {
            if k != p && k != q {
                a[p][k] = c * pk - s * qk;
                a[k][p] = a[p][k];
                a[q][k] = s * pk + c * qk;
                a[k][q] = a[q][k];
            }
        }
        a[p][p] = c * c * pp - 2.0 * s * c * pq + s * s * qq;
        a[q][q] = s * s * pp + 2.0 * s * c * pq + c * c * qq;
        a[p][q] = 0.0;
        a[q][p] = 0.0;
        for row in &mut v {
            let (vp, vq) = (row[p], row[q]);
            row[p] = c * vp - s * vq;
            row[q] = s * vp + c * vq;
        }
    }
    (std::array::from_fn(|i| a[i][i]), v)
}
fn rotation_centered(a: &[Point], b: &[Point]) -> Rotation {
    let mut cov = [[0.0; 3]; 3];
    for (a, b) in a.iter().zip(b) {
        for (i, row) in cov.iter_mut().enumerate() {
            for (j, value) in row.iter_mut().enumerate() {
                *value += a[i] * b[j];
            }
        }
    }
    let [[xx, xy, xz], [yx, yy, yz], [zx, zy, zz]] = cov;
    let (values, vectors) = eigen([
        [xx + yy + zz, yz - zy, zx - xz, xy - yx],
        [yz - zy, xx - yy - zz, xy + yx, zx + xz],
        [zx - xz, xy + yx, -xx + yy - zz, yz + zy],
        [xy - yx, zx + xz, yz + zy, -xx - yy + zz],
    ]);
    let k = (0..4)
        .max_by(|&i, &j| values[i].total_cmp(&values[j]))
        .unwrap();
    let [w, x, y, z] = std::array::from_fn(|i| vectors[i][k]);
    [
        [
            w * w + x * x - y * y - z * z,
            2.0 * (x * y - w * z),
            2.0 * (x * z + w * y),
        ],
        [
            2.0 * (x * y + w * z),
            w * w - x * x + y * y - z * z,
            2.0 * (y * z - w * x),
        ],
        [
            2.0 * (x * z - w * y),
            2.0 * (y * z + w * x),
            w * w - x * x - y * y + z * z,
        ],
    ]
}

#[derive(Clone, Copy, Debug)]
pub struct GeometryMatch {
    pub rmsd: f64,
    pub max_deviation: f64,
}
impl GeometryMatch {
    pub fn passes(self) -> bool {
        self.rmsd <= RMSD_THRESHOLD && self.max_deviation <= MAX_DEVIATION_THRESHOLD
    }
}
fn aligned_centered(a: &[Point], b: &[Point]) -> GeometryMatch {
    let r = rotation_centered(a, b);
    let squared: Vec<f64> = a
        .iter()
        .zip(b)
        .map(|(&a, &b)| norm2(sub(a, rotate(b, r))))
        .collect();
    // Explicit displacements supply both metrics, so the maximum and RMSD can never
    // refer to different rotations (the consistency requirement in logdedup.py).
    GeometryMatch {
        rmsd: (squared.iter().sum::<f64>() / a.len() as f64).sqrt(),
        max_deviation: squared.into_iter().fold(0.0, f64::max).sqrt(),
    }
}
pub fn superposition(a: &[Point], b: &[Point]) -> Option<GeometryMatch> {
    if a.is_empty() || a.len() != b.len() || a.iter().chain(b).flatten().any(|v| !v.is_finite()) {
        return None;
    }
    Some(aligned_centered(&centered(a), &centered(b)))
}
fn principal_moments(data: &GaussianEvidence) -> [f64; 3] {
    let masses: Vec<f64> = data.atomic_numbers.iter().map(|&z| mass(z)).collect();
    let total = masses.iter().sum::<f64>();
    let centre: Point = std::array::from_fn(|i| {
        data.coordinates
            .iter()
            .zip(&masses)
            .map(|(p, m)| p[i] * m)
            .sum::<f64>()
            / total
    });
    let mut tensor = [[0.0; 3]; 3];
    for (&p, m) in data.coordinates.iter().zip(masses) {
        let p = sub(p, centre);
        let n = norm2(p);
        for (i, row) in tensor.iter_mut().enumerate() {
            for (j, v) in row.iter_mut().enumerate() {
                *v += m * ((if i == j { n } else { 0.0 }) - p[i] * p[j]);
            }
        }
    }
    let (mut values, _) = eigen(tensor);
    values.sort_by(f64::total_cmp);
    values
}
fn moments_compatible(a: [f64; 3], b: [f64; 3]) -> bool {
    a.iter()
        .zip(b)
        .all(|(a, b)| (a - b).abs() / a.abs().max(b.abs()).max(1e-9) <= INERTIA_TOLERANCE)
}

pub fn frequency_agreement(a: &[f64], b: &[f64]) -> Option<(f64, f64)> {
    if a.is_empty() || a.len() != b.len() || a.iter().chain(b).any(|v| !v.is_finite()) {
        return None;
    }
    let (mut a, mut b) = (a.to_vec(), b.to_vec());
    a.sort_by(f64::total_cmp);
    b.sort_by(f64::total_cmp);
    let diffs: Vec<f64> = a.iter().zip(b).map(|(a, b)| (a - b).abs()).collect();
    Some((
        (diffs.iter().map(|d| d * d).sum::<f64>() / diffs.len() as f64).sqrt(),
        diffs.into_iter().fold(0.0, f64::max),
    ))
}
fn valid_geometry(d: &GaussianEvidence) -> bool {
    let n = d.atomic_numbers.len();
    n > 0
        && n == d.coordinates.len()
        && d.atomic_numbers.iter().all(|&z| z > 0 && z <= 118)
        && d.coordinates.iter().flatten().all(|v| v.is_finite())
        && d.connectivity.len() == n
        && d.connectivity.iter().enumerate().all(|(i, ns)| {
            ns.iter()
                .all(|&j| j < n && j != i && d.connectivity[j].contains(&i))
        })
}
fn canonical_graph(d: &GaussianEvidence) -> Vec<Vec<usize>> {
    d.connectivity
        .iter()
        .map(|ns| {
            ns.iter()
                .copied()
                .collect::<BTreeSet<_>>()
                .into_iter()
                .collect()
        })
        .collect()
}

fn ring_membership(graph: &[Vec<usize>]) -> Vec<usize> {
    let n = graph.len();
    let mut smallest = vec![0; n];
    for a in 0..n {
        for &b in &graph[a] {
            if b <= a {
                continue;
            }
            let mut previous = vec![usize::MAX; n];
            previous[a] = a;
            let mut queue = VecDeque::from([a]);
            while let Some(current) = queue.pop_front() {
                if current == b {
                    break;
                }
                for &next in &graph[current] {
                    if (current == a && next == b) || previous[next] != usize::MAX {
                        continue;
                    }
                    previous[next] = current;
                    queue.push_back(next);
                }
            }
            if previous[b] == usize::MAX {
                continue;
            }
            let mut path = vec![b];
            let mut node = b;
            while node != a {
                node = previous[node];
                path.push(node);
            }
            if (3..=10).contains(&path.len()) {
                for &member in &path {
                    if smallest[member] == 0 || path.len() < smallest[member] {
                        smallest[member] = path.len();
                    }
                }
            }
        }
    }
    smallest
}
fn rank<T: Ord + Clone>(keys: &[T]) -> Vec<usize> {
    let ranks: BTreeMap<T, usize> = keys
        .iter()
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .enumerate()
        .map(|(i, k)| (k, i))
        .collect();
    keys.iter().map(|k| ranks[k]).collect()
}
fn refined_labels(z: &[u16], graph: &[Vec<usize>]) -> Vec<usize> {
    let rings = ring_membership(graph);
    let mut labels = rank(
        &(0..z.len())
            .map(|i| (z[i], graph[i].len(), rings[i]))
            .collect::<Vec<_>>(),
    );
    loop {
        let keys: Vec<_> = (0..z.len())
            .map(|i| {
                let mut ns: Vec<_> = graph[i].iter().map(|&j| labels[j]).collect();
                ns.sort_unstable();
                (labels[i], ns)
            })
            .collect();
        let updated = rank(&keys);
        if updated.iter().max() == labels.iter().max() {
            return updated;
        }
        labels = updated;
    }
}
fn classes(labels: &[usize]) -> Vec<Vec<usize>> {
    let mut groups: BTreeMap<usize, Vec<usize>> = BTreeMap::new();
    for (i, &l) in labels.iter().enumerate() {
        groups.entry(l).or_default().push(i);
    }
    let mut groups: Vec<_> = groups.into_values().collect();
    groups.sort_by_key(Vec::len);
    groups
}
fn is_automorphism(p: &[usize], graph: &[Vec<usize>]) -> bool {
    p.len() == graph.len()
        && p.iter().copied().collect::<BTreeSet<_>>().len() == p.len()
        && p.iter().all(|&i| i < graph.len())
        && graph.iter().enumerate().all(|(i, ns)| {
            let mut image: Vec<_> = ns.iter().map(|&j| p[j]).collect();
            image.sort_unstable();
            image == graph[p[i]]
        })
}
fn hungarian(cost: &[Vec<f64>]) -> Vec<usize> {
    let n = cost.len();
    let mut u = vec![0.0; n + 1];
    let mut v = vec![0.0; n + 1];
    let mut p = vec![0; n + 1];
    let mut way = vec![0; n + 1];
    for i in 1..=n {
        p[0] = i;
        let mut j0 = 0;
        let mut minv = vec![f64::INFINITY; n + 1];
        let mut used = vec![false; n + 1];
        loop {
            used[j0] = true;
            let i0 = p[j0];
            let mut delta = f64::INFINITY;
            let mut j1 = 0;
            for j in 1..=n {
                if !used[j] {
                    let cur = cost[i0 - 1][j - 1] - u[i0] - v[j];
                    if cur < minv[j] {
                        minv[j] = cur;
                        way[j] = j0;
                    }
                    if minv[j] < delta {
                        delta = minv[j];
                        j1 = j;
                    }
                }
            }
            for j in 0..=n {
                if used[j] {
                    u[p[j]] += delta;
                    v[j] -= delta;
                } else {
                    minv[j] -= delta;
                }
            }
            j0 = j1;
            if p[j0] == 0 {
                break;
            }
        }
        while j0 != 0 {
            let j1 = way[j0];
            p[j0] = p[j1];
            j0 = j1;
        }
    }
    let mut assignment = vec![0; n];
    for j in 1..=n {
        if p[j] != 0 {
            assignment[p[j] - 1] = j - 1;
        }
    }
    assignment
}
fn permutations(values: &[usize]) -> Vec<Vec<usize>> {
    fn rec(values: &[usize], prefix: &mut Vec<usize>, out: &mut Vec<Vec<usize>>) {
        if prefix.len() == values.len() {
            out.push(prefix.clone());
            return;
        }
        for &v in values {
            if !prefix.contains(&v) {
                prefix.push(v);
                rec(values, prefix, out);
                prefix.pop();
            }
        }
    }
    let mut out = Vec::new();
    rec(values, &mut Vec::new(), &mut out);
    out
}
fn run_seed(
    seed: &[(usize, usize)],
    remaining: &[Vec<usize>],
    a: &[Point],
    b: &[Point],
    graph: &[Vec<usize>],
) -> Option<Vec<usize>> {
    let n = a.len();
    let mut corr = vec![usize::MAX; n];
    for &(i, j) in seed {
        corr[i] = j;
    }
    let ac = centered(a);
    let bc = centered(b);
    let mut previous = None;
    for _ in 0..MAX_ITERATIONS {
        let anchors: Vec<_> = corr
            .iter()
            .enumerate()
            .filter(|&(_, &j)| j != usize::MAX)
            .map(|(i, &j)| (a[i], b[j]))
            .collect();
        if anchors.len() < 3 {
            return None;
        }
        let aa: Vec<_> = anchors.iter().map(|p| p.0).collect();
        let bb: Vec<_> = anchors.iter().map(|p| p.1).collect();
        let r = rotation_centered(&centered(&aa), &centered(&bb));
        let mut updated = vec![usize::MAX; n];
        for &(i, j) in seed {
            updated[i] = j;
        }
        for group in remaining {
            let cost: Vec<Vec<f64>> = group
                .iter()
                .map(|&i| {
                    group
                        .iter()
                        .map(|&j| norm2(sub(ac[i], rotate(bc[j], r))))
                        .collect()
                })
                .collect();
            let assignment = hungarian(&cost);
            for (row, &i) in group.iter().enumerate() {
                updated[i] = group[assignment[row]];
            }
        }
        if previous.as_ref() == Some(&updated) {
            return is_automorphism(&updated, graph).then_some(updated);
        }
        previous = Some(corr);
        corr = updated;
    }
    None
}
fn orbit_guided(
    a: &[Point],
    b: &[Point],
    graph: &[Vec<usize>],
    groups: &[Vec<usize>],
) -> Option<Vec<usize>> {
    let singletons: Vec<_> = groups
        .iter()
        .filter(|g| g.len() == 1)
        .map(|g| (g[0], g[0]))
        .collect();
    if singletons.len() >= 3 {
        let remaining: Vec<_> = groups.iter().filter(|g| g.len() > 1).cloned().collect();
        return run_seed(&singletons, &remaining, a, b, graph);
    }
    let (mut selected, mut budget, mut atoms) = (0, 1usize, 0);
    for group in groups {
        let factorial = (1..=group.len())
            .try_fold(1usize, |p, v| p.checked_mul(v))
            .unwrap_or(usize::MAX);
        let next = budget.saturating_mul(factorial);
        if next > MAX_SEEDS && selected > 0 {
            break;
        }
        selected += 1;
        budget = next;
        atoms += group.len();
        if atoms >= 3 {
            break;
        }
    }
    if atoms < 3 || budget > MAX_SEEDS {
        return None;
    }
    let mut seeds = vec![Vec::new()];
    for group in &groups[..selected] {
        let mut next = Vec::new();
        for prefix in seeds {
            for perm in permutations(group) {
                let mut seed = prefix.clone();
                seed.extend(group.iter().copied().zip(perm));
                next.push(seed);
            }
        }
        seeds = next;
    }
    let mut best: Option<(f64, Vec<usize>)> = None;
    for seed in seeds {
        if let Some(p) = run_seed(&seed, &groups[selected..], a, b, graph) {
            let reordered: Vec<_> = p.iter().map(|&j| b[j]).collect();
            let rmsd = superposition(a, &reordered)?.rmsd;
            if best.as_ref().is_none_or(|(r, _)| rmsd < *r) {
                best = Some((rmsd, p));
            }
            if rmsd <= RMSD_THRESHOLD * 0.1 {
                break;
            }
        }
    }
    best.map(|(_, p)| p)
}

struct ExactSearch<'a> {
    graph: &'a [Vec<usize>],
    labels: &'a [usize],
    order: Vec<usize>,
    mapping: Vec<usize>,
    reverse: Vec<usize>,
    a: Vec<Point>,
    b: Vec<Point>,
    nodes: usize,
    count: usize,
    truncated: bool,
    best: Option<GeometryMatch>,
    matched: bool,
}
impl ExactSearch<'_> {
    fn visit(&mut self, depth: usize) {
        if self.matched || self.truncated {
            return;
        }
        if depth == self.order.len() {
            self.count += 1;
            let b: Vec<_> = self.mapping.iter().map(|&j| self.b[j]).collect();
            let result = aligned_centered(&self.a, &b);
            if self.best.is_none_or(|r| result.rmsd < r.rmsd) || result.passes() {
                self.best = Some(result);
            }
            self.matched = result.passes();
            if self.count >= MAX_AUTOMORPHISMS {
                self.truncated = true;
            }
            return;
        }
        let atom = self.order[depth];
        for candidate in 0..self.mapping.len() {
            if self.reverse[candidate] != usize::MAX || self.labels[atom] != self.labels[candidate]
            {
                continue;
            }
            self.nodes += 1;
            if self.nodes >= NODE_BUDGET {
                self.truncated = true;
                return;
            }
            if self.graph[atom].iter().any(|&j| {
                self.mapping[j] != usize::MAX && !self.graph[candidate].contains(&self.mapping[j])
            }) || self.graph[candidate].iter().any(|&j| {
                self.reverse[j] != usize::MAX && !self.graph[atom].contains(&self.reverse[j])
            }) {
                continue;
            }
            self.mapping[atom] = candidate;
            self.reverse[candidate] = atom;
            self.visit(depth + 1);
            self.mapping[atom] = usize::MAX;
            self.reverse[candidate] = usize::MAX;
            if self.matched || self.truncated {
                return;
            }
        }
    }
}
fn traversal(graph: &[Vec<usize>]) -> Vec<usize> {
    let mut seen = vec![false; graph.len()];
    let mut order = Vec::new();
    for start in 0..graph.len() {
        if seen[start] {
            continue;
        }
        seen[start] = true;
        order.push(start);
        let mut queue = VecDeque::from([start]);
        while let Some(current) = queue.pop_front() {
            for &next in &graph[current] {
                if !seen[next] {
                    seen[next] = true;
                    order.push(next);
                    queue.push_back(next);
                }
            }
        }
    }
    order
}

/// Geometry-independent refinement is prepared once per distinct skeleton,
/// rather than recomputing ring membership for every conformer pair.
struct SymmetryGraph {
    graph: Vec<Vec<usize>>,
    labels: Vec<usize>,
    classes: Vec<Vec<usize>>,
    order: Vec<usize>,
}
impl SymmetryGraph {
    fn new(z: &[u16], graph: Vec<Vec<usize>>) -> Self {
        let labels = refined_labels(z, &graph);
        let classes = classes(&labels);
        let order = traversal(&graph);
        Self {
            graph,
            labels,
            classes,
            order,
        }
    }
}

/// Returns the first qualifying graph-legal correspondence, or the best examined
/// proper-rotation result. A capped search can miss a duplicate, never invent one.
pub fn symmetry_distance(
    a: &GaussianEvidence,
    b: &GaussianEvidence,
) -> (Option<GeometryMatch>, bool) {
    if !valid_geometry(a) || !valid_geometry(b) || a.atomic_numbers != b.atomic_numbers {
        return (None, false);
    }
    let graph = canonical_graph(a);
    if graph != canonical_graph(b) {
        return (None, false);
    }
    symmetry_distance_prepared(a, b, &SymmetryGraph::new(&a.atomic_numbers, graph))
}

fn symmetry_distance_prepared(
    a: &GaussianEvidence,
    b: &GaussianEvidence,
    context: &SymmetryGraph,
) -> (Option<GeometryMatch>, bool) {
    let identity = superposition(&a.coordinates, &b.coordinates);
    if identity.is_some_and(GeometryMatch::passes) {
        return (identity, false);
    }
    if let Some(p) = orbit_guided(
        &a.coordinates,
        &b.coordinates,
        &context.graph,
        &context.classes,
    ) {
        let reordered: Vec<_> = p.iter().map(|&j| b.coordinates[j]).collect();
        let result = superposition(&a.coordinates, &reordered);
        if result.is_some_and(GeometryMatch::passes) {
            return (result, false);
        }
    }
    // A valid heuristic correspondence that misses a gate is not proof of a
    // nonduplicate: continue to exact graph search as the Python comments intend.
    let n = context.graph.len();
    let mut search = ExactSearch {
        graph: &context.graph,
        labels: &context.labels,
        order: context.order.clone(),
        mapping: vec![usize::MAX; n],
        reverse: vec![usize::MAX; n],
        a: centered(&a.coordinates),
        b: centered(&b.coordinates),
        nodes: 0,
        count: 0,
        truncated: false,
        best: identity,
        matched: false,
    };
    search.visit(0);
    (search.best, search.truncated)
}

#[derive(Clone, Debug)]
pub struct Duplicate {
    pub duplicate: usize,
    pub representative: usize,
    pub energy_gap: f64,
    pub geometry: GeometryMatch,
    pub frequency_rmsd: f64,
    pub frequency_max: f64,
}
#[derive(Clone, Debug, Default)]
pub struct DedupResult {
    pub survivors: Vec<usize>,
    pub rejected: Vec<(usize, String)>,
    pub duplicates: Vec<Duplicate>,
    pub ungated: Vec<usize>,
    pub imaginary: Vec<usize>,
    pub frequency_blocked: usize,
    pub graph_mismatches: usize,
    pub truncated_pairs: usize,
    pub inertia_screened: usize,
}
impl DedupResult {
    pub fn remap_indices(&mut self, original: &[usize]) {
        for i in self
            .survivors
            .iter_mut()
            .chain(&mut self.ungated)
            .chain(&mut self.imaginary)
        {
            *i = original[*i];
        }
        for pair in &mut self.duplicates {
            pair.duplicate = original[pair.duplicate];
            pair.representative = original[pair.representative];
        }
    }
}

/// Lowest Gibbs energy wins; candidates compare only with retained representatives.
/// Missing evidence, unequal mode counts, and inconsistent graphs never authorize deletion.
pub fn deduplicate(data: &[GaussianEvidence]) -> DedupResult {
    let mut result = DedupResult::default();
    let mut ordered = Vec::new();
    let mut moments = BTreeMap::new();
    let mut contexts = Vec::new();
    let mut context_ids = BTreeMap::new();
    let mut graph_ids = vec![usize::MAX; data.len()];
    for (i, d) in data.iter().enumerate() {
        if d.imaginary_modes > 0 {
            result.imaginary.push(i);
            result.survivors.push(i);
            continue;
        }
        if !valid_geometry(d)
            || d.gibbs.is_none_or(|g| !g.is_finite())
            || d.error_termination
            || frequency_agreement(&d.frequencies, &d.frequencies).is_none()
        {
            result.ungated.push(i);
            result.survivors.push(i);
            continue;
        }
        ordered.push(i);
        moments.insert(i, principal_moments(d));
        let key = (d.atomic_numbers.clone(), canonical_graph(d));
        let id = *context_ids.entry(key.clone()).or_insert_with(|| {
            contexts.push(SymmetryGraph::new(&key.0, key.1.clone()));
            contexts.len() - 1
        });
        graph_ids[i] = id;
    }
    ordered.sort_by(|&a, &b| {
        data[a]
            .gibbs
            .unwrap()
            .total_cmp(&data[b].gibbs.unwrap())
            .then(a.cmp(&b))
    });
    let mut representatives = Vec::<usize>::new();
    for candidate in ordered {
        let mut matched: Option<Duplicate> = None;
        for &representative in &representatives {
            let (a, b) = (&data[representative], &data[candidate]);
            let gap = (b.gibbs.unwrap() - a.gibbs.unwrap()).abs() * HARTREE_TO_KCAL;
            if gap > ENERGY_WINDOW {
                continue;
            }
            if graph_ids[representative] != graph_ids[candidate] {
                result.graph_mismatches += 1;
                continue;
            }
            if !moments_compatible(moments[&representative], moments[&candidate]) {
                result.inertia_screened += 1;
                continue;
            }
            let (geometry, truncated) =
                symmetry_distance_prepared(a, b, &contexts[graph_ids[candidate]]);
            if truncated {
                result.truncated_pairs += 1;
            }
            let Some(geometry) = geometry.filter(|m| m.passes()) else {
                continue;
            };
            let Some((frequency_rmsd, frequency_max)) =
                frequency_agreement(&a.frequencies, &b.frequencies)
            else {
                result.frequency_blocked += 1;
                continue;
            };
            if frequency_rmsd > FREQUENCY_RMSD_THRESHOLD
                || frequency_max > FREQUENCY_MAX_DIFF_THRESHOLD
            {
                result.frequency_blocked += 1;
                continue;
            }
            let record = Duplicate {
                duplicate: candidate,
                representative,
                energy_gap: gap,
                geometry,
                frequency_rmsd,
                frequency_max,
            };
            if matched
                .as_ref()
                .is_none_or(|d| geometry.rmsd < d.geometry.rmsd)
            {
                matched = Some(record);
            }
        }
        if let Some(record) = matched {
            result.duplicates.push(record);
        } else {
            representatives.push(candidate);
        }
    }
    result.survivors.extend(representatives);
    result.survivors.sort_unstable();
    result
}
