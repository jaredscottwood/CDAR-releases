//! Vibrational IR/VCD parsing, matching, and assignment.

use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::{Arc, OnceLock};

use anyhow::{Context, Result, anyhow, bail};
use rayon::prelude::*;
use regex::Regex;

use crate::electronic::{Spectrum, boltzmann_weights};
use crate::math::{T_DEFAULT, arange, interp_sorted, linspace, max_abs, median, min_max, resample};

pub const VIB_SCALE_DEFAULT: f64 = 0.98;
pub const VIB_GAMMA_DEFAULT: f64 = 6.0;
pub const VIB_RANGE_DEFAULT: (i32, i32) = (1000, 1600);
pub const VIB_MAX_SHIFT_DEFAULT: i32 = 20;
pub const VIB_GRID_MIN: i32 = 800;
pub const VIB_GRID_MAX: i32 = 2200;
pub const VIB_CALCULATED_FITTED_LABEL: &str = "Calculated (fitted)";
pub const VIB_ENANTIOMER_FITTED_LABEL: &str = "Enantiomer (fitted)";

#[derive(Clone, Debug, Default)]
pub struct VibConformer {
    pub name: String,
    pub path: PathBuf,
    pub scf_energy: Option<f64>,
    pub free_energy: Option<f64>,
    pub atomic_numbers: Vec<u16>,
    pub coordinates_angstrom: Vec<[f64; 3]>,
    /// Zero-based, undirected bond adjacency parsed from Gaussian's Initial
    /// Parameters table. Empty when the table is unavailable.
    pub connectivity: Vec<Vec<usize>>,
    pub frequencies: Vec<f64>,
    pub dipole_strengths: Vec<f64>,
    pub rotatory_strengths: Vec<f64>,
    pub imaginary_modes: usize,
    pub terminated_normally: bool,
    pub error_termination: bool,
    pub connectivity_reported: bool,
    pub ground_state_optimization_completed: bool,
    pub validation_errors: Vec<String>,
    pub include: bool,
    pub weight: f64,
}

impl VibConformer {
    pub fn nmodes(&self) -> usize {
        self.frequencies.len()
    }

    /// Gibbs free energy used by every vibrational population calculation.
    /// SCF energies remain available as parser diagnostics but are never used
    /// as a thermodynamic weighting fallback.
    pub fn weighting_energy(&self) -> Option<f64> {
        self.free_energy.filter(|g| g.is_finite())
    }
}

fn read_lossy(path: &Path) -> Result<String> {
    let bytes = fs::read(path).with_context(|| format!("could not read {}", path.display()))?;
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}

pub fn parse_gaussian_vib(path: impl AsRef<Path>) -> Result<VibConformer> {
    let path = path.as_ref();
    let text = read_lossy(path)?;
    static SCF_RE: OnceLock<Regex> = OnceLock::new();
    let scf_re =
        SCF_RE.get_or_init(|| Regex::new(r"SCF Done:\s+E\([^)]*\)\s*=\s*(-?\d+\.\d+)").unwrap());
    let scf_energy = scf_re
        .captures_iter(&text)
        .last()
        .and_then(|capture| capture.get(1))
        .and_then(|value| value.as_str().parse().ok());
    let evidence = crate::gaussian::parse_opt_freq(&text, path);
    evidence.validate_optimization()?;
    let mut dipole_strengths = Vec::new();
    let mut rotatory_strengths = Vec::new();
    for line in text
        .lines()
        .skip(evidence.mode_range.start)
        .take(evidence.mode_range.len())
    {
        let trimmed = line.trim();
        let target = if trimmed.starts_with("Dip. str.") {
            &mut dipole_strengths
        } else if trimmed.starts_with("Rot. str.") {
            &mut rotatory_strengths
        } else {
            continue;
        };
        let tail = trimmed
            .split_once("--")
            .ok_or_else(|| anyhow!("malformed vibrational intensity row"))?
            .1;
        for token in tail.split_whitespace() {
            target.push(
                crate::gaussian::parse_number(token)
                    .ok_or_else(|| anyhow!("invalid vibrational intensity"))?,
            );
        }
    }
    let imaginary_modes = evidence.imaginary_modes;
    let conformer = VibConformer {
        name: path
            .file_stem()
            .and_then(|value| value.to_str())
            .unwrap_or("conformer")
            .into(),
        path: path.to_path_buf(),
        scf_energy,
        free_energy: evidence.gibbs,
        atomic_numbers: evidence.atomic_numbers,
        coordinates_angstrom: evidence.coordinates,
        connectivity: evidence.connectivity,
        connectivity_reported: evidence.connectivity_reported,
        error_termination: evidence.error_termination,
        frequencies: evidence.frequencies,
        dipole_strengths,
        rotatory_strengths,
        imaginary_modes,
        terminated_normally: evidence.terminated_normally,
        ground_state_optimization_completed: evidence.ground_state_optimization_completed,
        validation_errors: evidence.validation_errors,
        include: true,
        weight: 0.0,
    };
    conformer.validate()?;
    Ok(conformer)
}

pub fn looks_like_gaussian_log(path: impl AsRef<Path>) -> bool {
    if path
        .as_ref()
        .extension()
        .and_then(|s| s.to_str())
        .is_some_and(|s| s.eq_ignore_ascii_case("log") || s.eq_ignore_ascii_case("out"))
    {
        return true;
    }
    let Ok(file) = fs::File::open(path.as_ref()) else {
        return false;
    };
    let mut bytes = Vec::new();
    if file.take(4000).read_to_end(&mut bytes).is_err() {
        return false;
    }
    let head = String::from_utf8_lossy(&bytes);
    head.contains("Entering Gaussian System")
        || head.contains("Gaussian, Inc.")
        || head.contains("Entering Link 1")
}

pub fn lorentzian_vib(grid: &[f64], centers: &[f64], weights: &[f64], gamma: f64) -> Vec<f64> {
    let n = centers.len().min(weights.len());
    if n == 0 {
        return vec![0.0; grid.len()];
    }
    let gamma2 = gamma * gamma;
    grid.par_iter()
        .map(|&x| {
            (0..n)
                .map(|i| {
                    let distance = x - centers[i];
                    weights[i] * gamma * gamma / (distance * distance + gamma2)
                })
                .sum()
        })
        .collect()
}

pub fn broaden_vib(
    frequencies: &[f64],
    strengths: &[f64],
    grid: &[f64],
    scale: f64,
    gamma: f64,
) -> Vec<f64> {
    let centers: Vec<f64> = frequencies.iter().map(|value| value * scale).collect();
    lorentzian_vib(grid, &centers, strengths, gamma)
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum VibKind {
    #[default]
    Ir,
    Vcd,
}

impl VibKind {
    pub fn label(self) -> &'static str {
        match self {
            Self::Ir => "IR",
            Self::Vcd => "VCD",
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct VibWeightedSticks {
    pub centers: Vec<f64>,
    pub strengths: Vec<f64>,
    pub populations: Vec<f64>,
    pub used_indices: Vec<usize>,
}

pub fn vib_weighted_sticks(
    conformers: &[VibConformer],
    kind: VibKind,
    temperature: f64,
) -> VibWeightedSticks {
    let used_indices: Vec<usize> = conformers
        .iter()
        .enumerate()
        .filter(|(_, conformer)| conformer.include && conformer.validate().is_ok())
        .map(|(index, _)| index)
        .collect();
    if used_indices.is_empty() {
        return VibWeightedSticks::default();
    }
    let energies: Vec<f64> = used_indices
        .iter()
        .map(|&index| conformers[index].weighting_energy().unwrap())
        .collect();
    let populations = boltzmann_weights(&energies, temperature).0;
    let mode_count: usize = used_indices
        .iter()
        .map(|&index| conformers[index].nmodes())
        .sum();
    let mut centers = Vec::with_capacity(mode_count);
    let mut strengths = Vec::with_capacity(mode_count);
    for (&index, &population) in used_indices.iter().zip(&populations) {
        let conformer = &conformers[index];
        let n = conformer.nmodes();
        centers.extend_from_slice(&conformer.frequencies[..n]);
        let source = match kind {
            VibKind::Ir => &conformer.dipole_strengths,
            VibKind::Vcd => &conformer.rotatory_strengths,
        };
        strengths.extend(source[..n].iter().map(|value| value * population));
    }
    VibWeightedSticks {
        centers,
        strengths,
        populations,
        used_indices,
    }
}

/// Proper-rotation all-atom RMSD, also used by the shared symmetry engine.
pub fn kabsch_rmsd(first: &[[f64; 3]], second: &[[f64; 3]]) -> Option<f64> {
    crate::dedup::superposition(first, second).map(|m| m.rmsd)
}

impl VibConformer {
    pub fn validate(&self) -> Result<()> {
        self.dedup_evidence().validate_optimization()?;
        let n = self.frequencies.len();
        if self.dipole_strengths.len() != n
            || self
                .dipole_strengths
                .iter()
                .any(|v| !v.is_finite() || *v < 0.0)
            || self.rotatory_strengths.len() != n
            || self.rotatory_strengths.iter().any(|v| !v.is_finite())
        {
            bail!("incomplete IR dipole or VCD rotational-strength data");
        }
        Ok(())
    }

    pub fn dedup_evidence(&self) -> crate::gaussian::GaussianEvidence {
        crate::gaussian::GaussianEvidence {
            source: self.path.clone(),
            atomic_numbers: self.atomic_numbers.clone(),
            coordinates: self.coordinates_angstrom.clone(),
            connectivity: self.connectivity.clone(),
            connectivity_reported: self.connectivity_reported,
            gibbs: self.free_energy,
            frequencies: self.frequencies.clone(),
            imaginary_modes: self.imaginary_modes,
            terminated_normally: self.terminated_normally,
            error_termination: self.error_termination,
            ground_state_optimization_completed: self.ground_state_optimization_completed,
            validation_errors: self.validation_errors.clone(),
            ..Default::default()
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct VibDedupeResult {
    pub conformers: Vec<VibConformer>,
    pub report: crate::dedup::DedupResult,
}

pub fn dedupe_vib(conformers: &[VibConformer]) -> VibDedupeResult {
    let mut eligible = Vec::new();
    let mut rejected = Vec::new();
    for (i, c) in conformers.iter().enumerate() {
        match c.validate() {
            Ok(()) => eligible.push(i),
            Err(error) => rejected.push((i, error.to_string())),
        }
    }
    let evidence: Vec<_> = eligible
        .iter()
        .map(|&i| conformers[i].dedup_evidence())
        .collect();
    let mut report = crate::dedup::deduplicate(&evidence);
    report.remap_indices(&eligible);
    report.rejected = rejected;
    let retained = report
        .survivors
        .iter()
        .map(|&i| conformers[i].clone())
        .collect();
    VibDedupeResult {
        conformers: retained,
        report,
    }
}

pub fn to_integer_grid(spectrum: &Spectrum, minimum: f64, maximum: f64) -> (Vec<i32>, Vec<f64>) {
    let start = minimum.ceil() as i32;
    let end = maximum.floor() as i32;
    let grid_i: Vec<i32> = if end >= start {
        (start..=end).collect()
    } else {
        Vec::new()
    };
    let grid_f: Vec<f64> = grid_i.iter().map(|value| *value as f64).collect();
    (grid_i, resample(&spectrum.x, &spectrum.y, &grid_f))
}

pub fn normalize_vib(values: &[f64], kind: VibKind) -> Vec<f64> {
    match kind {
        VibKind::Ir => {
            let (lo, hi) = min_max(values).unwrap_or((0.0, 0.0));
            if hi > lo {
                values
                    .iter()
                    .map(|value| (value - lo) / (hi - lo))
                    .collect()
            } else {
                vec![0.0; values.len()]
            }
        }
        VibKind::Vcd => {
            let amplitude = max_abs(values);
            if amplitude > 0.0 {
                values.iter().map(|value| value / amplitude).collect()
            } else {
                vec![0.0; values.len()]
            }
        }
    }
}

pub type IntegerSpectrum = BTreeMap<i32, f64>;

fn as_integer_spectrum(grid: &[i32], values: &[f64]) -> IntegerSpectrum {
    grid.iter().copied().zip(values.iter().copied()).collect()
}

pub fn shen_similarity(
    calculated: &IntegerSpectrum,
    observed: &IntegerSpectrum,
    low: i32,
    high: i32,
    kind: VibKind,
) -> f64 {
    let mut icc = 0.0;
    let mut ioo = 0.0;
    let mut ico = 0.0;
    for frequency in low..=high {
        let c = calculated.get(&frequency).copied().unwrap_or(0.0);
        let o = observed.get(&frequency).copied().unwrap_or(0.0);
        icc += c * c;
        ioo += o * o;
        ico += c * o;
    }
    let denominator = match kind {
        VibKind::Ir => icc + ioo - ico,
        VibKind::Vcd => icc + ioo - ico.abs(),
    };
    if denominator != 0.0 {
        ico / denominator
    } else {
        0.0
    }
}

pub fn vib_define_ranges(
    calculated: &IntegerSpectrum,
    low: i32,
    high: i32,
    max_shift: i32,
) -> Vec<i32> {
    let mut minima = Vec::new();
    let mut previous_negative = true;
    let mut previous_minimum = 0;
    for frequency in low..high {
        let gradient = calculated
            .get(&(frequency + 1))
            .copied()
            .unwrap_or(0.0)
            .abs()
            - calculated.get(&frequency).copied().unwrap_or(0.0).abs();
        let negative = gradient < 0.0;
        if !negative && previous_negative {
            let minimum = frequency - 1;
            if minimum - previous_minimum > max_shift {
                minima.push(minimum);
                previous_minimum = minimum;
            }
        }
        previous_negative = negative;
    }
    minima
}

fn three_point_fit(
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    x3: f64,
    y3: f64,
) -> Option<(f64, f64, f64)> {
    let denominator = (x1 - x2) * (x1 - x3) * (x2 - x3);
    if denominator == 0.0 {
        return None;
    }
    let a = (x3 * (y2 - y1) + x2 * (y1 - y3) + x1 * (y3 - y2)) / denominator;
    let b = (x3 * x3 * (y1 - y2) + x2 * x2 * (y3 - y1) + x1 * x1 * (y2 - y3)) / denominator;
    let c = (x2 * x3 * (x2 - x3) * y1 + x3 * x1 * (x3 - x1) * y2 + x1 * x2 * (x1 - x2) * y3)
        / denominator;
    Some((a, b, c))
}

pub fn vib_shift_spectrum(
    calculated: &IntegerSpectrum,
    observed: &IntegerSpectrum,
    ranges: &[i32],
    frequency_low: i32,
    frequency_high: i32,
    max_shift: i32,
    kind: VibKind,
) -> IntegerSpectrum {
    let mut shifted_output = IntegerSpectrum::new();
    let (mut x1, mut y1, mut x2, mut y2) = (0.0, 0.0, 0.0, 0.0);
    for pair in ranges.windows(2) {
        let start = pair[0];
        let end = pair[1];
        let mut best_similarity = -1e18;
        let mut best_shift = 0;
        for shift in 0..=max_shift {
            let candidate: IntegerSpectrum = (start..=end)
                .map(|frequency| {
                    (
                        frequency - shift,
                        calculated.get(&frequency).copied().unwrap_or(0.0),
                    )
                })
                .collect();
            let similarity =
                shen_similarity(&candidate, observed, start - shift, end - shift, kind);
            if similarity > best_similarity {
                best_similarity = similarity;
                best_shift = shift;
            }
        }
        for frequency in start..=end {
            let destination = frequency - best_shift;
            let value = calculated.get(&frequency).copied().unwrap_or(0.0);
            shifted_output.insert(destination, value);
            x1 = x2;
            y1 = y2;
            x2 = destination as f64;
            y2 = value;
        }
        let last = end - best_shift;
        if last > 0 {
            if let Some((a, b, c)) = three_point_fit(
                x1,
                y1,
                x2,
                y2,
                end as f64,
                calculated.get(&end).copied().unwrap_or(0.0),
            ) {
                for frequency in last..=end {
                    let x = frequency as f64;
                    shifted_output.insert(frequency, a * x * x + b * x + c);
                }
            } else {
                let value = calculated.get(&end).copied().unwrap_or(0.0);
                for frequency in last..=end {
                    shifted_output.insert(frequency, value);
                }
            }
        }
    }
    for frequency in frequency_low..=frequency_high {
        shifted_output
            .entry(frequency)
            .or_insert_with(|| calculated.get(&frequency).copied().unwrap_or(0.0));
    }
    shifted_output
}

pub fn tilt_baseline(spectrum: &Spectrum, left: f64, right: f64) -> Vec<f64> {
    let (x, y) = crate::math::sorted_xy(&spectrum.x, &spectrum.y);
    let left_value = interp_sorted(&x, &y, &[left])
        .first()
        .copied()
        .unwrap_or(0.0);
    let right_value = interp_sorted(&x, &y, &[right])
        .first()
        .copied()
        .unwrap_or(0.0);
    if left == right {
        return y.iter().map(|value| value - left_value).collect();
    }
    let slope = (left_value - right_value) / (left - right);
    x.iter()
        .zip(y)
        .map(|(frequency, value)| value - slope * (frequency - left) - left_value)
        .collect()
}

#[derive(Clone, Debug, Default)]
pub struct VibMatchResult {
    pub sim_ir_original: f64,
    pub sim_ir: f64,
    pub sim_vcd_original: f64,
    pub sim_vcd: f64,
    pub sim_vcd_opposite_original: f64,
    pub sim_vcd_opposite: f64,
    pub esi: f64,
    pub range_low: i32,
    pub range_high: i32,
    pub assignment: String,
    pub reliability: String,
}

#[derive(Clone, Debug, Default)]
pub struct VibMatchedCurves {
    pub frequency: Vec<f64>,
    pub ir_observed: Vec<f64>,
    pub ir_calculated: Vec<f64>,
    pub vcd_observed: Vec<f64>,
    pub vcd_calculated: Vec<f64>,
    pub vcd_opposite: Vec<f64>,
}

#[allow(clippy::too_many_arguments)]
pub fn match_vib_spectra(
    ir_observed: &Spectrum,
    ir_calculated: &Spectrum,
    vcd_observed: &Spectrum,
    vcd_calculated: &Spectrum,
    range: (i32, i32),
    max_shift: i32,
    vcd_zero: Option<(f64, f64)>,
) -> Result<(VibMatchResult, VibMatchedCurves)> {
    for spectrum in [ir_observed, ir_calculated, vcd_observed, vcd_calculated] {
        spectrum.validate_domain()?;
    }
    let (range_low, range_high) = range;
    if range_low <= 0 || range_high <= range_low || max_shift < 0 || max_shift >= range_low {
        bail!("the VCD match window is invalid");
    }
    let frequency_low = range_low - max_shift;
    let frequency_high = range_high + max_shift;
    let (grid, ir_o) = to_integer_grid(ir_observed, frequency_low as f64, frequency_high as f64);
    let (_, ir_c) = to_integer_grid(ir_calculated, frequency_low as f64, frequency_high as f64);
    let ir_observed_map = as_integer_spectrum(&grid, &normalize_vib(&ir_o, VibKind::Ir));
    let ir_calculated_map = as_integer_spectrum(&grid, &normalize_vib(&ir_c, VibKind::Ir));
    let sim_ir_original = shen_similarity(
        &ir_calculated_map,
        &ir_observed_map,
        range_low,
        range_high,
        VibKind::Ir,
    );
    let ir_ranges = vib_define_ranges(&ir_calculated_map, frequency_low, frequency_high, max_shift);
    let ir_shifted = vib_shift_spectrum(
        &ir_calculated_map,
        &ir_observed_map,
        &ir_ranges,
        frequency_low,
        frequency_high,
        max_shift,
        VibKind::Ir,
    );
    let sim_ir = shen_similarity(
        &ir_shifted,
        &ir_observed_map,
        range_low,
        range_high,
        VibKind::Ir,
    );

    let (vgrid, mut vcd_o) =
        to_integer_grid(vcd_observed, frequency_low as f64, frequency_high as f64);
    if let Some((left, right)) = vcd_zero {
        let tilted = tilt_baseline(
            &Spectrum::new(vgrid.iter().map(|v| *v as f64).collect(), vcd_o),
            left,
            right,
        );
        vcd_o = tilted;
    }
    let (_, vcd_c) = to_integer_grid(vcd_calculated, frequency_low as f64, frequency_high as f64);
    let vcd_observed_map = as_integer_spectrum(&vgrid, &normalize_vib(&vcd_o, VibKind::Vcd));
    let vcd_calculated_map = as_integer_spectrum(&vgrid, &normalize_vib(&vcd_c, VibKind::Vcd));

    let run_vcd = |calculated: &IntegerSpectrum| {
        let original = shen_similarity(
            calculated,
            &vcd_observed_map,
            range_low,
            range_high,
            VibKind::Vcd,
        );
        let ranges = vib_define_ranges(calculated, frequency_low, frequency_high, max_shift);
        let shifted = vib_shift_spectrum(
            calculated,
            &vcd_observed_map,
            &ranges,
            frequency_low,
            frequency_high,
            max_shift,
            VibKind::Vcd,
        );
        let final_similarity = shen_similarity(
            &shifted,
            &vcd_observed_map,
            range_low,
            range_high,
            VibKind::Vcd,
        );
        (original, final_similarity, shifted)
    };
    let (sim_vcd_original, sim_vcd, vcd_shifted) = run_vcd(&vcd_calculated_map);
    let vcd_opposite_map: IntegerSpectrum = vcd_calculated_map
        .iter()
        .map(|(f, value)| (*f, -*value))
        .collect();
    let (sim_vcd_opposite_original, sim_vcd_opposite, vcd_opposite_shifted) =
        run_vcd(&vcd_opposite_map);

    let esi = sim_vcd - sim_vcd_opposite;
    let assignment = if esi > 0.05 {
        "As-calculated configuration favoured"
    } else if esi < -0.05 {
        "Enantiomer of the calculation favoured"
    } else {
        "Inconclusive (|ESI| very small)"
    }
    .to_string();
    let absolute = esi.abs();
    let reliability = if absolute >= 0.6 {
        "high reliability"
    } else if absolute >= 0.3 {
        "moderate reliability"
    } else if absolute >= 0.05 {
        "low reliability — consider other methods"
    } else {
        "not reliable — spectra do not discriminate"
    }
    .to_string();

    let frequencies: Vec<f64> = grid.iter().map(|value| *value as f64).collect();
    let curves = VibMatchedCurves {
        frequency: frequencies,
        ir_observed: grid
            .iter()
            .map(|f| ir_observed_map.get(f).copied().unwrap_or(0.0))
            .collect(),
        ir_calculated: grid
            .iter()
            .map(|f| ir_shifted.get(f).copied().unwrap_or(0.0))
            .collect(),
        vcd_observed: grid
            .iter()
            .map(|f| vcd_observed_map.get(f).copied().unwrap_or(0.0))
            .collect(),
        vcd_calculated: grid
            .iter()
            .map(|f| vcd_shifted.get(f).copied().unwrap_or(0.0))
            .collect(),
        vcd_opposite: grid
            .iter()
            .map(|f| vcd_opposite_shifted.get(f).copied().unwrap_or(0.0))
            .collect(),
    };
    Ok((
        VibMatchResult {
            sim_ir_original,
            sim_ir,
            sim_vcd_original,
            sim_vcd,
            sim_vcd_opposite_original,
            sim_vcd_opposite,
            esi,
            range_low,
            range_high,
            assignment,
            reliability,
        },
        curves,
    ))
}

pub fn parse_vib_experimental(path: impl AsRef<Path>) -> Result<Spectrum> {
    let (x, mut columns) = parse_vib_experimental_multi(path)?;
    Ok(Spectrum::new(x, columns.remove(0)))
}

pub fn parse_vib_experimental_multi(path: impl AsRef<Path>) -> Result<(Vec<f64>, Vec<Vec<f64>>)> {
    let path = path.as_ref();
    if looks_like_gaussian_log(path) {
        bail!(
            "{} is a Gaussian output file, not a measured spectrum; load it with the calculation loader",
            path.display()
        );
    }
    let parsed = crate::electronic::parse_experimental(path)?;
    let mut order: Vec<usize> = (0..parsed.wavelength.len()).collect();
    order.sort_by(|&a, &b| parsed.wavelength[a].total_cmp(&parsed.wavelength[b]));
    let x: Vec<f64> = order.iter().map(|&i| parsed.wavelength[i]).collect();
    let columns: Vec<Vec<f64>> = parsed
        .columns
        .iter()
        .map(|c| order.iter().map(|&i| c[i]).collect())
        .collect();
    Spectrum::new(x.clone(), columns[0].clone()).validate_domain()?;
    Ok((x, columns))
}

pub fn guess_vib_role(x: &[f64], y: &[f64], window: Option<(f64, f64)>) -> VibKind {
    let n = x.len().min(y.len());
    let mut selected = y[..n].to_vec();
    if let Some((lo, hi)) = window {
        let low = lo.min(hi);
        let high = lo.max(hi);
        let in_window: Vec<f64> = x[..n]
            .iter()
            .zip(&y[..n])
            .filter(|(frequency, _)| **frequency >= low && **frequency <= high)
            .map(|(_, value)| *value)
            .collect();
        if in_window.len() > 20 {
            selected = in_window;
        }
    }
    if selected.is_empty() {
        return VibKind::Ir;
    }
    let offset = median(&selected);
    selected.iter_mut().for_each(|value| *value -= offset);
    let positive: f64 = selected.iter().filter(|v| **v > 0.0).sum();
    let negative: f64 = -selected.iter().filter(|v| **v < 0.0).sum::<f64>();
    let total = positive + negative;
    if total <= 0.0 {
        return VibKind::Ir;
    }
    let area_fraction = negative / total;
    let (minimum, maximum) = min_max(&selected).unwrap_or((0.0, 0.0));
    let amplitude_fraction = if maximum > 0.0 {
        minimum.abs() / maximum
    } else {
        f64::INFINITY
    };
    if area_fraction > 0.85 {
        return VibKind::Ir;
    }
    if area_fraction >= 0.20 && amplitude_fraction >= 0.35 {
        VibKind::Vcd
    } else {
        VibKind::Ir
    }
}

fn bipolarity(x: &[f64], y: &[f64], window: Option<(f64, f64)>) -> f64 {
    let n = x.len().min(y.len());
    let mut selected = y[..n].to_vec();
    if let Some((lo, hi)) = window {
        let (low, high) = (lo.min(hi), lo.max(hi));
        let values: Vec<f64> = x[..n]
            .iter()
            .zip(&y[..n])
            .filter(|(frequency, _)| **frequency >= low && **frequency <= high)
            .map(|(_, value)| *value)
            .collect();
        if values.len() > 20 {
            selected = values;
        }
    }
    if selected.is_empty() {
        return 0.0;
    }
    let offset = median(&selected);
    selected.iter_mut().for_each(|value| *value -= offset);
    let positive: f64 = selected.iter().filter(|v| **v > 0.0).sum();
    let negative: f64 = -selected.iter().filter(|v| **v < 0.0).sum::<f64>();
    let total = positive + negative;
    if total <= 0.0 {
        return 0.0;
    }
    let fraction = negative / total;
    1.0 - (fraction - 0.5).abs() * 2.0
}

pub fn guess_vib_roles(
    x: &[f64],
    columns: &[Vec<f64>],
    window: Option<(f64, f64)>,
) -> (Option<usize>, Option<usize>) {
    match columns.len() {
        0 => (None, None),
        1 => match guess_vib_role(x, &columns[0], window) {
            VibKind::Ir => (Some(0), None),
            VibKind::Vcd => (None, Some(0)),
        },
        _ => {
            let scores: Vec<f64> = columns
                .iter()
                .map(|column| bipolarity(x, column, window))
                .collect();
            let vcd = scores
                .iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(Ordering::Equal))
                .map(|(i, _)| i);
            let mut ir = scores
                .iter()
                .enumerate()
                .min_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(Ordering::Equal))
                .map(|(i, _)| i);
            if ir == vcd {
                ir = Some(if vcd != Some(0) { 0 } else { 1 });
            }
            (ir, vcd)
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct VibFitResult {
    pub scale: f64,
    pub gamma: f64,
    pub ir_similarity: f64,
}

#[allow(clippy::too_many_arguments)]
pub fn fit_vib_scale_gamma(
    ir_observed: &Spectrum,
    conformers: &[VibConformer],
    temperature: f64,
    range: (i32, i32),
    max_shift: i32,
    scale_grid: Option<&[f64]>,
    gamma_grid: Option<&[f64]>,
) -> Option<VibFitResult> {
    if ir_observed.validate_domain().is_err()
        || range.0 <= 0
        || range.1 <= range.0
        || max_shift < 0
        || max_shift >= range.0
    {
        return None;
    }
    let default_scales = arange(0.94, 1.0101, 0.005);
    let default_gammas = arange(2.0, 16.01, 1.0);
    let scales = scale_grid.unwrap_or(&default_scales);
    let gammas = gamma_grid.unwrap_or(&default_gammas);
    let sticks = vib_weighted_sticks(conformers, VibKind::Ir, temperature);
    if sticks.centers.is_empty() || ir_observed.is_empty() {
        return None;
    }
    let (low, high) = range;
    let frequency_low = low - max_shift;
    let frequency_high = high + max_shift;
    let (integer_grid, observed_values) =
        to_integer_grid(ir_observed, frequency_low as f64, frequency_high as f64);
    let observed =
        as_integer_spectrum(&integer_grid, &normalize_vib(&observed_values, VibKind::Ir));
    let grid: Vec<f64> = (VIB_GRID_MIN.min(frequency_low)..=VIB_GRID_MAX.max(frequency_high))
        .map(|value| value as f64)
        .collect();
    let mut best = None;
    for &gamma in gammas {
        for &scale in scales {
            if !scale.is_finite() || scale <= 0.0 || !gamma.is_finite() || gamma <= 0.0 {
                continue;
            }
            let curve = broaden_vib(&sticks.centers, &sticks.strengths, &grid, scale, gamma);
            let calculated_spectrum = Spectrum::new(grid.clone(), curve);
            let (_, integer_values) = to_integer_grid(
                &calculated_spectrum,
                frequency_low as f64,
                frequency_high as f64,
            );
            let calculated =
                as_integer_spectrum(&integer_grid, &normalize_vib(&integer_values, VibKind::Ir));
            let ranges = vib_define_ranges(&calculated, frequency_low, frequency_high, max_shift);
            let shifted = vib_shift_spectrum(
                &calculated,
                &observed,
                &ranges,
                frequency_low,
                frequency_high,
                max_shift,
                VibKind::Ir,
            );
            let similarity = shen_similarity(&shifted, &observed, low, high, VibKind::Ir);
            if best
                .as_ref()
                .is_none_or(|current: &VibFitResult| similarity > current.ir_similarity)
            {
                best = Some(VibFitResult {
                    scale,
                    gamma,
                    ir_similarity: similarity,
                });
            }
        }
    }
    best
}

#[derive(Clone, Debug, Default)]
pub struct VibCurves {
    pub frequency: Vec<f64>,
    pub ir: Vec<f64>,
    pub vcd: Vec<f64>,
    pub stick_x: Vec<f64>,
    pub stick_ir: Vec<f64>,
    pub stick_vcd: Vec<f64>,
}

#[derive(Clone, Debug, Default)]
pub struct VibEvaluation {
    pub result: Option<VibMatchResult>,
    pub curves: Option<Arc<VibMatchedCurves>>,
    pub assignment: String,
    pub reliability: String,
}

#[derive(Clone, Debug)]
pub struct VibDataset {
    pub(crate) state: crate::state::DatasetState,
    pub name: String,
    pub conformers: Vec<VibConformer>,
    pub experimental_ir: Option<Spectrum>,
    pub experimental_vcd: Option<Spectrum>,
    pub scale: f64,
    pub gamma: f64,
    pub range_low: i32,
    pub range_high: i32,
    pub max_shift: i32,
    pub view_low: i32,
    pub view_high: i32,
    pub npoints: usize,
    pub dpi: u32,
    pub temperature: f64,
    pub vcd_zero: Option<(f64, f64)>,
    pub show_enantiomer: bool,
    pub show_sticks: bool,
    pub show_export_legend: bool,
    pub fitted: bool,
    curve_cache: Option<Arc<VibCurves>>,
    evaluation_cache: Option<Arc<VibEvaluation>>,
}

impl Default for VibDataset {
    fn default() -> Self {
        Self::new("Compound 1")
    }
}

impl VibDataset {
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            state: Default::default(),
            name: name.into(),
            conformers: Vec::new(),
            experimental_ir: None,
            experimental_vcd: None,
            scale: VIB_SCALE_DEFAULT,
            gamma: VIB_GAMMA_DEFAULT,
            range_low: VIB_RANGE_DEFAULT.0,
            range_high: VIB_RANGE_DEFAULT.1,
            max_shift: VIB_MAX_SHIFT_DEFAULT,
            view_low: VIB_RANGE_DEFAULT.0,
            view_high: VIB_RANGE_DEFAULT.1,
            npoints: 1400,
            dpi: 400,
            temperature: T_DEFAULT,
            vcd_zero: None,
            show_enantiomer: false,
            show_sticks: false,
            show_export_legend: true,
            fitted: false,
            curve_cache: None,
            evaluation_cache: None,
        }
    }

    pub fn has_calculation(&self) -> bool {
        self.conformers
            .iter()
            .any(|c| c.include && c.validate().is_ok())
    }

    pub fn has_experimental_ir(&self) -> bool {
        self.experimental_ir.as_ref().is_some_and(|s| !s.is_empty())
    }

    pub fn has_experimental_vcd(&self) -> bool {
        self.experimental_vcd
            .as_ref()
            .is_some_and(|s| !s.is_empty())
    }

    pub fn invalidate(&mut self) {
        self.curve_cache = None;
        self.evaluation_cache = None;
    }

    pub fn invalidate_fit(&mut self) {
        self.fitted = false;
        self.state.changed();
    }

    pub fn invalidate_evaluation(&mut self) {
        self.evaluation_cache = None;
    }

    pub fn curves(&mut self) -> Option<Arc<VibCurves>> {
        let low = VIB_GRID_MIN
            .min(self.range_low - self.max_shift)
            .min(self.view_low.min(self.view_high));
        let high = VIB_GRID_MAX
            .max(self.range_high + self.max_shift)
            .max(self.view_low.max(self.view_high));
        if let Some(cache) = &self.curve_cache
            && cache.frequency.first() == Some(&(low as f64))
            && cache.frequency.last() == Some(&(high as f64))
        {
            return Some(cache.clone());
        }
        self.evaluation_cache = None;
        let ir = vib_weighted_sticks(&self.conformers, VibKind::Ir, self.temperature);
        let vcd = vib_weighted_sticks(&self.conformers, VibKind::Vcd, self.temperature);
        for conformer in &mut self.conformers {
            conformer.weight = 0.0;
        }
        if ir.centers.is_empty() {
            return None;
        }
        // Preserve the original sampling density when extending the domain.
        let points = (((high - low) as f64 / (VIB_GRID_MAX - VIB_GRID_MIN) as f64)
            * (self.npoints.max(200) - 1) as f64)
            .ceil() as usize
            + 1;
        let grid = linspace(low as f64, high as f64, points);
        for (&index, &population) in ir.used_indices.iter().zip(&ir.populations) {
            if let Some(conformer) = self.conformers.get_mut(index) {
                conformer.weight = population;
            }
        }
        let curves = Arc::new(VibCurves {
            frequency: grid.clone(),
            ir: broaden_vib(&ir.centers, &ir.strengths, &grid, self.scale, self.gamma),
            vcd: broaden_vib(&vcd.centers, &vcd.strengths, &grid, self.scale, self.gamma),
            stick_x: ir.centers.iter().map(|value| value * self.scale).collect(),
            stick_ir: ir.strengths,
            stick_vcd: vcd.strengths,
        });
        self.curve_cache = Some(curves.clone());
        Some(curves)
    }

    pub fn evaluate(&mut self) -> Arc<VibEvaluation> {
        // A changed view can extend the numerical domain and expire evaluation.
        let curves = self.curves();
        if let Some(cache) = &self.evaluation_cache {
            return cache.clone();
        }
        let mut evaluation = VibEvaluation::default();
        match (curves, &self.experimental_ir, &self.experimental_vcd) {
            (Some(curves), Some(ir), Some(vcd)) => {
                let calculated_ir = Spectrum::new(curves.frequency.clone(), curves.ir.clone());
                let calculated_vcd = Spectrum::new(curves.frequency.clone(), curves.vcd.clone());
                match match_vib_spectra(
                    ir,
                    &calculated_ir,
                    vcd,
                    &calculated_vcd,
                    (self.range_low, self.range_high),
                    self.max_shift,
                    self.vcd_zero,
                ) {
                    Ok((result, matched)) => {
                        evaluation.assignment = result.assignment.clone();
                        evaluation.reliability = result.reliability.clone();
                        evaluation.result = Some(result);
                        evaluation.curves = Some(Arc::new(matched));
                    }
                    Err(error) => {
                        evaluation.assignment =
                            "Match failed — check the window and data range".into();
                        evaluation.reliability = error.to_string();
                    }
                }
            }
            (Some(_), Some(_), None) => {
                evaluation.assignment = "IR loaded (no VCD yet)".into();
                evaluation.reliability = "Load measured VCD for an assignment.".into();
            }
            _ => {}
        }
        let evaluation = Arc::new(evaluation);
        self.evaluation_cache = Some(evaluation.clone());
        evaluation
    }

    pub fn view_span(&self) -> (f64, f64) {
        let low = self.view_low.min(self.view_high) as f64;
        let high = self.view_low.max(self.view_high) as f64;
        if high > low {
            (low, high)
        } else {
            (self.range_low as f64, self.range_high as f64)
        }
    }

    pub fn window_limits(
        spectrum: Option<&Spectrum>,
        low: f64,
        high: f64,
        padding: f64,
        symmetric: bool,
    ) -> Option<(f64, f64)> {
        let spectrum = spectrum?;
        let n = spectrum.len();
        if n == 0 {
            return None;
        }
        let mut selected: Vec<f64> = spectrum.x[..n]
            .iter()
            .zip(&spectrum.y[..n])
            .filter(|(x, _)| **x >= low && **x <= high)
            .map(|(_, y)| *y)
            .collect();
        if selected.is_empty() {
            selected = spectrum.y[..n].to_vec();
        }
        let (minimum, maximum) = min_max(&selected)?;
        if symmetric {
            let amplitude = minimum.abs().max(maximum.abs()).max(1.0);
            Some((-amplitude * (1.0 + padding), amplitude * (1.0 + padding)))
        } else {
            let span = if maximum > minimum {
                maximum - minimum
            } else {
                maximum.abs().max(1.0)
            };
            Some((minimum - span * padding, maximum + span * padding))
        }
    }

    pub fn fit_window_to_data(&mut self) {
        let previous = (self.range_low, self.range_high);
        let mut lows = vec![VIB_RANGE_DEFAULT.0 as f64];
        let mut highs = vec![VIB_RANGE_DEFAULT.1 as f64];
        for spectrum in [&self.experimental_ir, &self.experimental_vcd]
            .into_iter()
            .flatten()
        {
            if let Some((lo, hi)) = min_max(&spectrum.x) {
                lows.push(lo + self.max_shift as f64);
                highs.push(hi - self.max_shift as f64);
            }
        }
        let low = lows.into_iter().fold(f64::NEG_INFINITY, f64::max);
        let high = highs.into_iter().fold(f64::INFINITY, f64::min);
        if high - low >= 50.0 {
            self.range_low = low.round() as i32;
            self.range_high = high.round() as i32;
        }
        self.view_low = self.range_low;
        self.view_high = self.range_high;
        if previous != (self.range_low, self.range_high) {
            self.invalidate_fit();
        }
        self.invalidate_evaluation();
    }

    pub fn view_to_data(&mut self) {
        let ranges: Vec<(f64, f64)> = [&self.experimental_ir, &self.experimental_vcd]
            .into_iter()
            .flatten()
            .filter_map(|spectrum| min_max(&spectrum.x))
            .collect();
        if !ranges.is_empty() {
            self.view_low = ranges
                .iter()
                .map(|row| row.0)
                .fold(f64::INFINITY, f64::min)
                .round() as i32;
            self.view_high = ranges
                .iter()
                .map(|row| row.1)
                .fold(f64::NEG_INFINITY, f64::max)
                .round() as i32;
        }
    }

    pub fn reset_fit(&mut self) {
        self.scale = VIB_SCALE_DEFAULT;
        self.gamma = VIB_GAMMA_DEFAULT;
        self.range_low = VIB_RANGE_DEFAULT.0;
        self.range_high = VIB_RANGE_DEFAULT.1;
        self.max_shift = VIB_MAX_SHIFT_DEFAULT;
        self.invalidate_fit();
        self.invalidate();
    }
}

#[derive(Clone, Debug)]
pub struct VibAutoFitInput {
    pub ir: Spectrum,
    pub conformers: Vec<VibConformer>,
    pub temperature: f64,
    pub range: (i32, i32),
    pub max_shift: i32,
}

pub fn run_vib_auto_fit(input: VibAutoFitInput) -> Result<VibFitResult> {
    fit_vib_scale_gamma(
        &input.ir,
        &input.conformers,
        input.temperature,
        input.range,
        input.max_shift,
        None,
        None,
    )
    .ok_or_else(|| anyhow!("nothing could be fitted"))
}
