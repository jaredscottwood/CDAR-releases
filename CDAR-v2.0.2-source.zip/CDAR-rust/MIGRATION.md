# Migration map

This release is CDAR 2.0.2, based on the finalized 1.1.1 source.

Version 2.0.0 replaces the former VCD-only methyl-exclusion rule with the
supplied logdedup.py all-atom, symmetry-aware, energy/geometry/frequency
protocol and applies it to ECD as well. Gaussian evidence comes from each
mode's Gaussian LOG and passes strict optimization and spectral validation. All five
thresholds are unchanged from the supplied script. See README.md and
validation/README.md for the full protocol and edge-case policy.

The uploaded source contains 12,715 lines and roughly 1 MB of text. Much of the
size is embedded image data; the functional Python implementation is about five
thousand lines. The Rust edition preserves the behavior rather than performing
a line-for-line transliteration.

## Functional correspondence

| Python area | Rust location | Result |
|---|---|---|
| `Conformer`, Gaussian parsing and energy selection | `electronic.rs` | Validated optimization and TD calculations with both rotational-strength gauges |
| `boltzmann_weights`, `weighted_transitions` | `electronic.rs` | Existing constants; Gibbs-only weighting of qualified conformers |
| `broaden` | `electronic.rs` | Parallel Gaussian/Lorentzian implementation |
| baseline, noise, Savitzky–Golay feature analysis | `electronic.rs`, `math.rs` | Native robust fit and local-extrema pipeline |
| `fit_2d`, UV/ECD staged Auto-Fit | `electronic.rs` | Coarse/fine search and UV-tolerant ESI shift refinement |
| SpecDis same-sign similarity and ESI | `electronic.rs` | Same component metrics plus verdict diagnostics |
| JASCO/delimited measurement input and role guessing | `electronic.rs`, `app.rs` | Automatic roles plus modal column mapping |
| `VibConformer`, Gaussian frequency parser | `vibrational.rs` | Validated optimization, Gibbs energy, geometry, connectivity, complete modes and strengths, and normal termination |
| `logdedup.py` | `gaussian.rs`, `dedup.rs`, `electronic.rs`, `vibrational.rs`, `app.rs` | Shared automatic pre-spectrum de-duplication using Gibbs energy, graph-valid all-atom symmetry, proper rotations, max displacement and sorted-frequency gates |
| Lorentzian VCD broadening and weighted sticks | `vibrational.rs` | Parallel native implementation |
| compare.pl normalization, ranges, regional shifts, Shen similarity | `vibrational.rs` | Direct algorithmic port |
| IR-driven scale/γ Auto-Fit | `vibrational.rs` | Background grid search |
| Tkinter chooser and two workspaces | `app.rs` | Native egui UI with persistent mode state |
| TkDnD | `app.rs` | Native egui file drag-and-drop |
| Matplotlib plots | `app.rs` | Interactive egui plots with zoom/pan and inverted VCD axis |
| Matplotlib PNG/PDF/SVG export | `export.rs` | One SVG figure model, vector PDF conversion, DPI-aware PNG rasterization |
| Embedded base64 icon payload | `assets.rs`, `build.rs`, `main.rs` | Supplied high-resolution CDAR/ECD/VCD artwork and a multi-resolution Windows executable icon |
| About and methodology windows | `help.rs`, `app.rs` | Scrollable native dialogs |

## Deliberate Rust-native changes

- Fitting work is transferred through typed channels instead of mutating GUI
  state from worker threads.
- Cached curves are shared with `Arc`, avoiding repeated copies between plots,
  results, and exports.
- Both workspaces retain their state when switching modes.
- The VCD curve-resolution control now drives the working grid. Its default is
  1,400 points over 800–2,200 cm⁻¹, matching the electronic-mode default count.
  The grid extends to cover larger requested windows at the same sampling density.
- File names are sanitized without depending on operating-system shell rules.
- Artwork is compiled into the binary. The method chooser, title-bar icon, and
  Windows taskbar icon follow the active CDAR/ECD/VCD context without requiring
  loose runtime assets.
- A bundled DejaVu Sans fallback supplies scientific Unicode glyphs such as the
  superscript minus in cm⁻¹ consistently across Windows installations.
- Both workspaces use restrained method-colored chrome around white spectral
  plots, and scroll/wrap long results instead of expanding beyond the viewport.
- Plot hover positions are reported only in a shared footer, with the selected
  physical y unit appended for ECD and no y-unit suffix for UV, IR, or VCD. The
  chooser cards provide a visible lift/highlight interaction.
- A half-sized frameless splash viewport shows only `logo.png` at the monitor
  center for 1.5 seconds. The decorated workspace is created independently, maximized
  only after its native window exists, geometry-checked, retried once when
  necessary, and otherwise left as a centered normal window.
- Plot gridlines and the zero baseline can be toggled independently. Gridlines
  default off, the baseline defaults on, and an explicit re-center action resets
  both plots to their current data and configured spectral window.
- The chooser cards are fully clickable without redundant action buttons, and
  their text and height respond to the available width. The main plot and
  control cards use identical fixed outer heights, while the taller rounded
  status footer has symmetric separator spacing and the same bottom inset as
  the workspace side insets. The two live spectra are each two points taller to
  consume the small lower interior surplus without changing the card height.
- ECD data labels default to millidegrees, with molar ellipticity available as
  an explicit per-compound input/display-unit choice. No unsupported numerical
  conversion is inferred without concentration and path length.
- Conformer rows reserve stable columns for energy, population, and state/mode
  counts while truncating exceptionally long source names. The action rows and
  VCD fit controls retain visible spacing at narrow panel widths.
- Live plots and exported figures share peak-arrow and dashed-enantiomer styles.
  Their unboxed line-swatch legends select the least occupied corner, export
  legends can be disabled per compound, hovering a live legend row highlights
  its spectrum, and VCD uses the same blue enantiomer color in both contexts.
- ECD and VCD populations use Gibbs free energy exclusively. Both modes apply
  the shared logdedup.py protocol before populations or spectra are produced.
  Every atom participates; proper rotations and graph-valid relabelings are
  allowed, reflections are not. Only established representatives can absorb a
  duplicate. Incomplete calculations and structures with non-positive harmonic
  frequencies are rejected with an explanation. The parsers require explicit
  optimization completion, normal termination, reported connectivity, Gibbs
  energy, and complete spectral arrays. Calculations in successive jobs are
  checked separately so a later unfinished job cannot reuse earlier success.
- Results use explicit per-value interpretation colors and a centered metric
  table at the bottom of Fit. The former Results tab was removed and the three
  remaining tabs are evenly distributed. The Methodology dialog gives exact
  definitions for sign agreement, shape where signed, fit-quality ceiling, and
  discrimination.
- ECD experimental imports initialize and reset the plot to their exact
  measured wavelength span. VCD keeps its 1000–1600 cm⁻¹ default until the user
  explicitly fits a window to data. Both cards enforce a balanced right gutter;
  UV/IR place zero at the bottom; and live/exported axes use outward rounded
  spectroscopy-friendly ticks, with tick values and axis titles spaced clear of
  those ticks and scientific notation for small VCD values.
- ECD Auto-Fit determines bandwidth and wavelength registration, then leaves
  intensity display scaling available for user fine tuning while inspecting the
  overlays and reported diagnostics. Hovered legend text becomes bold with its
  highlighted spectrum. Sub-step floating-point normalization performed by a
  slider no longer clears the fitted-state label on the following frame.
- Active fitting shows a text-free spinner inline with Auto-Fit and Reset.
  Suggested figure names use `_ECD` or `_VCD` instead of `_CDAR`.
- Matched VCD-workspace legends qualify the region-shifted calculated IR and
  VCD curves as `Calculated (fitted)`, and qualify the independently shifted
  enantiomer in the same way. Electronic Auto-Fit now follows the same stateful
  convention for calculated UV/ECD and the ECD enantiomer. Resetting or changing
  fit inputs restores plain labels. UV and ECD display scales expose six decimal
  places for finer manual adjustment, and the electronic results metric is
  consistently named `ESI`.
- Refined CDAR/ECD/VCD artwork replaces the earlier embedded images, with
  matching six-resolution Windows ICO resources. The separate square
  `logo.png` retains the 280-pixel, 1.5-second splash presentation and fills an
  opaque frameless viewport whose native window supplies the rounded corners.
  In-app texture minification uses linear
  mipmaps for cleaner rendering on 1080p displays.
- Vibrational `(fitted)` legend qualifiers are now a strict indicator that
  Auto-Fit completed successfully. Loading measured data can create matched
  previews, but those previews retain plain calculated/enantiomer labels until
  the fit flag is set; resetting or changing fit inputs removes the qualifier.

## Verification record

The complete project was checked with Rust 1.97.1. All of these commands pass:

```bash
cargo fmt --check
cargo test
cargo clippy --all-targets -- -D warnings
cargo build --release
cargo check --target x86_64-pc-windows-msvc --all-targets
```

The deterministic regressions cover embedded high-resolution artwork and
splash assets, UI fitted-state normalization,
viewport containment, the numerical core, representative Gaussian electronic
and frequency/connectivity outputs, strict rejection of invalid calculations,
all-atom symmetry-aware de-duplication, delimited experimental data, and generation of
SVG, vector PDF, and PNG figures. The optimized Linux
binary also links successfully, and the Windows-specific source paths compile
for the MSVC target. As with any scientific migration, these checks
complement rather than replace acceptance testing with the laboratory's own
production files.

For scientific acceptance, compare representative production inputs in both
applications and confirm the conformer weights, fitted parameters, channel
similarities, ESI, assignment, and exported curves within the desired floating-
point tolerance.
