mod common;
use cdar::electronic::{Conformer, Gauge, dedupe_electronic, parse_qm, weighted_transitions};
use cdar::import::{ImportReport, import_conformers};
use cdar::vibrational::{
    VibConformer, VibKind, dedupe_vib, parse_gaussian_vib, vib_weighted_sticks,
};
use std::fs;
use std::path::PathBuf;

struct Fixture(PathBuf);
impl Fixture {
    fn new(name: &str) -> Self {
        let dir = std::env::temp_dir().join(format!("cdar-import-{}-{name}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        Self(dir)
    }
    fn file(&self, name: &str, text: &str) -> PathBuf {
        let path = self.0.join(name);
        fs::create_dir_all(path.parent().unwrap()).unwrap();
        fs::write(&path, text).unwrap();
        path
    }
}
impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn electronic(conformers: &mut Vec<Conformer>, paths: Vec<PathBuf>) -> ImportReport {
    import_conformers(
        conformers,
        paths,
        |p| parse_qm(p),
        |c| &c.path,
        dedupe_electronic,
    )
}
fn vibrational(conformers: &mut Vec<VibConformer>, paths: Vec<PathBuf>) -> ImportReport {
    import_conformers(
        conformers,
        paths,
        |p| parse_gaussian_vib(p),
        |c| &c.path,
        |c| {
            let result = dedupe_vib(c);
            *c = result.conformers;
            result.report
        },
    )
}
fn check_partition(r: &ImportReport) {
    assert_eq!(
        r.requested,
        r.new_retained()
            + r.incoming_duplicates()
            + r.incoming_rejected()
            + r.already_loaded.len()
            + r.repeated_selection.len()
    );
    assert_eq!(
        r.dedup.survivors.len(),
        r.previous - r.previous_removed() + r.new_retained()
    );
}
#[test]
fn importing_47_files_twice_keeps_counts_and_populations_consistent_in_both_modes() {
    let fixture = Fixture::new("47-files");
    let paths: Vec<_> = (0..47)
        .map(|i| {
            let mut text = common::electronic_log();
            let index = if i < 34 { i } else { i - 34 };
            text = text.replace(
                "-501.450000",
                &format!("{:.6}", -501.45 + index as f64 * 0.01),
            );
            if i >= 37 {
                text = text.replace("1100.0000", "-20.0000");
            }
            fixture.file(&format!("conformer-{i}.log"), &text)
        })
        .collect();
    let mut ecd = Vec::new();
    let mut vcd = Vec::new();
    for r in [
        electronic(&mut ecd, paths.clone()),
        vibrational(&mut vcd, paths.clone()),
    ] {
        check_partition(&r);
        assert_eq!(r.requested, 47);
        assert_eq!(r.previous, 0);
        assert_eq!(r.new_retained(), 34);
        assert_eq!(r.incoming_duplicates(), 3);
        assert_eq!(r.incoming_rejected(), 10);
        let report = r.text();
        assert!(report.contains(
            "47 files selected: 34 new conformers kept, 3 duplicates removed, 10 rejected"
        ));
        assert!(report.contains("Removed duplicate (this import):"));
        assert!(report.contains("Kept representative:"));
        assert!(!report.contains('→'));
        // The final failure is available too; details are not limited to the first two.
        assert!(report.contains("conformer-46.log"));
    }
    let ew = weighted_transitions(&ecd, Gauge::Velocity, 298.15).weights;
    let vw = vib_weighted_sticks(&vcd, VibKind::Vcd, 298.15).populations;
    assert_eq!(ew, vw);
    for r in [
        electronic(&mut ecd, paths.clone()),
        vibrational(&mut vcd, paths),
    ] {
        check_partition(&r);
        assert_eq!(r.previous, 34);
        assert_eq!(r.already_loaded.len(), 34);
        assert_eq!(r.new_retained(), 0);
        assert_eq!(r.incoming_duplicates(), 3);
        assert_eq!(r.incoming_rejected(), 10);
        assert_eq!(r.dedup.survivors.len(), 34);
        assert!(!r.changed());
        for d in &r.dedup.duplicates {
            assert_ne!(r.paths[d.duplicate], r.paths[d.representative]);
        }
    }
    assert_eq!(
        weighted_transitions(&ecd, Gauge::Velocity, 298.15).weights,
        ew
    );
    assert_eq!(
        vib_weighted_sticks(&vcd, VibKind::Vcd, 298.15).populations,
        vw
    );
}
#[test]
fn repeated_file_selections_are_not_counted_as_duplicate_conformers() {
    let fixture = Fixture::new("repeat");
    let path = fixture.file("single.log", &common::electronic_log());
    let mut ecd = Vec::new();
    let mut vcd = Vec::new();
    for r in [
        electronic(&mut ecd, vec![path.clone(), path.clone()]),
        vibrational(&mut vcd, vec![path.clone(), path.clone()]),
    ] {
        check_partition(&r);
        assert_eq!(r.new_retained(), 1);
        assert_eq!(r.repeated_selection.len(), 1);
        assert!(r.dedup.duplicates.is_empty());
    }
    for r in [
        electronic(&mut ecd, vec![path.clone()]),
        vibrational(&mut vcd, vec![path]),
    ] {
        check_partition(&r);
        assert_eq!(r.already_loaded.len(), 1);
        assert_eq!(r.parsed, 0);
        assert!(r.dedup.duplicates.is_empty());
        assert!(!r.changed());
    }
}
#[test]
fn same_named_files_in_different_directories_are_distinct_and_lower_gibbs_wins() {
    let fixture = Fixture::new("same-names");
    let old = fixture.file("old/conformer.log", &common::electronic_log());
    let lower = fixture.file(
        "new/conformer.log",
        &common::electronic_log().replace("-501.450000", "-501.450100"),
    );
    let mut ecd = Vec::new();
    let mut vcd = Vec::new();
    electronic(&mut ecd, vec![old.clone()]);
    vibrational(&mut vcd, vec![old.clone()]);
    for r in [
        electronic(&mut ecd, vec![lower.clone()]),
        vibrational(&mut vcd, vec![lower.clone()]),
    ] {
        check_partition(&r);
        assert!(r.changed());
        assert_eq!(r.new_retained(), 1);
        assert_eq!(r.previous_removed(), 1);
        assert_eq!(r.incoming_duplicates(), 0);
        let report = r.text();
        assert!(report.contains(&format!(
            "Removed duplicate (previously loaded): {}",
            old.display()
        )));
        assert!(report.contains(&format!("Kept representative: {}", lower.display())));
        assert!(report.contains("|ΔG| = 0.062751 kcal/mol"));
    }
    assert_eq!(ecd[0].path, lower);
    assert_eq!(vcd[0].path, lower);
}
