mod common;

use cdar::electronic::{
    Conformer, ElectronicAutoFitInput, ElectronicDataset, FitObjective, Profile, Spectrum,
    parse_experimental_text, run_electronic_auto_fit,
};
use cdar::vibrational::{VibDataset, broaden_vib, fit_vib_scale_gamma};

fn electronic() -> ElectronicDataset {
    let mut dataset = ElectronicDataset::default();
    dataset.conformers.push(Conformer {
        opt_freq: Some(common::evidence()),
        ev: vec![3.1],
        fosc: vec![0.12],
        rvel: Some(vec![4.]),
        rlen: Some(vec![3.]),
        include: true,
        ..Default::default()
    });
    dataset
}

#[test]
fn invalid_thermodynamics_cannot_invent_equal_populations() {
    use cdar::electronic::boltzmann_weights;
    for temperature in [0.0, -1.0, f64::NAN, f64::INFINITY] {
        assert!(boltzmann_weights(&[-500., -499.], temperature).0.is_empty());
    }
    assert!(boltzmann_weights(&[-500., f64::NAN], 298.15).0.is_empty());
}

#[test]
fn both_measurement_loaders_preserve_columns_and_reject_bad_rows() {
    use cdar::vibrational::{parse_vib_experimental, parse_vib_experimental_multi};
    let path = std::env::temp_dir().join(format!(
        "cdar-audit-measurements-{}.csv",
        std::process::id()
    ));
    for delimiter in [",", "\t", ";", " "] {
        let text = format!("# data\n1200{delimiter}2{delimiter}-3\n1100{delimiter}4{delimiter}5\n");
        std::fs::write(&path, &text).unwrap();
        let (x, columns) = parse_vib_experimental_multi(&path).unwrap();
        assert_eq!(x, vec![1100., 1200.]);
        assert_eq!(columns, vec![vec![4., 2.], vec![5., -3.]]);
        assert_eq!(parse_vib_experimental(&path).unwrap().y, vec![4., 2.]);
        assert_eq!(parse_experimental_text(&text).unwrap().ncolumns, 3);
    }
    for text in [
        "1200,2,-3\n1100,,5",
        "1200,2,-3\n1100,NaN,5",
        "1200,2,-3\n1100,4",
    ] {
        std::fs::write(&path, text).unwrap();
        assert!(parse_vib_experimental(&path).is_err());
        assert!(parse_vib_experimental_multi(&path).is_err());
    }
    std::fs::remove_file(&path).unwrap();
    let jasco = "TITLE Example\nJASCO\nXYDATA\n1200 2 -3\n1100 4 5\nEND";
    assert_eq!(
        parse_experimental_text(jasco).unwrap().columns[1],
        vec![-3., 5.]
    );
}

#[test]
fn ecd_rejects_td_geometry_from_a_different_conformer() {
    let path =
        std::env::temp_dir().join(format!("cdar-audit-td-geometry-{}.log", std::process::id()));
    let altered_td = common::td_log().replace("0.950000", "1.450000");
    std::fs::write(&path, common::optimization_log() + &altered_td).unwrap();
    let error = cdar::electronic::parse_qm(&path).unwrap_err().to_string();
    assert!(error.contains("geometry does not match"), "{error}");
    // Translation of the same geometry still qualifies.
    let translated = common::td_log()
        .replace(
            "0 0.000000 0.000000 0.000000",
            "0 2.000000 0.000000 0.000000",
        )
        .replace(
            "0 0.950000 0.000000 0.000000",
            "0 2.950000 0.000000 0.000000",
        )
        .replace(
            "0 -0.250000 0.900000 0.000000",
            "0 1.750000 0.900000 0.000000",
        );
    std::fs::write(&path, common::optimization_log() + &translated).unwrap();
    assert!(cdar::electronic::parse_qm(&path).is_ok());
    std::fs::remove_file(&path).unwrap();
}

#[test]
fn peak_shape_fit_recovers_synthetic_bands_for_both_profiles() {
    use cdar::electronic::{broaden, fit_uv};
    use cdar::math::{ev_to_nm, linspace};
    let ev = linspace(2.0, 6.0, 1000);
    let x: Vec<f64> = ev.iter().map(|&e| ev_to_nm(e) + 4.).collect();
    for profile in [Profile::Gaussian, Profile::Lorentzian] {
        let y = broaden(&[3.1, 4.5], &[1., 0.8], 0.2, &ev, profile, false);
        let fit = fit_uv(
            &x,
            &y,
            &[3.1, 4.5],
            &[1., 0.8],
            &[0.1, 0.2, 0.3],
            &[0., 4., 8.],
            profile,
            FitObjective::PeakShape,
            1.,
        )
        .unwrap();
        assert_eq!(fit.sigma, 0.2);
        assert_eq!(fit.shift, 4.0);
        assert!(fit.similarity > 0.999);
    }
}

#[test]
fn disabling_all_conformers_clears_displayed_populations_in_both_modes() {
    let mut e = electronic();
    e.curves().unwrap();
    assert_eq!(e.conformers[0].weight, 1.0);
    e.conformers[0].include = false;
    e.invalidate();
    assert!(e.curves().is_none());
    assert_eq!(e.conformers[0].weight, 0.0);
    e.conformers[0].include = true;
    e.invalidate();
    e.curves().unwrap();
    assert_eq!(e.conformers[0].weight, 1.0);

    let mut v = VibDataset::default();
    v.conformers.push(common::valid_vib());
    v.curves().unwrap();
    assert_eq!(v.conformers[0].weight, 1.0);
    v.conformers[0].include = false;
    v.invalidate();
    assert!(v.curves().is_none());
    assert_eq!(v.conformers[0].weight, 0.0);
}

#[test]
fn measurements_cannot_silently_drop_or_shift_missing_columns() {
    for text in [
        "x,uv,ecd\n200,1,2\n210,,3\n220,4,5\n",
        "200,1,2\n210,3\n220,4,5\n",
        "200,1,2\n210,bad,3\n220,4,5\n",
        "200,1,2\n210,NaN,3\n220,4,5\n",
        "200,1,2\n210,inf,3\n220,4,5\n",
    ] {
        assert!(parse_experimental_text(text).is_err(), "accepted {text}");
    }
}

#[test]
fn electronic_auto_fit_does_not_report_success_without_a_fit() {
    let input = ElectronicAutoFitInput {
        transitions: vec![3.1],
        oscillator_strengths: vec![0.12],
        rotatory_strengths: vec![4.0],
        uv: Some(Spectrum::new(vec![300.0], vec![1.0])),
        ecd: None,
        profile: Profile::Gaussian,
        objective: FitObjective::Cosine,
        sensitivity: 1.0,
    };
    assert!(run_electronic_auto_fit(input).is_err());
}

#[test]
fn vibrational_fit_rejects_reversed_windows() {
    let result = fit_vib_scale_gamma(
        &Spectrum::new(vec![1000.0, 1600.0], vec![0.0, 1.0]),
        &[common::valid_vib()],
        298.15,
        (1600, 1000),
        20,
        Some(&[0.98]),
        Some(&[6.0]),
    );
    assert!(result.is_none());
}

#[test]
fn measured_ir_with_zero_or_negative_endpoints_loads_and_fits_without_dropping_rows() {
    use cdar::vibrational::{
        match_vib_spectra, parse_vib_experimental, parse_vib_experimental_multi,
    };
    let path = std::env::temp_dir().join(format!("cdar-ir-endpoint-{}.csv", std::process::id()));
    for low in [0, -10] {
        let x: Vec<f64> = (low..=1700).step_by(2).map(f64::from).collect();
        let ir = broaden_vib(&[1100.], &[1.], &x, 1., 6.);
        let mut csv = String::from("Wavenumber,IR,VCD\n");
        for (&frequency, &intensity) in x.iter().zip(&ir).rev() {
            csv.push_str(&format!("{frequency},{intensity},{}\n", intensity * 0.2));
        }
        std::fs::write(&path, csv).unwrap();
        let measured_ir = parse_vib_experimental(&path).unwrap();
        let (parsed_x, columns) = parse_vib_experimental_multi(&path).unwrap();
        assert_eq!(measured_ir.x, x);
        assert_eq!(measured_ir.y, ir);
        assert_eq!(parsed_x, x);
        assert_eq!(columns[0], ir);
        assert_eq!(columns[1].len(), x.len());

        let fit = fit_vib_scale_gamma(
            &measured_ir,
            &[common::valid_vib()],
            298.15,
            (1000, 1600),
            0,
            Some(&[0.98, 1.0]),
            Some(&[6.0]),
        )
        .expect("measured IR endpoints must not block Auto-Fit");
        assert_eq!(fit.scale, 1.0);
        assert!(fit.ir_similarity > 0.999);

        let calc_x: Vec<f64> = (980..=1620).map(f64::from).collect();
        let calc_ir = Spectrum::new(
            calc_x.clone(),
            broaden_vib(&[1100.], &[1.], &calc_x, 1., 6.),
        );
        let measured_vcd = Spectrum::new(parsed_x, columns[1].clone());
        let calc_vcd = Spectrum::new(
            calc_x.clone(),
            broaden_vib(&[1100.], &[0.2], &calc_x, 1., 6.),
        );
        let (matched, curves) = match_vib_spectra(
            &measured_ir,
            &calc_ir,
            &measured_vcd,
            &calc_vcd,
            (1000, 1600),
            0,
            None,
        )
        .unwrap();
        assert!(matched.sim_ir > 0.999);
        assert!(matched.sim_vcd > 0.999);
        assert!(
            curves
                .ir_observed
                .iter()
                .chain(&curves.vcd_observed)
                .all(|v| v.is_finite())
        );

        let electronic = ElectronicAutoFitInput {
            transitions: vec![3.1],
            oscillator_strengths: vec![0.12],
            rotatory_strengths: vec![4.0],
            uv: Some(measured_ir),
            ecd: None,
            profile: Profile::Gaussian,
            objective: FitObjective::Cosine,
            sensitivity: 1.0,
        };
        assert!(
            run_electronic_auto_fit(electronic)
                .unwrap_err()
                .to_string()
                .contains("positive wavelengths")
        );
    }
    std::fs::remove_file(path).unwrap();
}

#[test]
fn measured_spectra_still_reject_nonfinite_unpaired_or_constant_samples() {
    for bad in [
        Spectrum::new(vec![0., f64::NAN], vec![1., 2.]),
        Spectrum::new(vec![0., 1000.], vec![1., f64::INFINITY]),
        Spectrum::new(vec![0., 1000.], vec![1.]),
        Spectrum::new(vec![0., 0.], vec![1., 2.]),
    ] {
        assert!(bad.validate_domain().is_err());
        assert!(
            fit_vib_scale_gamma(
                &bad,
                &[common::valid_vib()],
                298.15,
                (1000, 1600),
                0,
                Some(&[1.]),
                Some(&[6.])
            )
            .is_none()
        );
    }
}

#[test]
fn changing_vibrational_match_window_clears_completed_fit() {
    let mut v = VibDataset::default();
    v.fitted = true;
    v.experimental_ir = Some(Spectrum::new(vec![1200., 1500.], vec![0., 1.]));
    v.fit_window_to_data();
    assert_eq!((v.range_low, v.range_high), (1220, 1480));
    assert!(!v.fitted);
}

#[test]
fn vibrational_curves_cover_the_requested_high_frequency_window() {
    let mut v = VibDataset::default();
    let mut c = common::valid_vib();
    c.frequencies[0] = 3200.;
    v.conformers.push(c);
    v.scale = 1.0;
    // Warm the default cache, then move the view and analysis beyond 2200.
    v.curves().unwrap();
    v.range_low = 3000;
    v.range_high = 3400;
    v.view_low = 3000;
    v.view_high = 3400;
    v.invalidate_evaluation();
    let curves = v.curves().unwrap();
    let peak = curves
        .ir
        .iter()
        .enumerate()
        .max_by(|a, b| a.1.total_cmp(b.1))
        .unwrap()
        .0;
    assert!((curves.frequency[peak] - 3200.).abs() < 1.1);
    assert!(*curves.frequency.last().unwrap() >= 3420.);

    let x = cdar::math::linspace(2950., 3450., 501);
    let observed = Spectrum::new(x.clone(), broaden_vib(&[3200.], &[1.], &x, 1., 6.));
    let fit = fit_vib_scale_gamma(
        &observed,
        &v.conformers,
        298.15,
        (3000, 3400),
        0,
        Some(&[0.98, 1.0]),
        Some(&[6.0]),
    )
    .unwrap();
    assert_eq!(fit.scale, 1.0);
    assert!(fit.ir_similarity > 0.999);
}
