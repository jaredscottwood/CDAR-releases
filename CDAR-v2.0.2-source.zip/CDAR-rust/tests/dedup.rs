use cdar::dedup::{self, deduplicate, frequency_agreement, superposition, symmetry_distance};
use cdar::electronic::{Conformer, Gauge, dedupe_electronic, weighted_transitions};
use cdar::gaussian::GaussianEvidence;
use cdar::vibrational::{VibConformer, VibKind, dedupe_vib, vib_weighted_sticks};

fn methyl() -> GaussianEvidence {
    GaussianEvidence {
        atomic_numbers: vec![6, 1, 1, 1, 7, 8, 16],
        coordinates: vec![
            [0., 0., 0.],
            [1., 0., 0.],
            [0., 1., 0.],
            [0., 0., 1.],
            [-1.3, 0., 0.],
            [-2.1, 1.1, 0.2],
            [-2., -1., 1.1],
        ],
        connectivity: vec![
            vec![1, 2, 3, 4],
            vec![0],
            vec![0],
            vec![0],
            vec![0, 5, 6],
            vec![4],
            vec![4],
        ],
        gibbs: Some(-100.),
        frequencies: (1..=15).map(|i| i as f64 * 100.).collect(),
        connectivity_reported: true,
        terminated_normally: true,
        ground_state_optimization_completed: true,
        ..Default::default()
    }
}
fn pair(a: GaussianEvidence, b: GaussianEvidence) -> dedup::DedupResult {
    deduplicate(&[a, b])
}
#[test]
fn graph_valid_methyl_permutation_and_rigid_motion_merge() {
    let a = methyl();
    let mut b = a.clone();
    b.coordinates.swap(1, 3);
    for p in &mut b.coordinates {
        *p = [7. - p[1], p[0] - 4., 2. + p[2]];
    }
    b.gibbs = Some(-100. + 0.1 / dedup::HARTREE_TO_KCAL);
    assert!(superposition(&a.coordinates, &b.coordinates).unwrap().rmsd > 0.1);
    let r = pair(a, b);
    assert_eq!(r.survivors, vec![0]);
    assert_eq!(r.duplicates[0].representative, 0);
    assert!(r.duplicates[0].geometry.max_deviation < 1e-10);
}
#[test]
fn displaced_methyl_atoms_are_no_longer_omitted() {
    let a = methyl();
    let mut b = a.clone();
    b.coordinates[1] = [3., 0., 0.];
    assert_eq!(pair(a, b).survivors, vec![0, 1]);
}
#[test]
fn proper_rotations_keep_non_superimposable_mirrors() {
    let a = methyl();
    let mut b = a.clone();
    for p in &mut b.coordinates {
        p[0] = -p[0];
    }
    assert!(!symmetry_distance(&a, &b).0.unwrap().passes());
    assert_eq!(pair(a, b).survivors.len(), 2);
}
#[test]
fn energy_gate_uses_kcal_and_lowest_gibbs_representative() {
    let a = methyl();
    let mut b = a.clone();
    b.gibbs = Some(-100. - 0.199999 / dedup::HARTREE_TO_KCAL);
    assert_eq!(pair(a.clone(), b.clone()).survivors, vec![1]);
    b.gibbs = Some(-100. - 0.200001 / dedup::HARTREE_TO_KCAL);
    assert_eq!(pair(a, b).survivors.len(), 2);
}
#[test]
fn frequency_rms_and_single_mode_gates_each_block_merges() {
    let a = methyl();
    let mut b = a.clone();
    b.frequencies.iter_mut().for_each(|v| *v += 2.0001);
    assert_eq!(pair(a.clone(), b).frequency_blocked, 1);
    let mut b = a.clone();
    b.frequencies[0] += 3.0001;
    assert!(
        frequency_agreement(&a.frequencies, &b.frequencies)
            .unwrap()
            .0
            < 2.
    );
    assert_eq!(pair(a.clone(), b).frequency_blocked, 1);
    let mut b = a.clone();
    b.frequencies.iter_mut().for_each(|v| *v += 2.);
    b.frequencies.reverse();
    assert_eq!(pair(a.clone(), b).survivors.len(), 1);
    let mut b = a.clone();
    b.frequencies[0] += 3.;
    assert_eq!(pair(a, b).survivors.len(), 1);
}
#[test]
fn incomplete_data_and_unequal_mode_counts_never_authorize_a_merge() {
    let a = methyl();
    for which in 0..6 {
        let mut b = a.clone();
        match which {
            0 => b.frequencies.clear(),
            1 => {
                b.frequencies.pop();
            }
            2 => b.gibbs = None,
            3 => b.coordinates.clear(),
            4 => b.frequencies[0] = f64::NAN,
            _ => b.error_termination = true,
        }
        assert_eq!(pair(a.clone(), b).survivors.len(), 2, "case {which}");
    }
}
#[test]
fn mismatched_skeletons_are_retained() {
    let a = methyl();
    let mut b = a.clone();
    b.connectivity[4].retain(|&i| i != 6);
    b.connectivity[6].clear();
    let r = pair(a, b);
    assert_eq!(r.graph_mismatches, 1);
    assert_eq!(r.survivors.len(), 2);
}
#[test]
fn representative_only_clustering_does_not_chain_energy_windows() {
    let a = methyl();
    let mut b = a.clone();
    let mut c = a.clone();
    b.gibbs = Some(-100. + 0.15 / dedup::HARTREE_TO_KCAL);
    c.gibbs = Some(-100. + 0.30 / dedup::HARTREE_TO_KCAL);
    let r = deduplicate(&[a, b, c]);
    assert_eq!(r.survivors, vec![0, 2]);
}
#[test]
fn maximum_atom_gate_rejects_a_small_average_displacement() {
    let a = methyl();
    let mut b = a.clone();
    b.coordinates[1][0] += 0.22;
    let m = symmetry_distance(&a, &b).0.unwrap();
    assert!(m.rmsd < dedup::RMSD_THRESHOLD, "{m:?}");
    assert!(m.max_deviation > dedup::MAX_DEVIATION_THRESHOLD, "{m:?}");
    assert_eq!(pair(a, b).survivors.len(), 2);
}
fn as_vib(name: &str, d: &GaussianEvidence) -> VibConformer {
    VibConformer {
        name: name.into(),
        free_energy: d.gibbs,
        atomic_numbers: d.atomic_numbers.clone(),
        coordinates_angstrom: d.coordinates.clone(),
        connectivity: d.connectivity.clone(),
        frequencies: d.frequencies.clone(),
        dipole_strengths: vec![1.; d.frequencies.len()],
        rotatory_strengths: vec![1.; d.frequencies.len()],
        imaginary_modes: d.imaginary_modes,
        connectivity_reported: true,
        terminated_normally: true,
        ground_state_optimization_completed: true,
        include: true,
        ..Default::default()
    }
}
fn as_ecd(name: &str, d: &GaussianEvidence) -> Conformer {
    Conformer {
        name: name.into(),
        opt_freq: Some(d.clone()),
        ev: vec![3.],
        fosc: vec![1.],
        rvel: Some(vec![1.]),
        rlen: Some(vec![1.]),
        include: true,
        ..Default::default()
    }
}
#[test]
fn both_modes_remove_same_complete_conformer_before_boltzmann_weights() {
    let a = methyl();
    let mut b = a.clone();
    b.coordinates.swap(1, 2);
    let mut c = a.clone();
    c.gibbs = Some(-100. + 1. / dedup::HARTREE_TO_KCAL);
    let inputs = [a, b, c];
    let mut e: Vec<_> = inputs
        .iter()
        .enumerate()
        .map(|(i, d)| as_ecd(&format!("c{i}"), d))
        .collect();
    let v: Vec<_> = inputs
        .iter()
        .enumerate()
        .map(|(i, d)| as_vib(&format!("c{i}"), d))
        .collect();
    let er = dedupe_electronic(&mut e);
    let vr = dedupe_vib(&v);
    assert_eq!(er.survivors, vr.report.survivors);
    assert_eq!(e.len(), 2);
    assert_eq!(e[0].name, "c0");
    assert_eq!(vr.conformers[1].name, "c2");
    let ew = weighted_transitions(&e, Gauge::Velocity, 298.15).weights;
    let vw = vib_weighted_sticks(&vr.conformers, VibKind::Vcd, 298.15);
    assert!((ew[0] - vw.populations[0]).abs() < 1e-12);
    assert!(ew[0] > 0.84 && ew[0] < 0.85);
    assert!((ew.iter().sum::<f64>() - 1.).abs() < 1e-12);
}
#[test]
fn imaginary_conformers_are_rejected_in_both_modes() {
    let a = methyl();
    let mut b = a.clone();
    b.imaginary_modes = 1;
    b.frequencies[0] = -10.;
    let mut e = vec![as_ecd("minimum", &a), as_ecd("saddle", &b)];
    dedupe_electronic(&mut e);
    let v = dedupe_vib(&[as_vib("minimum", &a), as_vib("saddle", &b)]);
    assert_eq!(e.len(), 1);
    assert_eq!(v.conformers.len(), 1);
    assert_eq!(v.report.rejected[0].0, 1);
}

#[test]
fn matches_supplied_python_oracle_for_68_cases() {
    fn numbers(s: &str) -> Vec<f64> {
        s.split(',').map(|v| v.parse().unwrap()).collect()
    }
    fn points(s: &str) -> Vec<[f64; 3]> {
        numbers(s)
            .chunks_exact(3)
            .map(|p| [p[0], p[1], p[2]])
            .collect()
    }
    let mut count = 0;
    for row in include_str!("fixtures/logdedup_reference.tsv")
        .lines()
        .filter(|l| !l.starts_with('#'))
    {
        let c: Vec<_> = row.split('|').collect();
        let z: Vec<u16> = c[1].split(',').map(|v| v.parse().unwrap()).collect();
        let mut graph = vec![Vec::new(); z.len()];
        for edge in c[2].split(',') {
            let (i, j) = edge.split_once('-').unwrap();
            let i: usize = i.parse().unwrap();
            let j: usize = j.parse().unwrap();
            graph[i].push(j);
            graph[j].push(i);
        }
        let a = GaussianEvidence {
            atomic_numbers: z,
            connectivity: graph,
            coordinates: points(c[3]),
            frequencies: numbers(c[5]),
            gibbs: Some(-100.),
            ..Default::default()
        };
        let mut b = a.clone();
        b.coordinates = points(c[4]);
        b.frequencies = numbers(c[6]);
        b.gibbs = Some(-100. + c[7].parse::<f64>().unwrap() / dedup::HARTREE_TO_KCAL);
        let expected = numbers(c[9]);
        let actual = superposition(&a.coordinates, &b.coordinates).unwrap();
        assert!(
            (actual.rmsd - expected[0]).abs() < 1e-6,
            "{} RMSD: {actual:?} vs {expected:?}",
            c[0]
        );
        assert!(
            (actual.max_deviation - expected[1]).abs() < 1e-6,
            "{} max: {actual:?} vs {expected:?}",
            c[0]
        );
        let r = pair(a, b);
        assert_eq!(
            r.duplicates.len(),
            c[8].parse::<usize>().unwrap(),
            "{}",
            c[0]
        );
        count += 1;
    }
    assert_eq!(count, 68);
}
