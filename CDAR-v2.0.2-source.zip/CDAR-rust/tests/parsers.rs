mod common;
use cdar::electronic::{Gauge, parse_experimental_text, parse_qm};
use cdar::vibrational::parse_gaussian_vib;
use std::fs;
use std::path::PathBuf;

fn temporary(name: &str, contents: &str) -> PathBuf {
    let path = std::env::temp_dir().join(format!("cdar-rust-{}-{name}", std::process::id()));
    fs::write(&path, contents).unwrap();
    path
}
#[test]
fn delimited_experimental_parser_ignores_headers() {
    let parsed = parse_experimental_text(
        "wavelength,absorbance,ecd\n200,0.2,-0.1\n210,0.8,0.3\n220,0.4,-0.2\n",
    )
    .unwrap();
    assert_eq!(parsed.ncolumns, 3);
    assert_eq!(parsed.wavelength, vec![200., 210., 220.]);
    assert_eq!(parsed.columns[0], vec![0.2, 0.8, 0.4]);
    assert_eq!(parsed.columns[1], vec![-0.1, 0.3, -0.2]);
}
#[test]
fn gaussian_excited_state_parser_reads_gibbs_and_both_gauges() {
    let path = temporary("electronic.log", &common::electronic_log());
    let c = parse_qm(&path).unwrap();
    fs::remove_file(path).unwrap();
    assert_eq!(c.nstates(), 2);
    assert_eq!(c.fosc, vec![0.12, 0.08]);
    assert_eq!(c.rot(Gauge::Velocity), vec![4., -2.]);
    assert_eq!(c.rot(Gauge::Length), vec![3., -1.]);
    assert_eq!(c.energy(), Some(-501.45));
    assert_eq!(c.energy_kind, "free");
}
#[test]
fn gaussian_frequency_parser_preserves_reported_modes_geometry_and_bonds() {
    let path = temporary("vibrational.log", &common::optimization_log());
    let c = parse_gaussian_vib(&path).unwrap();
    fs::remove_file(path).unwrap();
    assert_eq!(c.nmodes(), 3);
    assert_eq!(c.imaginary_modes, 0);
    assert!(c.terminated_normally);
    assert_eq!(c.free_energy, Some(-501.45));
    assert_eq!(c.atomic_numbers, vec![8, 1, 1]);
    assert_eq!(c.connectivity[0], vec![1, 2]);
    assert!(c.connectivity_reported);
    assert_eq!(c.rotatory_strengths, vec![0.1, -1.2, 0.8]);
}
#[test]
fn combined_ecd_log_reads_same_optimization_evidence_as_vcd() {
    use cdar::electronic::dedupe_electronic;
    use cdar::vibrational::dedupe_vib;
    let text = common::electronic_log().replace("-501.450000", "-501.450000D+00");
    let path = temporary("same-evidence.log", &text);
    let e = parse_qm(&path).unwrap();
    let v = parse_gaussian_vib(&path).unwrap();
    fs::remove_file(path).unwrap();
    let evidence = e.opt_freq.as_ref().unwrap();
    assert_eq!(e.energy(), v.free_energy);
    assert_eq!(evidence.frequencies, v.frequencies);
    assert_eq!(evidence.coordinates, v.coordinates_angstrom);
    assert_eq!(evidence.connectivity, v.connectivity);
    let mut electronic = vec![e.clone(), e];
    assert_eq!(dedupe_electronic(&mut electronic).duplicates.len(), 1);
    assert_eq!(dedupe_vib(&[v.clone(), v]).report.duplicates.len(), 1);
}
#[test]
fn native_input_orientation_is_accepted_without_inferred_geometry() {
    let path = temporary(
        "input-orientation.log",
        &common::optimization_log().replace("Standard orientation:", "Input orientation:"),
    );
    let c = parse_gaussian_vib(&path).unwrap();
    fs::remove_file(path).unwrap();
    assert_eq!(c.coordinates_angstrom[1], [0.95, 0., 0.]);
}
#[test]
fn gibbs_and_normal_termination_alone_do_not_prove_optimization() {
    let text = common::electronic_log().replace(" Optimization completed.\n", "");
    let path = temporary("no-optimization.log", &text);
    assert!(
        parse_qm(&path)
            .unwrap_err()
            .to_string()
            .contains("completed ground-state")
    );
    assert!(parse_gaussian_vib(&path).is_err());
    fs::remove_file(path).unwrap();
}
#[test]
fn ground_state_validation_rejects_incomplete_or_unsuccessful_jobs() {
    let base = common::optimization_log();
    let cases = [
        base.replace(
            " Sum of electronic and thermal Free Energies= -501.450000\n",
            "",
        ),
        base.replace(" Normal termination of Gaussian\n", ""),
        base.clone() + " Error termination via Lnk1e\n",
        base.replace("opt freq", "freq"),
        base.replace("opt freq", "opt freq td"),
        base.replace(" ! Initial Parameters !", " ! Other Parameters !"),
        base.replace("1100.0000 1250.0000 1400.0000", "1100.0000 1250.0000"),
        base.replace(
            "1100.0000 1250.0000 1400.0000",
            "-20.0000 1250.0000 1400.0000",
        ),
        base.replace("1100.0000 1250.0000 1400.0000", "NaN 1250.0000 1400.0000"),
        base.replace("2.0000 20.0000 15.0000", "2.0000 20.0000"),
        base.replace("0.1000 -1.2000 0.8000", "0.1000 -1.2000"),
        base.replace(" ! R2 R(1,3)", " ! R2 R(1,999)"),
        base.clone() + " #p opt b3lyp/6-31g(d)\n ---\n SCF Done: E(RB3LYP) = -501.8 A.U.\n",
    ];
    for (i, text) in cases.iter().enumerate() {
        let path = temporary(&format!("invalid-ground-{i}.log"), text);
        assert!(parse_gaussian_vib(&path).is_err(), "case {i}");
        fs::remove_file(path).unwrap();
    }
}
#[test]
fn ecd_requires_complete_td_data_and_its_own_normal_termination() {
    let opt = common::optimization_log();
    let td = common::td_log();
    let cases = [
        opt.clone(),
        opt.clone() + &td.replace(" Normal termination of Gaussian\n", ""),
        opt.clone()
            + &td.replace(
                " Rotatory Strengths (R) in cgs velocity representation:",
                " Other strengths in cgs velocity representation:",
            ),
        opt.clone()
            + &td.replace(
                " Rotatory Strengths (R) in cgs length representation:",
                " Other strengths in cgs length representation:",
            ),
        opt.clone() + &td.replace(" 2 1.5000 2.5000 3.5000 -1.0000\n", ""),
        opt.clone() + &td.replace("f=0.1200", "f=NaN"),
        opt.clone() + &td.replace("nstates=2", "nstates=3"),
        opt.clone() + &td.replace(" #p td", " #p opt td"),
        opt.clone() + &td.replace("Excited State 2:", "Excited State 3:"),
        opt.clone() + &td.replace("4.2000 eV", "NaN eV"),
    ];
    for (i, text) in cases.iter().enumerate() {
        let path = temporary(&format!("invalid-td-{i}.log"), text);
        assert!(parse_qm(&path).is_err(), "case {i}");
        fs::remove_file(path).unwrap();
    }
}
#[test]
fn later_optimization_and_frequency_blocks_cannot_reuse_old_success() {
    let opt = common::optimization_log();
    let path = temporary(
        "late-failed-optimization.log",
        &(opt.clone() + &opt.replace(" Optimization completed.\n", "") + &common::td_log()),
    );
    assert!(parse_qm(&path).is_err());
    fs::remove_file(path).unwrap();
    let changed = opt.replace(
        " Harmonic frequencies",
        &(common::geometry("Standard").replace("0.950000", "1.950000") + " Harmonic frequencies"),
    );
    let path = temporary("different-frequency-geometry.log", &changed);
    assert!(parse_gaussian_vib(&path).is_err());
    fs::remove_file(path).unwrap();
}

#[test]
fn each_ground_state_job_must_finish_and_supply_its_own_frequency_analysis() {
    let opt = common::optimization_log();
    let freq_route = " #p freq b3lyp/6-31g(d) geom=check\n ---\n";
    let cases = [
        opt.clone()
            + " #p sp b3lyp/6-31g(d)\n ---\n Sum of electronic and thermal Free Energies= -501.46\n Normal termination of Gaussian\n"
            + &common::td_log(),
        opt.replace(" Normal termination of Gaussian\n", "") + &common::td_log(),
        opt.clone() + freq_route + " Normal termination of Gaussian\n" + &common::td_log(),
        opt.clone()
            + " Harmonic frequencies (cm**-1)\n Normal termination of Gaussian\n"
            + &common::td_log(),
        opt.replace(" ! R2 R(1,3)", " ! R2 R(1,bad)"),
        opt.replace(" ! R2 R(1,3)", " ! R2 R(0,3)"),
    ];
    for (i, text) in cases.iter().enumerate() {
        let path = temporary(&format!("stale-evidence-{i}.log"), text);
        assert!(parse_qm(&path).is_err(), "ECD case {i}");
        assert!(parse_gaussian_vib(&path).is_err(), "VCD case {i}");
        fs::remove_file(path).unwrap();
    }
    // Separate, completed optimization and harmonic-analysis jobs in the same
    // LOG are valid when they describe the same converged geometry.
    let split = opt.replace("opt freq", "opt").replace(
        " Harmonic frequencies",
        &(String::from(" Normal termination of Gaussian\n")
            + freq_route
            + &common::geometry("Input")
            + " Harmonic frequencies"),
    );
    let path = temporary("separate-completed-jobs.log", &(split + &common::td_log()));
    assert!(parse_qm(&path).is_ok());
    assert!(parse_gaussian_vib(&path).is_ok());
    fs::remove_file(path).unwrap();
}

#[test]
fn harmonic_output_qualifies_without_a_literal_freq_route_token() {
    use cdar::vibrational::{VibKind, vib_weighted_sticks};
    for (i, route) in ["opt=calcall", "opt frequency=vcd", "opt fr\n eq=vcd"]
        .iter()
        .enumerate()
    {
        let text = common::optimization_log().replace("opt freq", route);
        let path = temporary(&format!("harmonic-route-{i}.log"), &text);
        let c = parse_gaussian_vib(&path).unwrap();
        assert_eq!(c.free_energy, Some(-501.45));
        assert_eq!(c.nmodes(), 3);
        let sticks = vib_weighted_sticks(&[c], VibKind::Vcd, 298.15);
        assert_eq!(sticks.populations, vec![1.]);
        assert_eq!(sticks.strengths, vec![0.1, -1.2, 0.8]);
        fs::write(&path, text.clone() + &common::td_log()).unwrap();
        assert_eq!(parse_qm(&path).unwrap().energy(), Some(-501.45));
        fs::write(
            &path,
            text.replace(" Frequencies -- 1100.0000 1250.0000 1400.0000\n", ""),
        )
        .unwrap();
        assert!(parse_gaussian_vib(&path).is_err());
        fs::remove_file(path).unwrap();
    }
}
