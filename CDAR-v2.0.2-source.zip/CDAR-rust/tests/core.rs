mod common;
use approx::assert_abs_diff_eq;

use cdar::electronic::{
    EcdUnit, ElectronicDataset, FitObjective, Profile, Spectrum, boltzmann_weights, broaden,
    ecd_similarity, esi, fit_uv,
};
use cdar::math::{
    ev_to_nm, format_axis_tick, linspace, nice_axis_range, nm_to_ev, rounded_axis_ticks,
};
use cdar::vibrational::{
    IntegerSpectrum, VibConformer, VibDataset, VibKind, kabsch_rmsd, lorentzian_vib, normalize_vib,
    shen_similarity, vib_weighted_sticks,
};

#[test]
fn energy_wavelength_conversion_round_trips() {
    for energy in [1.5, 2.0, 3.75, 6.2] {
        assert_abs_diff_eq!(nm_to_ev(ev_to_nm(energy)), energy, epsilon = 1e-12);
    }
}

#[test]
fn electronic_data_defaults_to_millidegrees() {
    let dataset = ElectronicDataset::default();
    assert_eq!(dataset.ecd_unit, EcdUnit::Millidegrees);
    assert_eq!(dataset.ecd_unit.axis_label(), "Millidegrees (mdeg)");
    assert_eq!(dataset.ecd_unit.coordinate_unit(), "mdeg");
    assert_eq!(
        EcdUnit::MolarEllipticity.axis_label(),
        "Molar ellipticity (deg·cm²·dmol⁻¹)"
    );
    assert_eq!(
        EcdUnit::MolarEllipticity.coordinate_unit(),
        "deg·cm²·dmol⁻¹"
    );
}

#[test]
fn method_windows_follow_their_distinct_defaults() {
    let mut electronic = ElectronicDataset::default();
    electronic.experimental_ecd =
        Some(Spectrum::new(vec![400.0, 190.0, 275.0], vec![0.0, 1.0, -0.5]).sorted());
    electronic.set_default_range();
    assert_abs_diff_eq!(electronic.wavelength_min, 190.0, epsilon = 1e-12);
    assert_abs_diff_eq!(electronic.wavelength_max, 400.0, epsilon = 1e-12);

    let mut vibrational = VibDataset::default();
    assert_eq!(
        (vibrational.range_low, vibrational.range_high),
        (1000, 1600)
    );
    assert_eq!((vibrational.view_low, vibrational.view_high), (1000, 1600));
    assert_eq!(vibrational.npoints, 1400);
    vibrational.experimental_ir = Some(Spectrum::new(
        vec![800.0, 1400.0, 2000.0],
        vec![0.0, 1.0, 0.0],
    ));
    vibrational.fit_window_to_data();
    assert_eq!(
        (vibrational.range_low, vibrational.range_high),
        (1000, 1600)
    );
}

#[test]
fn spectroscopy_axes_use_conventional_major_intervals() {
    let wavelength = rounded_axis_ticks(190.0, 400.0, 6, 10.0, 10.0);
    assert_abs_diff_eq!(wavelength.step, 30.0, epsilon = 1e-12);
    assert_eq!(
        wavelength.values,
        vec![190.0, 220.0, 250.0, 280.0, 310.0, 340.0, 370.0, 400.0]
    );

    let wavenumber = rounded_axis_ticks(1000.0, 1600.0, 6, 50.0, 50.0);
    assert_abs_diff_eq!(wavenumber.step, 100.0, epsilon = 1e-12);
    assert_eq!(
        wavenumber.values,
        vec![1000.0, 1100.0, 1200.0, 1300.0, 1400.0, 1500.0, 1600.0]
    );

    let absorbance = nice_axis_range(0.0, 1.02, 6, 0.1, false, true);
    assert!(absorbance.step >= 0.1);
    assert_abs_diff_eq!(absorbance.low, 0.0, epsilon = 1e-12);
    assert_eq!(
        rounded_axis_ticks(-5.0, 5.0, 6, 0.0, 0.0).values,
        vec![-4.0, -2.0, 0.0, 2.0, 4.0]
    );
    assert_eq!(format_axis_tick(0.0002, 0.0001, true), "2e-4");
}

#[test]
fn boltzmann_weights_are_normalized_and_ordered() {
    let (weights, relative) = boltzmann_weights(&[-100.0, -99.999, -99.995], 298.15);
    assert_abs_diff_eq!(weights.iter().sum::<f64>(), 1.0, epsilon = 1e-12);
    assert_abs_diff_eq!(relative[0], 0.0, epsilon = 1e-12);
    assert!(weights[0] > weights[1] && weights[1] > weights[2]);
}

#[test]
fn normalized_gaussian_integrates_to_one() {
    let grid = linspace(-3.0, 3.0, 60_001);
    let curve = broaden(&[0.0], &[1.0], 0.2, &grid, Profile::Gaussian, false);
    let dx = grid[1] - grid[0];
    let area: f64 = curve.iter().sum::<f64>() * dx;
    assert_abs_diff_eq!(area, 1.0, epsilon = 2e-4);
}

#[test]
fn ecd_similarity_has_the_expected_limits() {
    let observed = [0.0, 1.0, 0.4, -0.7, -1.0, 0.0];
    let exact = ecd_similarity(&observed, &observed);
    assert_abs_diff_eq!(exact.smsi, 1.0, epsilon = 1e-12);
    let exact_esi = esi(&observed, &observed);
    assert_abs_diff_eq!(exact_esi.delta, 1.0, epsilon = 1e-12);
    let mirror: Vec<f64> = observed.iter().map(|value| -*value).collect();
    assert_abs_diff_eq!(esi(&observed, &mirror).delta, -1.0, epsilon = 1e-12);
}

#[test]
fn uv_grid_fit_recovers_synthetic_bandwidth_and_shift() {
    let transitions = [3.2, 4.1, 4.8];
    let strengths = [0.4, 1.0, 0.65];
    let energy_grid = linspace(1.7, 6.3, 1800);
    let intensity = broaden(
        &transitions,
        &strengths,
        0.18,
        &energy_grid,
        Profile::Gaussian,
        false,
    );
    let mut pairs: Vec<(f64, f64)> = energy_grid
        .iter()
        .zip(&intensity)
        .map(|(energy, value)| (ev_to_nm(*energy) + 7.5, *value))
        .collect();
    pairs.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
    let (wavelength, observed): (Vec<_>, Vec<_>) = pairs.into_iter().unzip();
    let fit = fit_uv(
        &wavelength,
        &observed,
        &transitions,
        &strengths,
        &[0.14, 0.18, 0.22],
        &[5.0, 7.5, 10.0],
        Profile::Gaussian,
        FitObjective::LeastSquares,
        1.0,
    )
    .expect("synthetic UV spectrum should fit");
    assert_abs_diff_eq!(fit.sigma, 0.18, epsilon = 1e-12);
    assert_abs_diff_eq!(fit.shift, 7.5, epsilon = 1e-12);
}

#[test]
fn shen_similarity_reaches_exact_ir_and_vcd_limits() {
    let calculated: IntegerSpectrum = [(1000, 0.2), (1001, 1.0), (1002, -0.5)].into();
    let exact_ir = shen_similarity(&calculated, &calculated, 1000, 1002, VibKind::Ir);
    let exact_vcd = shen_similarity(&calculated, &calculated, 1000, 1002, VibKind::Vcd);
    assert_abs_diff_eq!(exact_ir, 1.0, epsilon = 1e-12);
    assert_abs_diff_eq!(exact_vcd, 1.0, epsilon = 1e-12);
    let mirrored: IntegerSpectrum = calculated.iter().map(|(x, value)| (*x, -*value)).collect();
    assert_abs_diff_eq!(
        shen_similarity(&mirrored, &calculated, 1000, 1002, VibKind::Vcd),
        -1.0,
        epsilon = 1e-12
    );
}

#[test]
fn vibrational_normalization_and_lorentzian_are_stable() {
    assert_eq!(
        normalize_vib(&[2.0, 4.0, 6.0], VibKind::Ir),
        vec![0.0, 0.5, 1.0]
    );
    assert_eq!(
        normalize_vib(&[-2.0, 0.0, 1.0], VibKind::Vcd),
        vec![-1.0, 0.0, 0.5]
    );
    let curve = lorentzian_vib(&[999.0, 1000.0, 1001.0], &[1000.0], &[2.0], 6.0);
    assert_abs_diff_eq!(curve[1], 2.0, epsilon = 1e-12);
    assert_abs_diff_eq!(curve[0], curve[2], epsilon = 1e-12);
}

#[test]
fn vibrational_weighting_requires_gibbs_free_energy() {
    let scf_only = VibConformer {
        scf_energy: Some(-500.0),
        free_energy: None,
        frequencies: vec![1100.0],
        dipole_strengths: vec![10.0],
        rotatory_strengths: vec![1.0],
        include: true,
        ..common::valid_vib()
    };
    let with_gibbs = VibConformer {
        scf_energy: Some(-499.0),
        free_energy: Some(-498.5),
        frequencies: vec![1200.0],
        dipole_strengths: vec![20.0],
        rotatory_strengths: vec![2.0],
        include: true,
        ..common::valid_vib()
    };
    let sticks = vib_weighted_sticks(&[scf_only.clone(), with_gibbs.clone()], VibKind::Ir, 298.15);
    assert_eq!(sticks.used_indices, vec![1]);
    assert_eq!(sticks.populations, vec![1.0]);

    let no_gibbs = vib_weighted_sticks(std::slice::from_ref(&scf_only), VibKind::Ir, 298.15);
    assert!(no_gibbs.centers.is_empty());
    let mut dataset = VibDataset::default();
    dataset.conformers.push(scf_only);
    assert!(!dataset.has_calculation());
    dataset.conformers.push(with_gibbs);
    assert!(dataset.has_calculation());
}

#[test]
fn all_atom_rmsd_is_translation_and_rotation_invariant() {
    let first = [
        [0.0, 0.0, 0.0],
        [2.0, 0.0, 0.0],
        [0.0, 3.0, 0.0],
        [0.0, 0.0, 4.0],
    ];
    let second: Vec<[f64; 3]> = first
        .iter()
        .map(|[x, y, z]| [10.0 - y, -7.0 + x, 2.5 + z])
        .collect();
    assert_abs_diff_eq!(kabsch_rmsd(&first, &second).unwrap(), 0.0, epsilon = 1e-10);

    // Fixed against the attached Python/SVD implementation for a general pair.
    let general_first = [
        [0.2, -1.1, 2.3],
        [1.7, 0.4, -0.6],
        [-2.0, 1.3, 0.8],
        [0.5, 2.2, -1.4],
        [3.1, -0.7, 1.2],
    ];
    let general_second = [
        [-1.0, 0.3, 2.7],
        [2.2, -0.5, 0.1],
        [-0.8, 2.4, -1.2],
        [1.6, 1.1, -2.0],
        [2.7, -1.8, 0.9],
    ];
    assert_abs_diff_eq!(
        kabsch_rmsd(&general_first, &general_second).unwrap(),
        0.760_330_666_013_132,
        epsilon = 1e-12
    );
}

#[test]
fn all_atom_rmsd_excludes_reflections() {
    let first = [
        [0.0, 0.0, 0.0],
        [2.0, 0.0, 0.0],
        [0.0, 3.0, 0.0],
        [0.0, 0.0, 4.0],
    ];
    let reflected: Vec<[f64; 3]> = first.iter().map(|[x, y, z]| [-x, *y, *z]).collect();
    assert!(kabsch_rmsd(&first, &reflected).unwrap() > cdar::dedup::RMSD_THRESHOLD);
}

#[test]
fn spectrum_sort_keeps_pairs_together() {
    let sorted = Spectrum::new(vec![3.0, 1.0, 2.0], vec![30.0, 10.0, 20.0]).sorted();
    assert_eq!(sorted.x, vec![1.0, 2.0, 3.0]);
    assert_eq!(sorted.y, vec![10.0, 20.0, 30.0]);
}

#[test]
fn invalid_electronic_conformers_cannot_receive_population_or_spectra() {
    use cdar::electronic::{Conformer, Gauge, dedupe_electronic, weighted_transitions};
    let valid = Conformer {
        name: "valid".into(),
        energy_first: Some(-900.),
        energy_last: Some(-901.),
        opt_freq: Some(common::evidence()),
        ev: vec![3.1],
        fosc: vec![0.12],
        rvel: Some(vec![4.]),
        rlen: Some(vec![3.]),
        include: true,
        ..Default::default()
    };
    assert_eq!(valid.energy(), Some(-500.));
    let mut missing_gibbs = valid.clone();
    missing_gibbs.opt_freq.as_mut().unwrap().gibbs = None;
    assert_eq!(missing_gibbs.energy(), None);
    let mut missing_gauge = valid.clone();
    missing_gauge.rvel = None;
    assert!(missing_gauge.rot(Gauge::Velocity).is_empty());
    let mut unfinished = valid.clone();
    unfinished
        .opt_freq
        .as_mut()
        .unwrap()
        .ground_state_optimization_completed = false;
    let mut conformers = vec![missing_gibbs, missing_gauge, unfinished];
    assert!(
        weighted_transitions(&conformers, Gauge::Velocity, 298.15)
            .ev
            .is_empty()
    );
    let mut dataset = ElectronicDataset::default();
    dataset.conformers = conformers.clone();
    assert!(!dataset.has_calculation());
    conformers.push(valid);
    let sticks = weighted_transitions(&conformers, Gauge::Velocity, 298.15);
    assert_eq!(sticks.used_indices, vec![3]);
    assert_eq!(sticks.weights, vec![1.]);
    assert_eq!(sticks.rot, vec![4.]);
    let report = dedupe_electronic(&mut conformers);
    assert_eq!(report.rejected.len(), 3);
    assert_eq!(report.survivors, vec![3]);
    assert_eq!(conformers.len(), 1);
    assert_eq!(conformers[0].name, "valid");
}

#[test]
fn incomplete_vibrational_arrays_cannot_be_truncated_into_valid_spectra() {
    use cdar::vibrational::dedupe_vib;
    let mut missing_strength = common::valid_vib();
    missing_strength.rotatory_strengths.clear();
    let mut extra_frequency = common::valid_vib();
    extra_frequency.frequencies.push(1200.);
    let mut unfinished = common::valid_vib();
    unfinished.ground_state_optimization_completed = false;
    let mut conformers = vec![missing_strength, extra_frequency, unfinished];
    for kind in [VibKind::Ir, VibKind::Vcd] {
        assert!(
            vib_weighted_sticks(&conformers, kind, 298.15)
                .centers
                .is_empty()
        );
    }
    conformers.push(common::valid_vib());
    let sticks = vib_weighted_sticks(&conformers, VibKind::Vcd, 298.15);
    assert_eq!(sticks.used_indices, vec![3]);
    assert_eq!(sticks.populations, vec![1.]);
    let result = dedupe_vib(&conformers);
    assert_eq!(result.report.rejected.len(), 3);
    assert_eq!(result.report.survivors, vec![3]);
    assert_eq!(result.conformers.len(), 1);
}

#[test]
fn methodology_wraps_prose_and_preserves_formula_lines() {
    use cdar::help::{ECD_METHODOLOGY, VCD_METHODOLOGY, reflow_methodology};
    for method in [ECD_METHODOLOGY, VCD_METHODOLOGY] {
        let displayed = reflow_methodology(method);
        assert!(displayed.contains("Automatic conformer de-duplication"));
        assert!(displayed.contains("\n  |ΔG| ≤ 0.20 kcal/mol\n"));
        assert!(!displayed.contains("opt/freq"));
        assert!(!displayed.contains("combined Gaussian"));
        assert!(!displayed.contains("retained unchecked"));
        for paragraph in displayed.split("\n\n") {
            if !paragraph.lines().any(|l| l.starts_with("  ")) {
                assert!(!paragraph.contains('\n'), "hard-wrapped prose: {paragraph}");
            }
        }
    }
}
