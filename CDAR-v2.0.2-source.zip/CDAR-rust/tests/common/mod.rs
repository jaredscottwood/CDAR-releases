#![allow(dead_code)]
use cdar::gaussian::GaussianEvidence;
use cdar::vibrational::VibConformer;

pub fn geometry(tag: &str) -> String {
    format!(
        " {tag} orientation:\n ---------------------------------------------------------------------\n Center Atomic Atomic Coordinates (Angstroms)\n Number Number Type X Y Z\n ---------------------------------------------------------------------\n 1 8 0 0.000000 0.000000 0.000000\n 2 1 0 0.950000 0.000000 0.000000\n 3 1 0 -0.250000 0.900000 0.000000\n ---------------------------------------------------------------------\n"
    )
}
pub fn optimization_log() -> String {
    format!(
        " Entering Gaussian System\n #p opt freq b3lyp/6-31g(d)\n -----------------------\n ! Initial Parameters !\n ! (Angstroms and Degrees) !\n ---------------------------------------------------------------------\n ! Name  Definition Value Derivative Info. !\n ---------------------------------------------------------------------\n ! R1 R(1,2) 0.9500 estimate D2E/DX2 !\n ! R2 R(1,3) 0.9340 estimate D2E/DX2 !\n ! A1 A(2,1,3) 105.0 estimate D2E/DX2 !\n ---------------------------------------------------------------------\n{} SCF Done: E(RB3LYP) = -501.500000 A.U.\n Optimization completed.\n -- Stationary point found.\n Harmonic frequencies (cm**-1)\n Frequencies -- 1100.0000 1250.0000 1400.0000\n Dip. str. -- 2.0000 20.0000 15.0000\n Rot. str. -- 0.1000 -1.2000 0.8000\n Sum of electronic and thermal Free Energies= -501.450000\n Normal termination of Gaussian\n",
        geometry("Standard")
    )
}
pub fn td_log() -> String {
    format!(
        " #p td(nstates=2) b3lyp/6-31g(d) geom=check\n -----------------------\n{} SCF Done: E(RB3LYP) = -502.000000 A.U.\n Excited State 1: Singlet-A 3.1000 eV 399.95 nm f=0.1200\n Excited State 2: Singlet-A 4.2000 eV 295.20 nm f=0.0800\n Rotatory Strengths (R) in cgs velocity representation:\n state XX YY ZZ R E-M Angle\n 1 1.0000 2.0000 3.0000 4.0000 5.0000\n 2 1.5000 2.5000 3.5000 -2.0000 5.5000\n Rotatory Strengths (R) in cgs length representation:\n state XX YY ZZ R\n 1 1.0000 2.0000 3.0000 3.0000\n 2 1.5000 2.5000 3.5000 -1.0000\n Normal termination of Gaussian\n",
        geometry("Input")
    )
}
pub fn electronic_log() -> String {
    optimization_log() + &td_log()
}
pub fn evidence() -> GaussianEvidence {
    GaussianEvidence {
        atomic_numbers: vec![8, 1, 1],
        coordinates: vec![[0., 0., 0.], [0.95, 0., 0.], [-0.25, 0.9, 0.]],
        connectivity: vec![vec![1, 2], vec![0], vec![0]],
        connectivity_reported: true,
        gibbs: Some(-500.),
        frequencies: vec![1100., 1250., 1400.],
        terminated_normally: true,
        ground_state_optimization_completed: true,
        ..Default::default()
    }
}
pub fn valid_vib() -> VibConformer {
    VibConformer {
        atomic_numbers: vec![1, 17],
        coordinates_angstrom: vec![[0., 0., 0.], [1.3, 0., 0.]],
        connectivity: vec![vec![1], vec![0]],
        connectivity_reported: true,
        ground_state_optimization_completed: true,
        terminated_normally: true,
        free_energy: Some(-500.),
        frequencies: vec![1100.],
        dipole_strengths: vec![1.],
        rotatory_strengths: vec![1.],
        include: true,
        ..Default::default()
    }
}
