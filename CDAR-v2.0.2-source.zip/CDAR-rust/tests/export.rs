mod common;
use std::fs;

use cdar::electronic::{Conformer, ElectronicDataset, Spectrum};
use cdar::export::{
    FigureSpec, LineSeries, Marker, PanelSpec, StickSeries, electronic_figure, figure_svg,
    vibrational_figure, write_figure,
};
use cdar::vibrational::{VibConformer, VibDataset};

fn sample_figure() -> FigureSpec {
    let x = [200.0, 220.0, 240.0, 260.0, 280.0, 300.0];
    let y = [0.0, 0.7, -0.2, 1.0, 0.3, 0.0];
    FigureSpec {
        title: "CDAR <export> check".into(),
        show_legend: true,
        panels: vec![PanelSpec {
            y_label: "Δε".into(),
            x_label: Some("Wavelength (nm)".into()),
            x_range: (200.0, 300.0),
            x_tick_quantum: 10.0,
            y_tick_minimum: 0.0,
            scientific_y: false,
            reverse_x: false,
            symmetric_y: true,
            zero_line: true,
            lines: vec![
                LineSeries::new("Calculated", "#c62828", &x, &y),
                LineSeries::new(
                    "Enantiomer",
                    "#1565c0",
                    &x,
                    &y.iter().map(|value| -*value).collect::<Vec<_>>(),
                )
                .dashed(),
            ],
            sticks: vec![StickSeries {
                color: "#c62828".into(),
                x: vec![220.0, 260.0],
                height: vec![0.5, -0.8],
                positive_only: false,
            }],
            markers: vec![Marker {
                x: 260.0,
                y: 1.0,
                upward: true,
                color: "#0b7a5a".into(),
            }],
        }],
    }
}

#[test]
fn figure_exports_are_well_formed() {
    let figure = sample_figure();
    let svg_text = figure_svg(&figure);
    assert!(svg_text.starts_with("<svg"));
    assert!(svg_text.contains("CDAR &lt;export&gt; check"));
    assert!(svg_text.contains("data-legend-corner="));
    assert!(svg_text.contains("stroke-dasharray=\"5,2\""));
    assert!(!svg_text.contains("fill-opacity=\"0.93\""));
    assert!(svg_text.ends_with("</svg>"));

    let mut without_legend = figure.clone();
    without_legend.show_legend = false;
    assert!(!figure_svg(&without_legend).contains("data-legend-corner="));

    let base = std::env::temp_dir().join(format!("cdar-export-{}", std::process::id()));
    let svg_path = base.with_extension("svg");
    let pdf_path = base.with_extension("pdf");
    let png_path = base.with_extension("png");
    write_figure(&figure, &svg_path, 144).expect("SVG export should succeed");
    write_figure(&figure, &pdf_path, 144).expect("PDF export should succeed");
    write_figure(&figure, &png_path, 144).expect("PNG export should succeed");

    assert!(fs::read(&svg_path).unwrap().starts_with(b"<svg"));
    assert!(fs::read(&pdf_path).unwrap().starts_with(b"%PDF"));
    assert!(
        fs::read(&png_path)
            .unwrap()
            .starts_with(b"\x89PNG\r\n\x1a\n")
    );

    for path in [svg_path, pdf_path, png_path] {
        let _ = fs::remove_file(path);
    }
}

#[test]
fn exported_axes_use_rounded_ticks_and_compact_vcd_notation() {
    let mut figure = sample_figure();
    let panel = &mut figure.panels[0];
    panel.x_range = (190.0, 400.0);
    panel.scientific_y = true;
    for line in &mut panel.lines {
        for point in &mut line.points {
            point[1] *= 0.0004;
        }
    }
    let svg = figure_svg(&figure);
    for tick in ["190", "220", "250", "280", "310", "340", "370", "400"] {
        assert!(svg.contains(&format!(">{tick}</text>")));
    }
    assert!(!svg.contains(">232</text>"));
    assert!(svg.contains("e-4</text>"));
}

#[test]
fn vcd_export_matches_the_live_enantiomer_style() {
    let mut dataset = VibDataset::default();
    dataset.show_enantiomer = true;
    dataset.conformers.push(VibConformer {
        free_energy: Some(-500.0),
        frequencies: vec![1100.0],
        dipole_strengths: vec![10.0],
        rotatory_strengths: vec![1.0],
        include: true,
        ..common::valid_vib()
    });
    let figure = vibrational_figure(&mut dataset);
    let enantiomer = figure.panels[1]
        .lines
        .iter()
        .find(|line| line.label == "Enantiomer")
        .expect("VCD export should include its enabled enantiomer");
    assert_eq!(enantiomer.color, "#1565c0");
    assert!(enantiomer.dashed);
}

#[test]
fn electronic_export_uses_fitted_labels_only_after_auto_fit() {
    let mut dataset = ElectronicDataset::default();
    dataset.show_enantiomer = true;
    dataset.conformers.push(Conformer {
        name: "calculation".into(),
        energy_first: Some(-400.0),
        ev: vec![3.0, 4.0],
        fosc: vec![0.4, 0.8],
        rvel: Some(vec![1.0, -0.5]),
        rlen: Some(vec![1.0, -0.5]),
        opt_freq: Some(common::evidence()),
        include: true,
        ..Default::default()
    });

    let before = electronic_figure(&mut dataset);
    assert_eq!(before.panels[0].lines[0].label, "Calculated");
    assert_eq!(before.panels[1].lines[0].label, "Calculated");
    assert_eq!(before.panels[1].lines[1].label, "Enantiomer");

    dataset.fitted = true;
    let after = electronic_figure(&mut dataset);
    assert_eq!(after.panels[0].lines[0].label, "Calculated (fitted)");
    assert_eq!(after.panels[1].lines[0].label, "Calculated (fitted)");
    assert_eq!(after.panels[1].lines[1].label, "Enantiomer (fitted)");
    let svg = figure_svg(&after);
    assert!(svg.contains("Calculated (fitted)"));
    assert!(svg.contains("Enantiomer (fitted)"));

    dataset.reset_fit();
    let reset = electronic_figure(&mut dataset);
    assert_eq!(reset.panels[0].lines[0].label, "Calculated");
    assert_eq!(reset.panels[1].lines[1].label, "Enantiomer");
}

#[test]
fn auto_fitted_vibrational_image_export_preserves_exact_fitted_labels() {
    let mut dataset = VibDataset::default();
    dataset.fitted = true;
    dataset.show_enantiomer = true;
    dataset.conformers.push(VibConformer {
        free_energy: Some(-500.0),
        frequencies: vec![1150.0],
        dipole_strengths: vec![10.0],
        rotatory_strengths: vec![1.0],
        include: true,
        ..common::valid_vib()
    });
    let x = vec![980.0, 1000.0, 1100.0, 1200.0, 1600.0, 1620.0];
    dataset.experimental_ir = Some(Spectrum::new(x.clone(), vec![0.0, 0.0, 1.0, 0.2, 0.0, 0.0]));
    dataset.experimental_vcd = Some(Spectrum::new(x, vec![0.0, 0.0, 1.0, -0.5, 0.0, 0.0]));

    let figure = vibrational_figure(&mut dataset);
    let ir_labels: Vec<_> = figure.panels[0]
        .lines
        .iter()
        .map(|line| line.label.as_str())
        .collect();
    let vcd_labels: Vec<_> = figure.panels[1]
        .lines
        .iter()
        .map(|line| line.label.as_str())
        .collect();
    assert_eq!(ir_labels, ["Experimental", "Calculated (fitted)"]);
    assert_eq!(
        vcd_labels,
        ["Experimental", "Calculated (fitted)", "Enantiomer (fitted)"]
    );
    let svg = figure_svg(&figure);
    assert!(svg.contains("Calculated (fitted)"));
    assert!(svg.contains("Enantiomer (fitted)"));
}

#[test]
fn matched_vibrational_curves_are_not_labeled_as_fitted_before_auto_fit() {
    let mut dataset = VibDataset::default();
    dataset.show_enantiomer = true;
    dataset.conformers.push(VibConformer {
        free_energy: Some(-500.0),
        frequencies: vec![1150.0],
        dipole_strengths: vec![10.0],
        rotatory_strengths: vec![1.0],
        include: true,
        ..common::valid_vib()
    });
    let x = vec![980.0, 1000.0, 1100.0, 1200.0, 1600.0, 1620.0];
    dataset.experimental_ir = Some(Spectrum::new(x.clone(), vec![0.0, 0.0, 1.0, 0.2, 0.0, 0.0]));
    dataset.experimental_vcd = Some(Spectrum::new(x, vec![0.0, 0.0, 1.0, -0.5, 0.0, 0.0]));

    let figure = vibrational_figure(&mut dataset);
    let ir_labels: Vec<_> = figure.panels[0]
        .lines
        .iter()
        .map(|line| line.label.as_str())
        .collect();
    let vcd_labels: Vec<_> = figure.panels[1]
        .lines
        .iter()
        .map(|line| line.label.as_str())
        .collect();
    assert_eq!(ir_labels, ["Experimental", "Calculated"]);
    assert_eq!(vcd_labels, ["Experimental", "Calculated", "Enantiomer"]);
}
