# CDAR 2.0.2 protocol validation

The supplied `logdedup.py` is included unchanged as an oracle, not as a runtime
dependency. Regenerate the deterministic fixture with:

```sh
python3 validation/generate_reference.py
cargo test
```

The 68 cases compare duplicate verdicts and proper-rotation RMSD/max-displacement
metrics. They cover rigid motion, element-equivalent methyl permutations, small
and large perturbations, reflections, energy/frequency rejections, rings without
singleton anchors, and tert-butyl branch permutations. Additional Rust tests
cover unequal frequency counts, missing data, graph mismatches, maximum-atom
outliers, non-chaining representatives, optimization parsing, identical ECD/VCD
survivors, and populations calculated once per survivor. Input regressions reject
missing Gibbs energy, incomplete frequency or strength tables, malformed data,
non-positive modes, failed/unfinished jobs, excited-state optimization, and stale
evidence across job boundaries. Population tests independently prevent invalid
conformers from receiving weight or generating spectra. These are synthetic
regressions; no user production LOG dataset was supplied for this release.

## Preserved protocol

Energy ≤ 0.20 kcal/mol; symmetry RMSD ≤ 0.10 Å; maximum displacement ≤ 0.15 Å;
sorted-frequency RMSD ≤ 2.0 cm^-1 and maximum difference ≤ 3.0 cm^-1. The
Hartree conversion is exactly 627.509474. Application input qualification
requires the reported Gaussian Initial Parameters bond table.
The 5% inertia screen, proper quaternion rotations, graph-label refinement,
Hungarian orbit proposals, 25 orbit iterations, 720 seed cap, 500000 mapping
cap and 10000000-node exact-search budget are retained.

## Deliberate corrections to script edge cases

- The supplied script calls `itertools` without importing it. The oracle driver
  injects that standard-library import into the module namespace; the supplied
  file remains byte-for-byte unchanged. Rust needs no such import or dependency.
- Application imports reject missing/invalid data, non-positive modes, or
  error-terminated calculations before invoking the merger. Completed geometry
  optimization and normal termination must be established, Gibbs energy and
  reported connectivity must be present, and every spectral array must be
  complete. ECD additionally requires the completed subsequent TD calculation.
  The pure numerical merger tests still verify that incomplete evidence or
  unequal mode counts cannot authorize deletion; those kernel tests do not
  constitute permission to import invalid files.
- Inconsistent atom lists/bond graphs block comparison. The script's driver
  warns, then continues using the first conformer's graph; Rust does not.
- A graph-valid heuristic assignment that fails a geometric gate falls back to
  exact search. The supplied code falls back only if the heuristic returns no
  permutation, although its comments describe a general exact fallback.
- Exact search is streamed and performed only if needed. Both caps terminate
  the entire search; the script's node-budget exhaustion can keep revisiting
  sibling branches. A capped search cannot authorize an unproven merge.
- Both displacement metrics use the same explicitly rotated coordinates,
  fulfilling the reference's eigenvalue/displacement consistency requirement.
- Non-minimum structures are rejected during import. Duplicate removal never
  transfers multiplicity to the representative that survives.

The current protocol expects consistent Gaussian atom numbering and bonding
skeletons; it handles permitted symmetry permutations within that skeleton.
It intentionally does not invent correspondences between different numbered
bond graphs or recover isotopic masses that the supplied parser does not read.

## Release checks

- All 80 Rust tests pass, including 68 Python-oracle cases inside the parity
  test, plus parser, input eligibility, population, fitting, layout, and export
  regressions.
- Formatting and Clippy over all targets pass with warnings denied.
- The optimized Linux release build passes.
- The x86_64 Windows MSVC target compile check passes (cross-check only, not a
  Windows-linked executable or a Windows GUI runtime test).
- Linux test compilation used one code-generation unit and disabled incremental
  compilation to avoid empty dependency object files in the temporary build
  environment. This is a validation-command override; project dependencies and
  end-user build configuration are unchanged.

## Troubleshooting regressions

- Measured IR/VCD CSVs with zero or negative wavenumber endpoints load without
  dropping rows and complete synthetic fitting and matching. Electronic inputs
  still require positive wavelengths; malformed or non-finite measurements
  remain rejected. The subsequently supplied `ir-test.csv` was checked directly:
  all 4096 rows were preserved through both measurement loaders, automatic IR
  identification succeeded, and Auto-Fit and matching accepted the spectrum.
- Both activity logs retain ordered events and errors, update while open, and
  keep each calculation-import report once. Tests cover per-mode separation,
  entry/byte limits, large Unicode reports, and the footer divider geometry.
- A paired-mode wording regression keeps shared initial, empty-import, and
  fit-range language identical while preserving mode-specific scientific text.

- A 47-file synthetic selection produces 34 retained conformers, 3 duplicates,
  and 10 rejections in both ECD and VCD. A second import reports the 34 already
  loaded files separately, keeps the same populations, and never lists a source
  file as its own removed/kept match.
- Repeated selections are skipped. Equal basenames in different directories
  remain distinct source files; a new lower-Gibbs representative can replace a
  previously retained duplicate with both sources identified explicitly.
- Complete harmonic output without a literal `freq` route token qualifies;
  removing its modes still fails validation. Tests exercise both spectral modes.
- The footer's two cards retain equal height, the 18-point workspace gap, and
  the established bottom inset. A simulated pointer click tests access to the
  complete log at laptop window width.

The reported production Gaussian LOGs were not attached to the bug report.
These regressions reproduce the identified failure mechanisms using controlled
fixtures; they do not establish acceptance of the user's exact production set.

## 2.0.1 audit regressions

Six new tests were first run against 2.0.0 and reproduced stale populations,
missing measurement columns, false fit success, reversed VCD windows, a stale
fitted flag after fitting the window to data, and missing high-frequency VCD
bands. They now pass. Further cases exercise delayed worker results, compound
splitting and unit preservation, queued mappings, finite thermodynamic inputs,
all four supported measurement delimiters, JASCO data, TD geometry consistency,
and synthetic peak-shape fitting with Gaussian and Lorentzian profiles.

The VCD default grid remains 1,400 points over 800–2,200 cm⁻¹. Wider display or
analysis windows extend the numerical domain without reducing its sampling
density; fitting also evaluates those additional frequencies. The default
1000–1600 cm⁻¹ analysis window and duplicate-detection gates are unchanged.

The Windows icon guard releases only handles created by CDAR, including partial
creation failures, and detaches any handle still assigned to the window before
freeing it. See Microsoft's [DestroyIcon ownership requirements](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-destroyicon)
and [WM_SETICON behavior](https://learn.microsoft.com/en-us/windows/win32/winmsg/wm-seticon).
This code is cross-compiled here; native window behavior requires Windows testing.

The 2.0.2 interface regression also locks the complete two-developer credit and
ensures neither workspace title reintroduces the redundant `CDAR` branding.
