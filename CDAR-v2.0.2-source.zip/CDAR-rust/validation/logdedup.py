#!/usr/bin/env python3
"""
logdedup.py -- find duplicate conformers among Gaussian opt freq log files.

Point it at a folder of {compound}_{n}.log files from optimization + frequency calculations and it reports
which conformers converged to the same minimum. Nothing else is required: no SDF, no NMR calculation, no
structure file of any kind. Everything comes out of the logs.

    python logdedup.py                     analyse *.log in the current folder
    python logdedup.py path/to/folder      analyse a folder
    python logdedup.py a.log b.log c.log   analyse specific files
    python logdedup.py --report out.txt    also write a detailed report

WHAT IT DOES

    1. Reads each log's final geometry, its Gibbs free energy and its vibrational frequencies.
    2. Perceives the bonding skeleton from the geometry, using covalent radii. Bond ORDERS are never needed:
       the comparison rests on the automorphism group of the molecular graph, and which atoms are bonded is
       all that determines that. A double bond and a single bond between the same pair of atoms give the same
       graph and the same symmetry.
    3. Merges two conformers only when EVERY gate agrees:
         - Gibbs free energies within 0.20 kcal/mol
         - symmetry-corrected RMSD within 0.10 A, with no single atom displaced more than 0.15 A
         - vibrational spectra within 2.0 cm^-1 overall and 3.0 cm^-1 in every individual mode
       All three come from the NMR workbench unchanged, thresholds included.

WHY THE COMPARISON IS SYMMETRY-CORRECTED

    The quantity computed is min over P in Aut(G) of Kabsch_RMSD(A, P.B) -- the best superposition over every
    relabelling the molecular graph permits. That is what makes a methyl rotated by 120 degrees compare equal
    to itself: atom for atom it looks like a completely different geometry, but it is the same minimum.

    The superposition is a proper rotation only, so mirror-image conformers are never merged. For an achiral
    molecule those are exactly isoenergetic and their equal and opposite rotational strengths are what make
    its VCD and ECD cancel; merging them would break that. For NMR they contribute identically either way.
"""

import os
import re
import sys
import math
import glob
import argparse
from collections import defaultdict, deque

import numpy as np


# ==================================================================================================================
# READING GAUSSIAN OUTPUT
# ==================================================================================================================

HARTREE_TO_KCAL = 627.509474

# Covalent radii in Angstrom, used to perceive which atoms are bonded. Values from Cordero et al. (2008), the
# same set most structure viewers use.
COVALENT_RADII = {
    'H': 0.31, 'He': 0.28, 'Li': 1.28, 'Be': 0.96, 'B': 0.84, 'C': 0.76, 'N': 0.71, 'O': 0.66, 'F': 0.57,
    'Ne': 0.58, 'Na': 1.66, 'Mg': 1.41, 'Al': 1.21, 'Si': 1.11, 'P': 1.07, 'S': 1.05, 'Cl': 1.02, 'Ar': 1.06,
    'K': 2.03, 'Ca': 1.76, 'Sc': 1.70, 'Ti': 1.60, 'V': 1.53, 'Cr': 1.39, 'Mn': 1.39, 'Fe': 1.32, 'Co': 1.26,
    'Ni': 1.24, 'Cu': 1.32, 'Zn': 1.22, 'Ga': 1.22, 'Ge': 1.20, 'As': 1.19, 'Se': 1.20, 'Br': 1.20,
    'Kr': 1.16, 'Rb': 2.20, 'Sr': 1.95, 'I': 1.39, 'Xe': 1.40, 'Pt': 1.36, 'Au': 1.36, 'Hg': 1.32,
}
DEFAULT_COVALENT_RADIUS = 1.20

BOND_TOLERANCE = 0.45
# How much longer than the sum of covalent radii a contact may be and still count as a bond. The usual choice
# is 0.4 to 0.5 Angstrom: below that some genuine long C-N and C-S bonds are missed, above it close
# non-bonded contacts start being perceived as bonds. Sensitivity to this is checked and reported.

ATOMIC_NUMBER_TO_SYMBOL = {
    1: 'H', 2: 'He', 3: 'Li', 4: 'Be', 5: 'B', 6: 'C', 7: 'N', 8: 'O', 9: 'F', 10: 'Ne',
    11: 'Na', 12: 'Mg', 13: 'Al', 14: 'Si', 15: 'P', 16: 'S', 17: 'Cl', 18: 'Ar', 19: 'K', 20: 'Ca',
    21: 'Sc', 22: 'Ti', 23: 'V', 24: 'Cr', 25: 'Mn', 26: 'Fe', 27: 'Co', 28: 'Ni', 29: 'Cu', 30: 'Zn',
    31: 'Ga', 32: 'Ge', 33: 'As', 34: 'Se', 35: 'Br', 36: 'Kr', 37: 'Rb', 38: 'Sr', 53: 'I', 54: 'Xe',
    78: 'Pt', 79: 'Au', 80: 'Hg',
}


def read_gaussian_log(path):
    """
    Everything this program needs from one Gaussian log.

    Returns a dict with elements, coordinates, gibbs, frequencies, imaginary_count and any problems found,
    or None if the file cannot be read at all.

    The LAST geometry block is taken rather than the first: an optimization prints one per step, and the
    converged structure is the one at the end. Standard orientation is preferred, with input orientation as
    the fallback for jobs run with nosymm, where Gaussian prints no standard orientation at all.
    """
    try:
        with open(path, 'r', errors='replace') as handle:
            lines = handle.readlines()
    except OSError as error:
        print(f"  Could not read {os.path.basename(path)}: {error}")
        return None

    result = {'path': path, 'name': os.path.splitext(os.path.basename(path))[0],
              'elements': [], 'coordinates': [], 'gibbs': None, 'frequencies': [],
              'imaginary_count': 0, 'problems': [], 'normal_termination': False,
              'reported_connectivity': read_connectivity_from_parameters(lines, path)}

    standard_blocks, input_blocks = [], []
    index = 0
    while index < len(lines):
        line = lines[index]

        if 'Standard orientation:' in line or 'Input orientation:' in line:
            target = standard_blocks if 'Standard orientation:' in line else input_blocks
            # Header is five lines: title, rule, two column headings, rule
            position = index + 5
            block = []
            while position < len(lines) and '---------' not in lines[position]:
                parts = lines[position].split()
                if len(parts) >= 6:
                    try:
                        block.append((int(parts[1]), float(parts[3]), float(parts[4]), float(parts[5])))
                    except ValueError:
                        pass
                position += 1
            if block:
                target.append(block)
            index = position
            continue

        if 'Sum of electronic and thermal Free Energies=' in line:
            match = re.search(r'=\s*(-?\d+\.\d+)', line)
            if match:
                result['gibbs'] = float(match.group(1))

        elif line.strip().startswith('Frequencies --'):
            for value in line.split('--', 1)[1].split():
                try:
                    result['frequencies'].append(float(value))
                except ValueError:
                    pass

        elif 'imaginary frequencies' in line.lower():
            match = re.search(r'(\d+)\s+imaginary frequencies', line, re.I)
            if match:
                result['imaginary_count'] = int(match.group(1))

        elif 'Normal termination' in line:
            result['normal_termination'] = True

        elif 'Error termination' in line:
            result['problems'].append('error termination')

        index += 1

    geometry = standard_blocks[-1] if standard_blocks else (input_blocks[-1] if input_blocks else None)
    if not geometry:
        result['problems'].append('no geometry found')
        return result

    result['elements'] = [ATOMIC_NUMBER_TO_SYMBOL.get(number, 'X') for number, _x, _y, _z in geometry]
    result['coordinates'] = [(x, y, z) for _n, x, y, z in geometry]

    if result['gibbs'] is None:
        result['problems'].append('no Gibbs free energy (was this a freq job?)')
    if not result['frequencies']:
        result['problems'].append('no frequencies')
    # A negative frequency is an imaginary one; Gaussian prints them as negative numbers
    negative = sum(1 for value in result['frequencies'] if value < 0)
    if negative and not result['imaginary_count']:
        result['imaginary_count'] = negative
    if result['imaginary_count']:
        result['problems'].append(f"{result['imaginary_count']} imaginary frequency/frequencies "
                                  f"(not a true minimum)")
    if 'X' in result['elements']:
        result['problems'].append('unrecognised element')

    return result


def read_connectivity_from_parameters(lines, path):
    """
    Connectivity as Gaussian itself perceived it, from the Initial Parameters table.

    Gaussian prints its internal coordinates near the top of an optimization: every bond as R(i,j), then every
    angle as A(i,j,k), then every dihedral as D(i,j,k,l). The R entries ARE the connectivity -- explicit,
    complete, and carrying no bond orders, which is exactly what the graph comparison needs.

    This is preferred over deriving bonds from distances because it is not a judgement at all. A covalent-radii
    cutoff has to decide what counts as a bond, and a contact sitting near that cutoff can be perceived
    differently in two conformers of the same molecule -- which changes the molecular graph and therefore the
    symmetry the comparison rests on. Reading Gaussian's own table removes that decision entirely.

    Returns {atom: [neighbour, ...]} over 1-based atom numbers, or None when the section is absent.
    """
    start = -1
    for index, line in enumerate(lines):
        if "Initial Parameters" in line and index + 1 < len(lines) and "Angstroms and Degrees" in lines[index + 1]:
            for offset in range(index, min(index + 10, len(lines))):
                if "Name  Definition" in lines[offset]:
                    start = offset + 2      # past the header and its separator
                    break
            break
    if start == -1:
        return None

    neighbours = defaultdict(set)
    # The table is bounded in practice, but a malformed file missing its terminator would otherwise be
    # scanned to the end
    for index in range(start, min(len(lines), start + 5000)):
        line = lines[index].strip()
        if not line:
            continue
        # Bonds are listed before angles and dihedrals, so the first A( or D( entry ends the bond section
        if line.startswith('!') and re.search(r'[AD]\(\d+', line) and not re.search(r'R\(\d+,\d+\)', line):
            break
        if line.startswith('---'):
            break
        match = re.search(r'R\((\d+),(\d+)\)', line)
        if match:
            first, second = int(match.group(1)), int(match.group(2))
            neighbours[first].add(second)
            neighbours[second].add(first)

    if not neighbours:
        return None
    return {atom: sorted(found) for atom, found in neighbours.items()}


def perceive_bonds(elements, coordinates, tolerance=BOND_TOLERANCE):
    """
    Which atoms are bonded, from geometry alone.

    Two atoms are bonded when their separation is no more than the sum of their covalent radii plus a
    tolerance. This is all the deduplication needs: the comparison rests on the automorphism group of the
    molecular graph, and that is fixed by WHICH atoms are bonded, not by bond order. Deriving orders would add
    a dependency on the wavefunction for no gain here.

    Used only when a log has no Initial Parameters section -- a single-point job, say, or output truncated
    before it was printed. Where that section exists it is authoritative and this is not called.

    Returns {atom: [neighbour, ...]} over 1-based atom numbers.
    """
    points = np.asarray(coordinates, dtype=float)
    count = len(points)
    radii = np.array([COVALENT_RADII.get(symbol, DEFAULT_COVALENT_RADIUS) for symbol in elements])

    connectivity = {atom: [] for atom in range(1, count + 1)}
    if count < 2:
        return connectivity

    # Pairwise distances in one shot; at these atom counts the full matrix is far cheaper than a loop
    differences = points[:, None, :] - points[None, :, :]
    distances = np.sqrt((differences ** 2).sum(axis=2))
    limits = radii[:, None] + radii[None, :] + tolerance

    bonded = (distances <= limits) & (distances > 0.1)
    for first, second in zip(*np.nonzero(np.triu(bonded, k=1))):
        connectivity[int(first) + 1].append(int(second) + 1)
        connectivity[int(second) + 1].append(int(first) + 1)
    return connectivity


def describe_skeleton(elements, connectivity):
    """A one-line summary of the perceived skeleton, for the report."""
    bonds = sum(len(neighbours) for neighbours in connectivity.values()) // 2
    counts = defaultdict(int)
    for symbol in elements:
        counts[symbol] += 1
    formula = "".join(f"{symbol}{counts[symbol]}" for symbol in sorted(counts))
    unbonded = [atom for atom, neighbours in connectivity.items() if not neighbours]
    text = f"{formula}, {len(elements)} atoms, {bonds} bonds"
    if unbonded:
        text += f", {len(unbonded)} unbonded atom(s): {unbonded[:6]}"
    return text


def check_skeleton_consistency(structures):
    """
    Confirm every conformer gives the same skeleton before any of them are compared.

    Conformers of one molecule must share a bonding graph. If they do not, either the files are not all the
    same compound or the bond tolerance is sitting on a boundary for some contact -- and in the second case a
    single perceived bond appearing or vanishing changes the automorphism group, which silently changes which
    conformers are found equivalent. Better to say so than to compare graphs that are not the same.
    """
    signatures = {}
    for entry in structures:
        bonds = frozenset(frozenset((atom, neighbour))
                          for atom, neighbours in entry['connectivity'].items()
                          for neighbour in neighbours)
        signatures.setdefault((tuple(entry['elements']), bonds), []).append(entry['name'])

    if len(signatures) <= 1:
        return True, []
    groups = sorted(signatures.values(), key=len, reverse=True)
    return False, groups


# ==================================================================================================================
# DEDUPLICATION ENGINE
# ==================================================================================================================
# Lifted verbatim from the NMR Gaussian Workbench, thresholds included, so a verdict here is the verdict that
# program would reach. The one adaptation is the input: the workbench takes connectivity from an SDF, while
# here it is perceived from the geometry above. Nothing in the comparison itself is changed.


HARTREE_TO_KCAL = 627.509474  # Conversion factor from Hartrees to kcal/mol
DEDUP_ENERGY_WINDOW = 0.20  # kcal/mol; maximum Gibbs free energy separation for two conformers to be considered the same minimum
DEDUP_RMSD_THRESHOLD = 0.10  # Angstrom; maximum symmetry-corrected Cartesian RMSD after optimal proper-rotation superposition. Validated against 30 compounds with vibrational frequencies as ground truth: any value in [0.0916, 0.1067] gives identical merges across all of them, so this sits inside a real empty gap in the data. Do NOT loosen it -- 7 of the 30 change their merge counts by 0.20
DEDUP_MAX_DEVIATION_THRESHOLD = 0.15  # Angstrom; largest single-atom displacement after superposition, blocking merges of structures that agree on average but differ sharply in one region
DEDUP_ENABLE_FREQUENCY_GATE = True  # Require vibrational spectra to agree before merging, when frequency data is available for both conformers. Independent of geometry (it comes from the Hessian), so it can contradict the geometric verdict rather than restating it
DEDUP_FREQUENCY_RMSD_THRESHOLD = 2.0  # cm^-1; maximum all-mode RMSD between two conformers' frequency lists. Rarely the binding constraint: averaging over ~110 modes, most of them conformation-independent stretches, dilutes a real single-mode shift by roughly tenfold
DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD = 3.0  # cm^-1; maximum difference in ANY single mode. This is the metric that actually discriminates, because it does not dilute
DEDUP_ENABLE_INERTIA_PREFILTER = True  # Screen pairs on principal moments of inertia (invariant to both orientation and numbering) before the exact comparison. Saves time; verified not to change any verdict
DEDUP_INERTIA_RELATIVE_TOLERANCE = 0.05  # Fractional agreement required of each principal moment to reach the exact comparison. Deliberately loose: this filter exists to save time, not to make decisions
DEDUP_ENABLE_ORBIT_FAST_PATH = True  # Resolve correspondences by orbit decomposition instead of enumerating the whole automorphism group; every result is validated as a true automorphism before use, so this can only be faster, never less correct
DEDUP_ORBIT_MIN_ANCHORS = 3  # Minimum uniquely-labelled atoms needed to bootstrap the fast path's rotation
DEDUP_ORBIT_MAX_ITERATIONS = 25  # Safety valve on the rotate/reassign alternation; it settles within a few rounds in practice
DEDUP_MAX_ORBIT_SEED_TRIALS = 720  # Cap on seed combinations tried when there are too few singleton atoms to anchor directly
DEDUP_MAX_AUTOMORPHISMS = 500000  # Enumeration cap. A truncated group can only OVER-estimate RMSD_sym, so duplicates may be missed, none invented
DEDUP_AUTOMORPHISM_NODE_BUDGET = 10000000  # Backtracking node budget; raised faster than the count cap because a search tree can exhaust it before reaching that cap
DEDUP_MAX_RING_SIZE = 10  # Largest ring perceived for the ring-membership graph invariant
DEDUP_DEFAULT_MASS = 12.011
DEDUP_ATOMIC_MASSES = {'H': 1.008, 'B': 10.81, 'C': 12.011, 'N': 14.007, 'O': 15.999, 'F': 18.998, 'Na': 22.990,
                       'Mg': 24.305, 'Al': 26.982, 'Si': 28.085, 'P': 30.974, 'S': 32.06, 'Cl': 35.45,
                       'K': 39.098, 'Ca': 40.078, 'Fe': 55.845, 'Zn': 65.38, 'Se': 78.971, 'Br': 79.904, 'I': 126.904}


def dedup_build_adjacency(atom_types, connectivity):
    """
    Adjacency as {atom: set(neighbours)} over 1-based atom numbers, from ngp2's simple_connectivity.

    Bond order is never consulted anywhere in this module. Degree already encodes hybridization (a multiply
    bonded carbon has fewer other neighbours), and ignoring order handles every resonance system uniformly
    instead of needing a normalization pass for aromatic rings, carboxylates and nitro groups separately.
    """
    atom_count = len(atom_types)
    adjacency = {atom: set() for atom in range(1, atom_count + 1)}
    for atom, neighbors in (connectivity or {}).items():
        if not (1 <= atom <= atom_count):
            continue
        for neighbor in neighbors:
            if 1 <= neighbor <= atom_count and neighbor != atom:
                adjacency[atom].add(neighbor)
                adjacency[neighbor].add(atom)
    return adjacency


def dedup_ring_membership(adjacency):
    """
    Smallest ring size through each atom, or 0 for acyclic atoms. A genuine graph invariant, so adding it to the
    refinement can only sharpen the partition correctly -- it can never split atoms a real automorphism would
    exchange.
    """
    smallest = {atom: 0 for atom in adjacency}
    for atom1 in adjacency:
        for atom2 in adjacency[atom1]:
            if atom2 <= atom1:
                continue
            previous = {atom1: None}
            queue = deque([atom1])
            while queue:
                current = queue.popleft()
                if current == atom2:
                    break
                for neighbor in adjacency[current]:
                    if current == atom1 and neighbor == atom2:
                        continue
                    if neighbor not in previous:
                        previous[neighbor] = current
                        queue.append(neighbor)
            if atom2 not in previous:
                continue
            path, node = [], atom2
            while node is not None:
                path.append(node)
                node = previous[node]
            if 3 <= len(path) <= DEDUP_MAX_RING_SIZE:
                for member in path:
                    if smallest[member] == 0 or len(path) < smallest[member]:
                        smallest[member] = len(path)
    return smallest


def dedup_invariant_keys(atom_types, adjacency):
    """The geometry-free per-atom invariants seeding the refinement."""
    rings = dedup_ring_membership(adjacency)
    return {atom: (atom_types[atom - 1], len(adjacency[atom]), rings[atom]) for atom in adjacency}


def dedup_refine_labels(adjacency, initial_keys):
    """
    Iterated neighbour-label refinement (Morgan / Weisfeiler-Leman).

    Labels are ranked from sorted signature content each round rather than assigned in encounter order, so they
    depend only on the graph and never on the order atoms happen to be stored in.
    """
    ranks = {key: rank for rank, key in enumerate(sorted(set(initial_keys.values())))}
    labels = {atom: ranks[initial_keys[atom]] for atom in adjacency}
    while True:
        signatures = {atom: (labels[atom], tuple(sorted(labels[neighbor] for neighbor in adjacency[atom])))
                      for atom in adjacency}
        ranks = {signature: rank for rank, signature in enumerate(sorted(set(signatures.values())))}
        updated = {atom: ranks[signatures[atom]] for atom in adjacency}
        if len(set(updated.values())) == len(set(labels.values())):
            return updated
        labels = updated


def dedup_traversal_order(adjacency):
    """Order atoms so each is adjacent to something already placed, which keeps the search's candidate lists short."""
    order, seen = [], set()
    for start in sorted(adjacency):
        if start in seen:
            continue
        seen.add(start)
        order.append(start)
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for neighbor in sorted(adjacency[current]):
                if neighbor not in seen:
                    seen.add(neighbor)
                    order.append(neighbor)
                    queue.append(neighbor)
    return order


def dedup_automorphism_permutations(adjacency, labels, atom_count):
    """
    The automorphism group as zero-based permutation arrays, identity first.

    Refinement labels supply the candidate lists so the search only ever tries atoms no graph invariant can
    distinguish, and edge consistency is checked in both directions so a completed map is a true automorphism.
    Identity leading matters in practice: conformers from one Gaussian batch share their numbering, so the first
    superposition tried for a genuine duplicate is usually the one that succeeds.

    Returns (permutations, truncated). A truncated group can only make RMSD_sym an OVER-estimate, so duplicates
    may be missed but none can be invented.
    """
    by_label = defaultdict(list)
    for atom in sorted(adjacency):
        by_label[labels[atom]].append(atom)

    order = dedup_traversal_order(adjacency)
    mapping, reverse, results = {}, {}, []
    budget = [DEDUP_AUTOMORPHISM_NODE_BUDGET]
    truncated = [False]

    def backtrack(position):
        if position == len(order):
            results.append(dict(mapping))
            if len(results) >= DEDUP_MAX_AUTOMORPHISMS:
                truncated[0] = True
            return
        atom = order[position]
        for candidate in by_label[labels[atom]]:
            if candidate in reverse:
                continue
            budget[0] -= 1
            if budget[0] <= 0:
                truncated[0] = True
                return
            if any(mapping[neighbor] not in adjacency[candidate]
                   for neighbor in adjacency[atom] if neighbor in mapping):
                continue
            if any(reverse[neighbor] not in adjacency[atom]
                   for neighbor in adjacency[candidate] if neighbor in reverse):
                continue
            mapping[atom] = candidate
            reverse[candidate] = atom
            backtrack(position + 1)
            del mapping[atom]
            del reverse[candidate]
            if truncated[0] and len(results) >= DEDUP_MAX_AUTOMORPHISMS:
                return

    backtrack(0)

    identity = tuple(range(atom_count))
    permutations, seen = [], set()
    for found in results:
        permutation = tuple(found[atom] - 1 for atom in range(1, atom_count + 1))
        if permutation not in seen:
            seen.add(permutation)
            permutations.append(permutation)
    if identity in seen:
        permutations.remove(identity)
        permutations.insert(0, identity)
    return permutations, truncated[0]


def dedup_centred_with_norm(coordinates):
    """Centered coordinates plus the sum of their squared norms, computed together since callers need both."""
    points = np.asarray(coordinates, dtype=float)
    points = points - points.mean(axis=0)
    return points, float((points ** 2).sum())


def dedup_superposition_from_centered(a, norm_a, b, norm_b, want_deviations=False):
    """
    Optimal proper-rotation superposition RMSD by Horn's quaternion method, for already-centered coordinates.

    The 4x4 matrix built from the correlation matrix has the optimal rotation quaternion as its largest
    eigenvector and the RMSD follows from the largest eigenvalue directly. Because rotations are parametrized by
    quaternions the result is always a proper rotation: a reflection cannot be produced, so the determinant-sign
    correction an SVD implementation needs is structurally unnecessary here.

    Taking already-centered input lets the caller center each side once and merely reindex per permutation --
    permuting labels does not move the centroid, so the two operations commute.
    """
    count = len(a)
    if count == 0:
        return 0.0, 0.0

    correlation = a.T.dot(b)
    (sxx, sxy, sxz), (syx, syy, syz), (szx, szy, szz) = correlation

    quaternion_matrix = np.array([
        [sxx + syy + szz, syz - szy,        szx - sxz,        sxy - syx],
        [syz - szy,       sxx - syy - szz,  sxy + syx,        szx + sxz],
        [szx - sxz,       sxy + syx,       -sxx + syy - szz,  syz + szy],
        [sxy - syx,       szx + sxz,        syz + szy,       -sxx - syy + szz],
    ], dtype=float)
    eigenvalues, eigenvectors = np.linalg.eigh(quaternion_matrix)
    best_index = int(np.argmax(eigenvalues))
    largest = float(eigenvalues[best_index])

    rmsd = math.sqrt(max(0.0, (norm_a + norm_b - 2.0 * largest)) / count)
    if not want_deviations:
        return rmsd, None

    qw, qx, qy, qz = (float(eigenvectors[0][best_index]), float(eigenvectors[1][best_index]),
                      float(eigenvectors[2][best_index]), float(eigenvectors[3][best_index]))
    length = math.sqrt(qw * qw + qx * qx + qy * qy + qz * qz)
    if length < 1e-12:
        return rmsd, None
    qw, qx, qy, qz = qw / length, qx / length, qy / length, qz / length

    forward = np.array([
        [qw*qw + qx*qx - qy*qy - qz*qz, 2.0*(qx*qy - qw*qz),           2.0*(qx*qz + qw*qy)],
        [2.0*(qx*qy + qw*qz),           qw*qw - qx*qx + qy*qy - qz*qz, 2.0*(qy*qz - qw*qx)],
        [2.0*(qx*qz - qw*qy),           2.0*(qy*qz + qw*qx),           qw*qw - qx*qx - qy*qy + qz*qz],
    ], dtype=float)

    # The quaternion expresses the rotation carrying the reference onto the target, so the TRANSPOSE brings the
    # target back onto the reference. Applying it the other way round leaves the eigenvalue RMSD untouched while
    # producing a wrong displacement -- invisible unless the two are cross-checked, which is what the guard below
    # does.
    rotated = b.dot(forward)
    differences = a - rotated
    squared = (differences ** 2).sum(axis=1)
    maximum = float(np.sqrt(squared).max())
    explicit_rmsd = math.sqrt(float(squared.sum()) / count)
    if abs(explicit_rmsd - rmsd) > max(1e-6, 1e-6 * max(explicit_rmsd, rmsd)):
        raise ArithmeticError(
            f"superposition inconsistency: eigenvalue RMSD {rmsd:.8f} disagrees with the RMSD implied by the "
            f"per-atom displacements {explicit_rmsd:.8f}")
    return rmsd, maximum


def dedup_symmetry_corrected_rmsd(coords_a, coords_b, permutations):
    """
    Minimum superposition RMSD over the automorphism group.

    Both sides are centered once before the loop; each permutation only reindexes already-centered points. The
    loop stops as soon as a permutation clears both thresholds, since one qualifying correspondence settles the
    question, and the identity permutation is tried first so a duplicate written with consistent numbering costs
    a single superposition.
    """
    a, norm_a = dedup_centred_with_norm(coords_a)
    b, norm_b = dedup_centred_with_norm(coords_b)

    best_rmsd, best_index, best_reordered = None, None, None
    for index, permutation in enumerate(permutations):
        reordered = b[list(permutation)]
        rmsd, _ = dedup_superposition_from_centered(a, norm_a, reordered, norm_b)
        if best_rmsd is None or rmsd < best_rmsd:
            best_rmsd, best_index, best_reordered = rmsd, index, reordered
        if rmsd <= DEDUP_RMSD_THRESHOLD:
            exact_rmsd, deviation = dedup_superposition_from_centered(a, norm_a, reordered, norm_b, True)
            if deviation is not None and deviation <= DEDUP_MAX_DEVIATION_THRESHOLD:
                return exact_rmsd, deviation, index, True
    if best_index is None:
        return None, None, None, False
    rmsd, deviation = dedup_superposition_from_centered(a, norm_a, best_reordered, norm_b, True)
    return rmsd, deviation, best_index, False


def dedup_hungarian_assignment(cost_matrix):
    """
    Optimal assignment minimizing total cost, by the Kuhn-Munkres algorithm.

    Every use here is on one automorphism orbit (a methyl's 3 hydrogens, a tert-butyl's 9, a ring's handful of
    swappable positions) rather than the whole molecule, so n is always small and the cubic cost is negligible.
    That is what makes the orbit-decomposition path cheap where enumerating the orbits' combined Cartesian
    product is not.
    """
    n = len(cost_matrix)
    if n == 0:
        return []
    INF = float('inf')
    u = [0.0] * (n + 1)
    v = [0.0] * (n + 1)
    p = [0] * (n + 1)
    way = [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [INF] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], INF, -1
            for j in range(1, n + 1):
                if used[j]:
                    continue
                cur = cost_matrix[i0 - 1][j - 1] - u[i0] - v[j]
                if cur < minv[j]:
                    minv[j] = cur
                    way[j] = j0
                if minv[j] < delta:
                    delta = minv[j]
                    j1 = j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while j0:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
    assignment = [0] * n
    for j in range(1, n + 1):
        if p[j]:
            assignment[p[j] - 1] = j - 1
    return assignment


def dedup_kabsch_rotation(points_a, points_b):
    """
    The optimal proper rotation carrying points_b onto points_a, by Horn's quaternion method. Needed by the
    orbit-guided path, which applies the rotation directly to find each orbit's nearest correspondence rather
    than only reporting a final RMSD. Returns None when there are too few points to determine a rotation.
    """
    if len(points_a) < 3:
        return None
    a, _ = dedup_centred_with_norm(points_a)
    b, _ = dedup_centred_with_norm(points_b)
    correlation = a.T.dot(b)
    (sxx, sxy, sxz), (syx, syy, syz), (szx, szy, szz) = correlation
    quaternion_matrix = np.array([
        [sxx + syy + szz, syz - szy,        szx - sxz,        sxy - syx],
        [syz - szy,       sxx - syy - szz,  sxy + syx,        szx + sxz],
        [szx - sxz,       sxy + syx,       -sxx + syy - szz,  syz + szy],
        [sxy - syx,       szx + sxz,        syz + szy,       -sxx - syy + szz],
    ], dtype=float)
    eigenvalues, eigenvectors = np.linalg.eigh(quaternion_matrix)
    best_index = int(np.argmax(eigenvalues))
    qw, qx, qy, qz = (float(eigenvectors[0][best_index]), float(eigenvectors[1][best_index]),
                      float(eigenvectors[2][best_index]), float(eigenvectors[3][best_index]))
    length = math.sqrt(qw*qw + qx*qx + qy*qy + qz*qz)
    if length < 1e-12:
        return None
    qw, qx, qy, qz = qw/length, qx/length, qy/length, qz/length
    forward = np.array([
        [qw*qw + qx*qx - qy*qy - qz*qz, 2.0*(qx*qy - qw*qz),           2.0*(qx*qz + qw*qy)],
        [2.0*(qx*qy + qw*qz),           qw*qw - qx*qx + qy*qy - qz*qz, 2.0*(qy*qz - qw*qx)],
        [2.0*(qx*qz - qw*qy),           2.0*(qy*qz + qw*qx),           qw*qw - qx*qx - qy*qy + qz*qz],
    ], dtype=float)
    return forward


def dedup_orbit_guided_correspondence(adjacency, coords_a, coords_b, atoms_by_label):
    """
    Find the correspondence between two conformers directly, without enumerating the automorphism group.

    Several independent rotatable groups multiply their automorphism counts together, so |Aut(G)| reaches the
    hundreds of thousands for unremarkable drug-like molecules, and every element costs one superposition to try.
    This path avoids materializing the group at all for such cases.

    THE IDEA: refinement labels partition atoms into classes -- singletons (forced to map to themselves in any
    automorphism) and larger orbits. For a FIXED rotation the sum-of-squared-displacements objective separates
    exactly along those classes, because each atom's term depends only on which same-class atom it pairs with.
    So the optimal assignment within each class is found by ordinary bipartite matching on that class alone,
    independent of every other class -- no need for the combined Cartesian product that made the full group
    explode. The rotation and the assignment are mutually dependent, resolved by ICP-style alternation: seed a
    rotation from the singletons, assign every other class optimally under it, refit the rotation, repeat. Each
    half is exact given the other, so the total squared displacement can only decrease or hold.

    When there are too few singletons to seed from (a symmetric structure can have none), the smallest available
    classes are used as the seed instead, trying each of their internal permutations in turn and keeping the best
    validated result.

    SAFETY: this only PROPOSES a correspondence. Every candidate is validated as a genuine graph automorphism
    before its RMSD is computed, so a molecule where the heuristic does not apply cleanly simply fails validation
    and the caller falls back to exact enumeration. This path can make a comparison faster, never less correct.
    """
    atom_count = len(coords_a)
    classes_by_size = sorted(atoms_by_label.values(), key=len)
    singleton_atoms = [atoms[0] for atoms in classes_by_size if len(atoms) == 1]

    def run_from_seed(seed_correspondence, remaining_classes):
        correspondence = dict(seed_correspondence)
        previous = None
        for _ in range(DEDUP_ORBIT_MAX_ITERATIONS):
            anchor_a = [coords_a[atom - 1] for atom in correspondence]
            anchor_b = [coords_b[correspondence[atom] - 1] for atom in correspondence]
            rotation = dedup_kabsch_rotation(anchor_a, anchor_b)
            if rotation is None:
                return None
            centre_b = np.asarray(coords_b, dtype=float).mean(axis=0)
            centre_a = np.asarray(coords_a, dtype=float).mean(axis=0)
            updated = dict(seed_correspondence)
            for atoms_in_class in remaining_classes:
                shifted = np.asarray([coords_b[atom - 1] for atom in atoms_in_class], dtype=float) - centre_b
                rotated = shifted.dot(rotation) + centre_a
                cost = [[float(((np.asarray(coords_a[a - 1], dtype=float) - centre_a - (rotated[k] - centre_a)) ** 2).sum())
                        for k in range(len(atoms_in_class))] for a in atoms_in_class]
                assignment = dedup_hungarian_assignment(cost)
                for row, atom_a in enumerate(atoms_in_class):
                    updated[atom_a] = atoms_in_class[assignment[row]]
            if updated == previous:
                correspondence = updated
                break
            previous, correspondence = correspondence, updated
        else:
            return None

        if len(correspondence) != atom_count:
            return None
        permutation = [0] * atom_count
        for atom_a, atom_b in correspondence.items():
            permutation[atom_a - 1] = atom_b - 1
        for atom_a in range(1, atom_count + 1):
            image = permutation[atom_a - 1] + 1
            if {permutation[n - 1] + 1 for n in adjacency[atom_a]} != adjacency[image]:
                return None
        return tuple(permutation)

    def best_of(candidates):
        candidates = [c for c in candidates if c is not None]
        if not candidates:
            return None
        a, norm_a = dedup_centred_with_norm(coords_a)
        b_all = np.asarray(coords_b, dtype=float)
        best_permutation, best_rmsd = None, None
        for permutation in candidates:
            b, norm_b = dedup_centred_with_norm(b_all[list(permutation)])
            rmsd, _ = dedup_superposition_from_centered(a, norm_a, b, norm_b)
            if best_rmsd is None or rmsd < best_rmsd:
                best_rmsd, best_permutation = rmsd, permutation
            if best_rmsd <= DEDUP_RMSD_THRESHOLD * 0.1:
                break
        return best_permutation

    if len(singleton_atoms) >= DEDUP_ORBIT_MIN_ANCHORS:
        seed = {atom: atom for atom in singleton_atoms}
        remaining = [atoms for atoms in classes_by_size if len(atoms) > 1]
        return best_of([run_from_seed(seed, remaining)])

    seed_classes, trial_budget = [], 1
    for atoms_in_class in classes_by_size:
        candidate_budget = trial_budget * math.factorial(len(atoms_in_class))
        if candidate_budget > DEDUP_MAX_ORBIT_SEED_TRIALS and seed_classes:
            break
        seed_classes.append(atoms_in_class)
        trial_budget = candidate_budget
        if sum(len(c) for c in seed_classes) >= DEDUP_ORBIT_MIN_ANCHORS:
            break
    if sum(len(c) for c in seed_classes) < 3 or trial_budget > DEDUP_MAX_ORBIT_SEED_TRIALS:
        return None

    remaining_classes = [atoms for atoms in classes_by_size if atoms not in seed_classes]
    results = []
    for combo in itertools.product(*(itertools.permutations(atoms) for atoms in seed_classes)):
        seed = {}
        for original, permuted in zip(seed_classes, combo):
            seed.update(dict(zip(original, permuted)))
        result = run_from_seed(seed, remaining_classes)
        if result is not None:
            results.append(result)
    return best_of(results)


def dedup_principal_moments(atom_types, coordinates):
    """
    Principal moments of inertia, sorted ascending.

    Eigenvalues of the inertia tensor are invariant to BOTH orientation and atom numbering, so two writings of
    one geometry give the same three numbers with no permutation reasoning at all. That makes them an ideal
    cheap screen ahead of the exact comparison.
    """
    masses = np.array([DEDUP_ATOMIC_MASSES.get(symbol, DEDUP_DEFAULT_MASS) for symbol in atom_types], dtype=float)
    points = np.asarray(coordinates, dtype=float)
    centre = (masses[:, None] * points).sum(axis=0) / masses.sum()
    shifted = points - centre
    x, y, z = shifted[:, 0], shifted[:, 1], shifted[:, 2]
    tensor = np.array([
        [float((masses * (y*y + z*z)).sum()), -float((masses * x * y).sum()), -float((masses * x * z).sum())],
        [-float((masses * x * y).sum()), float((masses * (x*x + z*z)).sum()), -float((masses * y * z).sum())],
        [-float((masses * x * z).sum()), -float((masses * y * z).sum()), float((masses * (x*x + y*y)).sum())],
    ], dtype=float)
    return sorted(float(v) for v in np.linalg.eigvalsh(tensor))


def dedup_moments_compatible(moments_a, moments_b):
    """Whether two structures agree closely enough in their principal moments to be worth an exact comparison."""
    for first, second in zip(moments_a, moments_b):
        scale = max(abs(first), abs(second), 1e-9)
        if abs(first - second) / scale > DEDUP_INERTIA_RELATIVE_TOLERANCE:
            return False
    return True


def dedup_frequency_agreement(frequencies_a, frequencies_b):
    """
    Compare two conformers' vibrational spectra mode by mode.

    Two structures relaxed into the same basin have essentially the same normal modes, agreeing to within
    optimization-convergence noise. Two structures in different basins have different force constants and
    therefore different frequencies, most visibly in the low-frequency torsional modes that describe the very
    motions distinguishing conformers. This is independent evidence: it comes from the Hessian at each geometry
    and never from any distance comparison, so it can confirm or contradict the geometric verdict rather than
    restating it.

    Returns (all_rmsd, max_difference, comparable). comparable is False when the mode counts differ, which means
    the structures are not the same molecule at all (3N-6 is fixed by atom count) -- comparing them would be
    meaningless rather than merely inaccurate.

    NOTE ON WHICH METRIC BINDS: the all-mode RMSD dilutes badly. A molecule of this size has ~110 modes, of which
    ~25 are C-H and O-H stretches that barely shift between conformers, so a genuine conformational difference
    moving one low mode by 10 cm^-1 averages down to about 1 cm^-1 across all modes and slips under any sensible
    RMSD cutoff. The MAX single-mode difference does not dilute and is what actually discriminates; the RMSD is
    retained as a secondary guard because requiring both is strictly more conservative than either alone.
    """
    if len(frequencies_a) != len(frequencies_b) or not frequencies_a:
        return None, None, False
    a = np.sort(np.asarray(frequencies_a, dtype=float))
    b = np.sort(np.asarray(frequencies_b, dtype=float))
    differences = np.abs(a - b)
    return float(math.sqrt(float((differences ** 2).mean()))), float(differences.max()), True


def deduplicate_conformers(conformer_numbers, energy_by_conformer, coordinates_by_conformer,
                           atom_types, connectivity, frequencies_by_conformer=None):
    """
    Identify conformers that optimized to a minimum already represented by a lower-energy conformer.

    A pair is merged only when EVERY gate agrees: the energy gap is within DEDUP_ENERGY_WINDOW, the
    symmetry-corrected RMSD is within DEDUP_RMSD_THRESHOLD with no single atom displaced by more than
    DEDUP_MAX_DEVIATION_THRESHOLD, and -- when frequency data is available for both -- the vibrational spectra
    agree within DEDUP_FREQUENCY_RMSD_THRESHOLD overall and DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD in every single
    mode. Requiring all of them is deliberately conservative: a merge silently deletes a conformer and hands its
    Boltzmann weight to a structure that may not be it, which is not recoverable from the output, whereas
    retaining a redundant conformer merely inflates the ensemble slightly.

    Conformers are pooled from the lowest energy upward, so the survivor of any merge is always the more
    populated one, and each candidate is compared only against established representatives -- never against
    another duplicate -- so a chain of individually similar structures cannot bridge two genuinely different
    minima into one cluster.

    Returns (survivors, duplicate_records, ungated_conformers, diagnostics).
    """
    atom_count = len(atom_types)
    adjacency = dedup_build_adjacency(atom_types, connectivity)
    labels = dedup_refine_labels(adjacency, dedup_invariant_keys(atom_types, adjacency))
    permutations, truncated = dedup_automorphism_permutations(adjacency, labels, atom_count)
    atoms_by_label = defaultdict(list)
    for atom, label in labels.items():
        atoms_by_label[label].append(atom)
    atoms_by_label = dict(atoms_by_label)

    diagnostics = {'group_size': len(permutations), 'truncated': truncated, 'atom_count': atom_count,
                   'frequency_gated_pairs': 0, 'frequency_blocked_pairs': 0, 'frequency_unavailable': 0,
                   'frequency_blocked_records': [],
                   'energy_screened': 0, 'inertia_screened': 0, 'exact_comparisons': 0}

    prepared, ungated = {}, []
    for conformer in conformer_numbers:
        coordinates = coordinates_by_conformer.get(conformer)
        energy = energy_by_conformer.get(conformer)
        if coordinates is None or energy is None or len(coordinates) != atom_count:
            ungated.append(conformer)
            continue
        prepared[conformer] = {'coordinates': np.asarray(coordinates, dtype=float), 'energy': energy,
                               'moments': dedup_principal_moments(atom_types, coordinates)}
    if not prepared:
        return list(conformer_numbers), [], sorted(ungated), diagnostics

    minimum_energy = min(entry['energy'] for entry in prepared.values())
    for entry in prepared.values():
        entry['relative'] = (entry['energy'] - minimum_energy) * HARTREE_TO_KCAL

    ordered = sorted(prepared, key=lambda c: (prepared[c]['relative'], c))
    representatives, duplicate_records = [], []

    for conformer in ordered:
        candidate = prepared[conformer]
        matched = None
        for representative in representatives:
            reference = prepared[representative]
            gap = candidate['relative'] - reference['relative']
            if gap > DEDUP_ENERGY_WINDOW:
                diagnostics['energy_screened'] += 1
                continue
            if DEDUP_ENABLE_INERTIA_PREFILTER and not dedup_moments_compatible(reference['moments'], candidate['moments']):
                diagnostics['inertia_screened'] += 1
                continue

            diagnostics['exact_comparisons'] += 1
            rmsd = deviation = None
            permutation_label = None
            is_match = False
            if DEDUP_ENABLE_ORBIT_FAST_PATH and atoms_by_label:
                fast = dedup_orbit_guided_correspondence(adjacency, reference['coordinates'],
                                                         candidate['coordinates'], atoms_by_label)
                if fast is not None:
                    a, norm_a = dedup_centred_with_norm(reference['coordinates'])
                    b, norm_b = dedup_centred_with_norm(candidate['coordinates'][list(fast)])
                    rmsd, deviation = dedup_superposition_from_centered(a, norm_a, b, norm_b, True)
                    permutation_label = 'orbit-guided'
                    is_match = (rmsd <= DEDUP_RMSD_THRESHOLD and deviation is not None
                                and deviation <= DEDUP_MAX_DEVIATION_THRESHOLD)
            if permutation_label is None:
                rmsd, deviation, permutation_label, is_match = dedup_symmetry_corrected_rmsd(
                    reference['coordinates'], candidate['coordinates'], permutations)
            if not is_match:
                continue

            # Independent vibrational check, applied last because it can only ever BLOCK a merge the geometry
            # already accepted, never create one
            frequency_note = 'not available'
            if DEDUP_ENABLE_FREQUENCY_GATE and frequencies_by_conformer:
                spectra_a = frequencies_by_conformer.get(representative)
                spectra_b = frequencies_by_conformer.get(conformer)
                if spectra_a and spectra_b:
                    freq_rmsd, freq_max, comparable = dedup_frequency_agreement(spectra_a, spectra_b)
                    if comparable:
                        if (freq_rmsd > DEDUP_FREQUENCY_RMSD_THRESHOLD
                                or freq_max > DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD):
                            diagnostics['frequency_blocked_pairs'] += 1
                            # Recorded individually: a blocked pair is one the geometry accepted and the
                            # spectra rejected, which is exactly the case worth being able to inspect. It
                            # leaves no other trace, since it simply never becomes a duplicate record
                            diagnostics['frequency_blocked_records'].append({
                                'candidate': conformer, 'representative': representative,
                                'energy_gap': gap, 'rmsd': rmsd, 'max_deviation': deviation,
                                'freq_rmsd': freq_rmsd, 'freq_max': freq_max})
                            continue
                        diagnostics['frequency_gated_pairs'] += 1
                        frequency_note = f"RMSD {freq_rmsd:.3f}, max {freq_max:.3f} cm^-1"
                    else:
                        diagnostics['frequency_unavailable'] += 1
                else:
                    diagnostics['frequency_unavailable'] += 1

            record = {'duplicate': conformer, 'representative': representative, 'energy_gap': gap,
                      'rmsd': rmsd, 'max_deviation': deviation, 'permutation': permutation_label,
                      'frequency': frequency_note}
            if matched is None or rmsd < matched['rmsd']:
                matched = record

        if matched is not None:
            duplicate_records.append(matched)
        else:
            representatives.append(conformer)

    survivors = sorted(representatives) + sorted(ungated)
    return sorted(set(survivors)), duplicate_records, sorted(ungated), diagnostics


# ==================================================================================================================
# DRIVER
# ==================================================================================================================

def collect_log_files(arguments):
    """Resolve command-line arguments to a list of log files."""
    if not arguments:
        return sorted(glob.glob('*.log'))
    files = []
    for item in arguments:
        if os.path.isdir(item):
            files.extend(sorted(glob.glob(os.path.join(item, '*.log'))))
        elif os.path.isfile(item):
            files.append(item)
        else:
            files.extend(sorted(glob.glob(item)))
    seen, unique = set(), []
    for path in files:
        absolute = os.path.abspath(path)
        if absolute not in seen:
            seen.add(absolute)
            unique.append(path)
    return unique


def analyse(paths, tolerance=BOND_TOLERANCE, skip_imaginary=True, report_lines=None):
    """Read every log, deduplicate, and print the result. Returns (survivors, duplicates, structures)."""

    def say(text=""):
        print(text)
        if report_lines is not None:
            report_lines.append(text)

    say("=" * 100)
    say("Conformer deduplication from Gaussian opt freq output")
    say("=" * 100)
    say(f"Files: {len(paths)}")
    say("")

    structures, rejected = [], []
    for path in paths:
        entry = read_gaussian_log(path)
        if entry is None:
            continue
        if not entry['coordinates']:
            rejected.append((entry['name'], "; ".join(entry['problems']) or 'no geometry'))
            continue
        if entry['gibbs'] is None:
            rejected.append((entry['name'], "no Gibbs free energy; deduplication needs it for the energy gate"))
            continue
        if skip_imaginary and entry['imaginary_count']:
            rejected.append((entry['name'], f"{entry['imaginary_count']} imaginary frequency/frequencies"))
            continue
        if entry.get('reported_connectivity'):
            # Gaussian's own bond list, complete with no decision to make
            connectivity = {atom: [] for atom in range(1, len(entry['elements']) + 1)}
            connectivity.update({atom: list(found)
                                 for atom, found in entry['reported_connectivity'].items()})
            entry['connectivity'] = connectivity
            entry['connectivity_source'] = 'Initial Parameters'
        else:
            entry['connectivity'] = perceive_bonds(entry['elements'], entry['coordinates'], tolerance)
            entry['connectivity_source'] = 'covalent radii'
        structures.append(entry)

    if rejected:
        say(f"Excluded {len(rejected)} file(s):")
        for name, reason in rejected:
            say(f"  {name}: {reason}")
        say("")

    if len(structures) < 2:
        say(f"Only {len(structures)} usable conformer(s); nothing to compare.")
        return [entry['name'] for entry in structures], [], structures

    say(f"Usable conformers: {len(structures)}")
    say(f"Skeleton: {describe_skeleton(structures[0]['elements'], structures[0]['connectivity'])}")

    sources = defaultdict(int)
    for entry in structures:
        sources[entry.get('connectivity_source', 'unknown')] += 1
    for source, count in sorted(sources.items()):
        say(f"Connectivity from {source}: {count} conformer(s)")
    if sources.get('covalent radii'):
        say(f"  (covalent-radii perception used a {tolerance:.2f} A tolerance; those logs had no "
            f"Initial Parameters section)")

    consistent, groups = check_skeleton_consistency(structures)
    if not consistent:
        say("")
        say("WARNING: these conformers do not all share one bonding skeleton.")
        say("  Conformers of one molecule must. Either the files are not all the same compound, or a contact")
        say("  is sitting on the bond-perception boundary and is being seen as a bond in some files and not")
        say("  others. Because the comparison rests on the molecular graph, a differing graph means the")
        say("  structures are not being compared on equal terms.")
        for index, group in enumerate(groups, start=1):
            listed = ", ".join(group[:8]) + (f", and {len(group) - 8} more" if len(group) > 8 else "")
            say(f"    group {index} ({len(group)} conformer(s)): {listed}")
        if sources.get('covalent radii'):
            say("  Try --tolerance to see whether the split moves; if it does, the boundary is the cause.")
        else:
            say("  Every skeleton here came from Gaussian's own Initial Parameters table, so this is not a")
            say("  perception threshold: the structures genuinely differ in what is bonded to what.")
    say("")

    conformer_numbers, energies, coordinates, frequencies = [], {}, {}, {}
    for index, entry in enumerate(structures, start=1):
        conformer_numbers.append(index)
        energies[index] = entry['gibbs']
        coordinates[index] = entry['coordinates']
        if entry['frequencies']:
            frequencies[index] = entry['frequencies']
        entry['number'] = index

    lowest = min(energies.values())
    say("Conformers, by energy:")
    say(f"  {'#':>4}  {'name':<34}{'dG (kcal/mol)':>15}{'modes':>8}")
    say("  " + "-" * 62)
    for index in sorted(conformer_numbers, key=lambda i: energies[i]):
        entry = structures[index - 1]
        relative = (energies[index] - lowest) * HARTREE_TO_KCAL
        say(f"  {index:>4}  {entry['name']:<34}{relative:>15.4f}{len(entry['frequencies']):>8}")
    say("")

    missing_frequencies = [i for i in conformer_numbers if i not in frequencies]
    if missing_frequencies:
        say(f"NOTE: {len(missing_frequencies)} conformer(s) have no frequencies, so the vibrational gate")
        say("      cannot apply to them and they are judged on energy and geometry alone.")
        say("")

    say("Gates (a pair must satisfy every one to be called the same minimum):")
    say(f"  Gibbs free energy separation  <= {DEDUP_ENERGY_WINDOW:.2f} kcal/mol")
    say(f"  Symmetry-corrected RMSD       <= {DEDUP_RMSD_THRESHOLD:.2f} A")
    say(f"  Largest single-atom deviation <= {DEDUP_MAX_DEVIATION_THRESHOLD:.2f} A")
    say(f"  Vibrational spectra           <= {DEDUP_FREQUENCY_RMSD_THRESHOLD:.1f} cm^-1 overall and "
        f"{DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD:.1f} cm^-1 in any single mode")
    say("")

    survivors, duplicates, ungated, diagnostics = deduplicate_conformers(
        conformer_numbers, energies, coordinates,
        structures[0]['elements'], structures[0]['connectivity'], frequencies)

    say(f"Automorphism group: {diagnostics['group_size']} graph-legal relabelling(s)"
        + ("  [enumeration hit its cap]" if diagnostics['truncated'] else ""))
    say(f"Pairs screened on energy: {diagnostics['energy_screened']}, "
        f"on moments of inertia: {diagnostics['inertia_screened']}, "
        f"compared exactly: {diagnostics['exact_comparisons']}")
    if diagnostics['frequency_gated_pairs'] or diagnostics['frequency_blocked_pairs']:
        say(f"Frequency gate: {diagnostics['frequency_gated_pairs']} merge(s) confirmed, "
            f"{diagnostics['frequency_blocked_pairs']} blocked")
    say("")

    say("=" * 100)
    if not duplicates:
        say(f"RESULT: no duplicates. All {len(structures)} conformers are distinct minima.")
    else:
        say(f"RESULT: {len(duplicates)} duplicate(s) among {len(structures)} conformers; "
            f"{len(survivors)} distinct minima remain.")
    say("=" * 100)
    say("")

    if duplicates:
        say("Duplicates (each is the same minimum as the conformer it is matched to, which is kept):")
        say(f"  {'duplicate':<34}{'same as':<34}{'dE':>9}{'RMSD':>9}{'max dev':>9}   frequencies")
        say("  " + "-" * 112)
        for record in sorted(duplicates, key=lambda r: r['duplicate']):
            duplicate_name = structures[record['duplicate'] - 1]['name']
            representative_name = structures[record['representative'] - 1]['name']
            say(f"  {duplicate_name:<34}{representative_name:<34}"
                f"{record['energy_gap']:>9.4f}{record['rmsd']:>9.4f}{record['max_deviation']:>9.4f}"
                f"   {record.get('frequency', 'not available')}")
        say("")

    blocked = diagnostics.get('frequency_blocked_records') or []
    if blocked:
        say("Pairs the geometry accepted but the frequencies rejected:")
        say("  These satisfied every geometric criterion, but their vibrational spectra differ. Frequencies")
        say("  come from the Hessian rather than from any distance comparison, so this is independent")
        say("  evidence that the two are different minima despite very similar geometries.")
        say(f"  {'candidate':<34}{'against':<34}{'RMSD':>9}{'freq RMSD':>12}{'freq max':>11}")
        say("  " + "-" * 112)
        for record in sorted(blocked, key=lambda r: r['candidate']):
            say(f"  {structures[record['candidate'] - 1]['name']:<34}"
                f"{structures[record['representative'] - 1]['name']:<34}"
                f"{record['rmsd']:>9.4f}{record['freq_rmsd']:>12.3f}{record['freq_max']:>11.3f}")
        say("")

    say("Distinct minima to keep:")
    for index in sorted(survivors, key=lambda i: energies.get(i, 0.0)):
        entry = structures[index - 1]
        relative = (energies[index] - lowest) * HARTREE_TO_KCAL
        say(f"  {entry['name']:<40}{relative:>10.4f} kcal/mol")

    return survivors, duplicates, structures


def main():
    parser = argparse.ArgumentParser(
        description="Find duplicate conformers among Gaussian opt freq log files.",
        epilog="Files may be given individually, as folders, or as glob patterns. "
               "With no arguments, every .log in the current folder is used.")
    parser.add_argument('inputs', nargs='*', help="log files, folders or patterns")
    parser.add_argument('--report', metavar='FILE', help="also write the full output to this file")
    parser.add_argument('--tolerance', type=float, default=BOND_TOLERANCE,
                        help=f"bond perception tolerance in Angstrom over the sum of covalent radii "
                             f"(default {BOND_TOLERANCE})")
    parser.add_argument('--keep-imaginary', action='store_true',
                        help="include conformers with imaginary frequencies, which are saddle points rather "
                             "than minima and are excluded by default")
    arguments = parser.parse_args()

    paths = collect_log_files(arguments.inputs)
    if not paths:
        print("No log files found.")
        return 1

    report_lines = [] if arguments.report else None
    analyse(paths, tolerance=arguments.tolerance,
            skip_imaginary=not arguments.keep_imaginary, report_lines=report_lines)

    if arguments.report:
        try:
            with open(arguments.report, 'w', encoding='utf-8') as handle:
                handle.write("\n".join(report_lines) + "\n")
            print(f"\nReport written to {arguments.report}")
        except OSError as error:
            print(f"\nCould not write the report: {error}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
