# CDAR 2.0.2 — native Rust edition

CDAR compares calculated and measured circular-dichroism spectra for
absolute-configuration analysis. This project is a ground-up Rust migration of
the supplied Python/Tkinter application, with both of its scientific modes:

- Electronic UV/ECD from Gaussian optimization and excited-state calculations
- Vibrational IR/VCD from Gaussian optimization and frequency calculations

The application is native and cross-platform. It does not embed Python or call
NumPy, SciPy, Matplotlib, or Tk.

## Build and run

Install Rust 1.95 or newer, then run:

```bash
cargo run --release
```

Build an optimized executable without launching it:

```bash
cargo build --release
```

The executable is written to `target/release/cdar` (`cdar.exe` on Windows).

On Linux, file dialogs use the XDG desktop portal. A normal GNOME, KDE, or
similar desktop installation already supplies a compatible portal backend.

## Test

```bash
cargo test
```

The regression suite covers energy/wavelength conversion, normalized
broadening, Boltzmann weights, exact and mirrored ECD/VCD similarity limits,
proper-rotation and symmetry-corrected RMSD, all five de-duplication gates, synthetic
UV fitting, delimited experimental input, representative Gaussian electronic
and vibrational parsers, fitted-state legend exports, and real SVG/PDF/PNG
generation.

## Using CDAR

CDAR first presents the supplied square `logo.png` in a frameless, taskbar-free
native window centered on the monitor for 1.5 seconds at half the former splash
dimensions. The artwork is opaque and fills the viewport while the native
window supplies the visible rounded corners. The splash contains only the artwork; the normal decorated workspace is a
separate native window, so the splash never changes or interferes with its
title bar. CDAR then
requests maximization after the workspace exists, verifies the resulting window
geometry, retries once if Windows reports a false partial maximize, and falls
back to a centered normal window if necessary.

The responsive Electronic/Vibrational method chooser has cards that lift and
highlight on hover. It blends navy into burgundy, while the ECD and VCD
workspaces use matching dark outer chrome around white plots and light control
panels. The native window and taskbar icon also change to match the active
method.

In either workspace:

1. Load calculated outputs and measured spectra with the input buttons, or
   drag files onto the window.
2. Inspect conformers, energies, populations, mode/state counts, and warnings.
3. Adjust the fit and view controls, or run Auto-Fit in the background.
4. Read the assignment and its supporting metrics beneath the Fit controls.
5. Export a publication-style PNG, vector PDF/SVG, or a CSV/TXT table.

Hovering any spectrum reports its live x/y coordinates only in the
always-visible application footer, using nm for UV/ECD and cm⁻¹ for IR/VCD.
ECD y values also carry the selected physical unit (mdeg or
deg·cm²·dmol⁻¹); UV, IR, and VCD y values retain no footer-unit suffix.
The UV and IR intensity axes are identified as absorbance in absorbance units
(AU). ECD defaults to millidegrees and can instead label imported values as
molar ellipticity (deg·cm²·dmol⁻¹); this selector labels values rather than
converting them, because conversion requires concentration and path length.
The VCD axis retains its channel-specific differential-absorbance quantity.
The footer uses the same proportional font as the rest of the interface. Under
**View / Export**, each mode can independently show or hide the zero baseline,
gridlines, and exported legend, and **Re-center spectra** restores both plots to
the exact selected spectral window and their current data amplitudes. Live plots
and exported figures use matching line styles and peak arrows; their unboxed
line-swatch legends choose the least occupied plot corner automatically, and
hovering a legend row highlights its spectrum and bolds the corresponding
legend text without changing the line-based key. Major ticks use rounded
spectroscopic intervals and protrude outward in both the live and exported
figures; compact scientific notation is used for very small VCD values. The UV
and IR axes anchor zero at the bottom because absorbance is nonnegative. Both
spectral cards retain a compact right gutter outside the plots so terminal axis
labels remain separated from the card edge. Each live spectrum is slightly
taller to balance the space above the upper channel title and below the lower
x-axis label. The taller footer uses the same spacing above its card as the main
cards use below theirs, and its bottom inset matches the outer side insets. ECD
initializes its range to the full measured wavelength domain, while VCD starts
at 1000–1600 cm⁻¹ unless the user explicitly fits its window to data. The
default is a white plot with the zero baseline and export legend visible and
gridlines hidden.

The Fit tab ends with the complete assignment and metric report for its active
compound; the separate Results tab is no longer needed, and the three remaining
tabs share the control-panel width evenly. During fitting, the activity spinner
remains inline to the right of the **Auto-Fit** and **Reset** buttons. Results
color individual metric values as
strong/favoured, limited, or weak/unfavoured; the Methodology dialog defines
the ECD component metrics and every visual threshold. Suggested figure names
end in `_ECD` or `_VCD` according to the active method. The compact **New**,
**Rename**, **Methodology**, and **About** actions use a slightly taller button
frame so their labels have balanced vertical clearance.

The chooser, workspace headers, splash, native window identity, and packaged
Windows executable use the version-2 high-resolution CDAR/ECD/VCD artwork.
Minified in-app artwork uses linear mipmap filtering to retain detail on
lower-density displays. The splash presentation remains a fixed 280 × 280
pixels for 1.5 seconds; its image is the same CDAR artwork used by the primary
application identity.

Multi-column UV/ECD input opens a column-mapping dialog when its roles are
ambiguous. IR/VCD roles are inferred from sign content, matching the Python
workflow. Loading one channel preserves a channel that was loaded separately.

## Scientific implementation

Electronic mode includes validated Gaussian parsing, Gibbs-free-energy Boltzmann
weighting, length/velocity gauge selection, Gaussian or Lorentzian broadening,
independent UV/ECD bandwidths, global wavelength shifting, peak-shape,
cross-section, least-squares, and cosine objectives, UV-anchored auto-fitting,
SpecDis-inspired same-sign similarity, ESI, band detection, and fit diagnostics.
This substantially extended workflow uses SpecDis as an important methodological
starting point rather than as a complete specification.

Vibrational mode includes Gaussian frequency parsing, Gibbs-free-energy-only
weighting, Lorentzian broadening, scale and half-width optimization against IR,
integer-wavenumber normalization, independent region shifting, Shen overlap
similarity, independently fitted enantiomers, ESI, and automatic conformer
de-duplication before spectral calculation.

Both modes require normally terminated ground-state geometry optimization,
Gibbs free energy, a complete optimized geometry, the Gaussian Initial Parameters
bond table, and a complete harmonic analysis with positive frequencies. The
optimization completion marker is checked independently of Gibbs free energy.
ECD input LOG files must also contain the subsequent completed time-dependent
calculation, including excitation energies, oscillator strengths, and both
length- and velocity-gauge rotational strengths. VCD requires complete IR dipole
and VCD rotational strengths for the same harmonic modes. Invalid files are
rejected with a reason before conformers enter the calculation. Population and
spectrum construction enforce the same eligibility checks.

After VCD Auto-Fit completes, the displayed and exported calculated IR and VCD
curves are labeled `Calculated (fitted)`; the independently shifted enantiomer
is labeled `Enantiomer (fitted)`. Before Auto-Fit—including matched previews—
those curves retain the plain `Calculated` and `Enantiomer` labels. Electronic
Auto-Fit uses the same fitted-state convention: calculated UV/ECD and the ECD
enantiomer gain the qualifier only after a successful fit, and reset or
fit-input changes remove it. Harmless floating-point normalization by the fit
sliders does not clear a completed ECD fit. The UV and ECD display-scale controls show six
decimal places for precise manual scaling.

Open **Methodology** inside either workspace for the full user-facing protocol,
interpretation guidance, and literature references.

## Project layout

| File | Responsibility |
|---|---|
| `src/electronic.rs` | UV/ECD parsers, broadening, features, fitting, ESI, datasets |
| `src/vibrational.rs` | IR/VCD parser, broadening, region matching, Shen metrics, datasets |
| `src/math.rs` | Interpolation, small linear solves, smoothing, shared vector math |
| `src/export.rs` | CSV/TXT and consistent SVG/PDF/PNG figure generation |
| `src/app.rs` | Responsive chooser/workspaces, plots, dialogs, drag/drop, background fitting |
| `src/assets.rs` | Embedded artwork, high-resolution icons, and Unicode font fallback |
| `src/help.rs` | About and methodology reference text |
| `src/main.rs` | Native window and application entry point |
| `tests/` | Numerical and parser regressions |

The numerical modules do not depend on GUI types, so they can also be used as a
Rust library or tested independently.

## Notes for packagers

- The desktop UI uses `eframe`/`egui` with the OpenGL renderer.
- CPU-heavy grid searches and broadening use Rayon and background workers.
- PDF and SVG output remain vector. PNG output is rasterized at the selected
  DPI.
- Supplied CDAR/ECD/VCD artwork is embedded at build time; no runtime asset
  files are required. Windows builds also embed the multi-resolution
  `cdar.ico` in `cdar.exe` for Explorer and pinned-shortcut identity. The
  executable metadata identifies Jared Wood and OpenAI GPT-5.6 Sol as the
  authors/developers. Windows
  will nevertheless show **Unknown publisher** until the distributed `.exe`
  is Authenticode-signed with a trusted code-signing certificate issued to
  that identity; version metadata alone cannot establish a trusted publisher.

See [MIGRATION.md](MIGRATION.md) for a detailed Python-to-Rust feature map and
verification record.

## Import reports and troubleshooting

The footer has separate activity-log and coordinate cards with the same spacing
as the main workspace cards. Click the activity-log card to open a resizable,
scrollable report; **Copy log** copies its complete text. The coordinate prompt
reads “Hover cursor over a spectrum for x/y coordinates.” Conformer-tab protocol
paragraphs use the same body-text size as the Temperature label.

Calculation reports distinguish the selected files from conformers already in
the dataset. Every selected file is counted as newly retained, a duplicate,
rejected, already loaded, or selected repeatedly in the same import. Full paths
identify the removed duplicate and kept representative, and all rejection
reasons remain available. Reimporting a retained file skips it instead of adding
another entry; unchanged imports preserve populations and fitted results. Remove
a loaded conformer before importing a revised calculation at the same path.

The Gibbs-energy parser validates the printed harmonic data and thermochemistry;
it does not require a literal `freq` token in the route. Completion, positive
frequencies, finite Gibbs energy, geometry, connectivity, and complete spectral
arrays remain mandatory. All five numerical duplicate-detection gates are
unchanged.

## Version 2.0.2 interface changes

- The opening method chooser credits Jared Wood and OpenAI GPT-5.6 Sol as the
  authors/developers. The About dialog, Rust package metadata, and Windows
  executable author metadata use the same attribution.
- The Electronic and Vibrational workspace headers begin directly with their
  mode names. Their redundant mode icon, `CDAR` label, and adjacent divider were
  removed; the application title bar and taskbar icon remain unchanged.

## Version 2.0.1 maintenance changes

- Background fits apply only to the compound and input revision that started
  them. Resetting or changing inputs prevents an older result from restoring
  fitted labels or replacing current settings. Display-only changes remain
  available while fitting.
- Multi-file electronic imports queue every required column mapping and keep
  each request attached to its original compound. Conflicting column assignments
  are rejected. Splitting by prefix preserves temperature, gauge, units, and
  display settings while requiring a new fit for the new conformer groups.
- Excluding every conformer clears the displayed populations. Invalid
  temperatures or non-finite energies cannot produce artificial equal weights.
- Electronic and vibrational measurement loaders share one parser. Numeric rows
  must have consistent, complete, finite columns; damaged rows now produce an
  error instead of silently changing channels or dropping measurements. Spectra
  require at least two distinct finite coordinates. UV/ECD wavelengths must be
  positive. Measured IR/VCD files may include zero or negative wavenumbers
  outside the positive-frequency fitting window; these rows remain intact.
  CSV, TSV, semicolon, whitespace, and JASCO data remain supported.
- The footer cards have a vertical divider matching the other workspace
  separators. Click the left card to open the **UV/ECD activity log** or
  **IR/VCD activity log**. Each keeps reported actions and errors for the current
  session, in order, up to 200 entries or 1 MiB of text per mode. The oldest
  entries are removed when either limit is reached, with a visible notice;
  oversized single entries are shortened with a notice. Open log windows update
  as new events arrive, and **Copy log** copies the retained history.
- A printed TD geometry must match the optimized ground-state structure, allowing
  rigid translation and rotation. The Gibbs, frequency, completion, and spectral
  completeness requirements remain in place.
- Auto-Fit rejects unusable spectra and invalid VCD windows. Changing the VCD
  analysis window with the Data button clears a completed fit when appropriate.
  Calculated VCD/IR curves and fitting now cover windows outside 800–2200 cm⁻¹;
  extending the grid preserves its sampling density.
- Peak-shape fitting reuses broadened candidates instead of recomputing them.
  Gaussian route scanning and file-type detection avoid redundant work. Duplicate
  measurement parsers and the obsolete duplicate-summary formatter were removed;
  the Hartree conversion now has one shared definition.
- Native Windows icon handles are released when replaced or no longer needed.

The artwork, splash configuration, DPI rendering, duplicate-detection thresholds,
and established live/export labels are preserved. See `validation/README.md`
for test coverage and platform-validation limits.

Shared ECD/VCD interface language is kept identical when the action is the
same. Both modes use the same initial activity message, Gaussian-LOG button
wording, measured-spectrum terminology, fit-range label, and empty-import
message; mode-specific scientific and export descriptions remain distinct.

## Version 2.0.0 conformer protocol

Automatic conformer de-duplication runs in each mode before populations are
calculated. The optimization calculation supplies Gibbs free energy, optimized
geometry, and unscaled harmonic frequencies. Gaussian's Initial Parameters
R(i,j) bonds define the molecular graph.

A merge requires ALL of these inclusive gates from logdedup.py:
  |ΔG| ≤ 0.20 kcal/mol (627.509474 kcal/mol per hartree)
  symmetry-corrected Cartesian RMSD ≤ 0.10 Å
  largest aligned single-atom displacement ≤ 0.15 Å
  sorted-frequency RMSD ≤ 2.0 cm⁻¹
  largest sorted-mode difference ≤ 3.0 cm⁻¹

Every atom participates, including methyl hydrogens and tert-butyl branches.
Only element/connectivity-preserving graph automorphisms may relabel atoms;
translation and proper rotation are allowed, reflection is not. A loose 5%
principal-moment screen precedes geometry comparison. Graph-label refinement,
validated orbit assignments and bounded exact search resolve symmetry.

Conformers are considered from lowest Gibbs energy upward and compared only
with retained representatives, preventing chains of near matches from merging
distinct minima. Duplicate entries are removed before Boltzmann weighting;
the survivor is counted once, without adding the removed entry's weight.
Input qualification precedes duplicate comparison: incomplete or unsuccessful
calculations are rejected. Distinct valid structures are retained when their
atom lists, bonding graphs, frequency counts, or any numerical gate prevent a
match. A symmetry search limit cannot authorize an unproven merge. Import
messages identify rejected files, removed duplicates, and retained representatives.

The protocol is implemented in `src/gaussian.rs` and `src/dedup.rs`, with the
ECD/VCD import adapters in their existing mode modules. No Python installation
or new Rust dependency is required. Both button import and drag-and-drop apply
it before spectral recomputation. Artwork, splash behavior, DPI handling, and
fitted-legend behavior remain as in finalized 1.1.1.

### Validation against the supplied Python

`validation/logdedup.py` preserves the supplied reference byte-for-byte.
`python3 validation/generate_reference.py` (NumPy required) regenerates 68
fixed-seed oracle cases in `tests/fixtures/logdedup_reference.tsv`. `cargo test`
checks the Rust merger and proper-rotation displacement metrics against those
cases, as well as parser/integration and conservative edge-case regressions.
See `validation/README.md` for the deliberate handling of reference-script
edge cases; numerical thresholds have not been changed.
